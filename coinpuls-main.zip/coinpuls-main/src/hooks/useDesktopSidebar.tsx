import { createContext, useContext, useEffect, useState, ReactNode } from "react";

interface Ctx {
  visible: boolean;
  toggle: () => void;
  show: () => void;
  hide: () => void;
}

const DesktopSidebarContext = createContext<Ctx | undefined>(undefined);

const STORAGE_KEY = "desktop-sidebar-visible";

export const DesktopSidebarProvider = ({ children }: { children: ReactNode }) => {
  const [visible, setVisible] = useState<boolean>(() => {
    if (typeof window === "undefined") return true;
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved === null ? true : saved === "1";
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, visible ? "1" : "0");
    } catch {
      // ignore
    }
  }, [visible]);

  return (
    <DesktopSidebarContext.Provider
      value={{
        visible,
        toggle: () => setVisible((v) => !v),
        show: () => setVisible(true),
        hide: () => setVisible(false),
      }}
    >
      {children}
    </DesktopSidebarContext.Provider>
  );
};

export const useDesktopSidebar = () => {
  const ctx = useContext(DesktopSidebarContext);
  if (!ctx) {
    // Safe fallback so components don't crash if provider is missing
    return { visible: true, toggle: () => {}, show: () => {}, hide: () => {} };
  }
  return ctx;
};
