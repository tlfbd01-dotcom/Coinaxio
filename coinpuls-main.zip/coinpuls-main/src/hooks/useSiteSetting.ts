import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

/** djb2-style fast hash → short base36 string. Stable across reloads. */
const hashJson = (val: unknown): string => {
  try {
    const s = JSON.stringify(val) ?? "";
    let h = 5381;
    for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
  } catch {
    return "0";
  }
};

/** Append a cache-busting `?v=` param to an image url, preserving existing query. */
export const withCacheBuster = (url: string | undefined | null, version: string): string => {
  if (!url) return "";
  // Skip data URIs
  if (url.startsWith("data:")) return url;
  const sep = url.includes("?") ? "&" : "?";
  return `${url}${sep}v=${version}`;
};

/** Manually clear cached site setting (e.g. after admin update). */
export const clearSiteSettingCache = (key: string) => {
  try {
    window.localStorage.removeItem(`site_setting:${key}`);
    window.dispatchEvent(new CustomEvent("site-setting-cleared", { detail: { key } }));
  } catch {
    // ignore
  }
};

/**
 * Reads a single row from `site_settings` by key and keeps it in sync via realtime.
 * Any admin update is reflected on the live site instantly — no refresh needed.
 *
 * Returns a stable `version` token derived from the value content; use it with
 * `withCacheBuster()` on image URLs so browsers don't serve stale cached images
 * after admin updates the same URL.
 */
export function useSiteSetting<T = Record<string, unknown>>(
  key: string,
  fallback: T
): { value: T; loading: boolean; version: string } {
  const cacheKey = `site_setting:${key}`;

  const [value, setValue] = useState<T>(() => {
    if (typeof window === "undefined") return fallback;
    try {
      const cached = window.localStorage.getItem(cacheKey);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed && typeof parsed === "object") {
          return { ...fallback, ...(parsed as Partial<T>) };
        }
      }
    } catch {
      // ignore
    }
    return fallback;
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;

    const persist = (next: Partial<T>) => {
      try {
        window.localStorage.setItem(cacheKey, JSON.stringify(next));
      } catch {
        // ignore
      }
    };

    const load = async () => {
      const { data } = await supabase
        .from("site_settings")
        .select("value")
        .eq("key", key)
        .maybeSingle();
      if (!active) return;
      if (data?.value && typeof data.value === "object") {
        const next = data.value as Partial<T>;
        setValue({ ...fallback, ...next });
        persist(next);
      }
      setLoading(false);
    };

    load();

    const channel = supabase
      .channel(`site_settings:${key}:${Math.random().toString(36).slice(2)}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "site_settings",
          filter: `key=eq.${key}`,
        },
        (payload) => {
          const next = (payload.new as { value?: unknown })?.value;
          if (next && typeof next === "object") {
            setValue({ ...fallback, ...(next as Partial<T>) });
            persist(next as Partial<T>);
          }
        }
      )
      .subscribe();

    // Listen for manual cache-clear events (same tab) and storage events (other tabs)
    const onCleared = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail?.key === key) load();
    };
    const onStorage = (e: StorageEvent) => {
      if (e.key === cacheKey) load();
    };
    window.addEventListener("site-setting-cleared", onCleared);
    window.addEventListener("storage", onStorage);

    return () => {
      active = false;
      supabase.removeChannel(channel);
      window.removeEventListener("site-setting-cleared", onCleared);
      window.removeEventListener("storage", onStorage);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  const version = useMemo(() => hashJson(value), [value]);
  return { value, loading, version };
}
