import { ArrowRight, Sparkles, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import coin from "@/assets/coin.png";

const Hero = () => {
  return (
    <section className="relative overflow-hidden">
      <div className="container grid items-center gap-12 py-20 md:grid-cols-2 md:py-28">
        <div className="space-y-6">
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-primary">
            <Sparkles className="h-3.5 w-3.5" /> Highest paying offerwall
          </div>
          <h1 className="text-5xl font-extrabold leading-[1.05] tracking-tight md:text-7xl" style={{ fontFamily: 'Sora' }}>
            Earn <span className="text-gradient-primary">coins</span>.<br />
            Cash out <span className="text-gradient-gold">instantly</span>.
          </h1>
          <p className="max-w-md text-lg text-muted-foreground">
            Complete simple offers, play games, and answer surveys. Trade your coins for real money — PayPal, crypto or gift cards.
          </p>
          <div className="flex flex-wrap gap-3 pt-2">
            <Button size="lg" className="bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow">
              Start Earning <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" className="border-border/60">
              <Zap className="mr-2 h-4 w-4 text-primary" /> See Offers
            </Button>
          </div>
          <div className="flex gap-8 pt-4">
            <div>
              <div className="text-3xl font-bold text-gradient-primary">$2.4M+</div>
              <div className="text-xs text-muted-foreground">Paid to users</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-gradient-primary">120K+</div>
              <div className="text-xs text-muted-foreground">Active members</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-gradient-primary">800+</div>
              <div className="text-xs text-muted-foreground">Live offers</div>
            </div>
          </div>
        </div>

        <div className="relative flex items-center justify-center">
          <div className="absolute inset-0 -z-10 bg-gradient-primary opacity-20 blur-3xl" />
          <div className="relative animate-float">
            <img src={coin} alt="Reward coin" width={420} height={420} className="h-[320px] w-[320px] drop-shadow-[0_20px_60px_hsl(45_95%_60%/0.4)] md:h-[420px] md:w-[420px]" />
          </div>
          {/* Floating mini coins */}
          <img src={coin} alt="" loading="lazy" className="absolute left-0 top-10 h-16 w-16 animate-float opacity-80" style={{ animationDelay: '0.5s' }} />
          <img src={coin} alt="" loading="lazy" className="absolute bottom-10 right-4 h-20 w-20 animate-float opacity-80" style={{ animationDelay: '1s' }} />
        </div>
      </div>
    </section>
  );
};

export default Hero;
