import { useEffect, useState } from "react";
import { Coins } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSiteSetting, withCacheBuster } from "@/hooks/useSiteSetting";
import { formatCoins } from "@/lib/coins";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface Activity {
  id: string;
  username: string;
  provider: string;
  offerTitle: string;
  amount: number;
  avatar: string;
  completedAt: string;
}

const fallbackAvatar = (seed: string) =>
  `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(seed)}`;

const formatTime = (iso: string) => {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
};

const DEMO_ACTIVITIES: Activity[] = [
  { id: "demo-1", username: "rakib_99", provider: "AdGate", offerTitle: "Install Game X", amount: 250, avatar: fallbackAvatar("rakib_99"), completedAt: new Date(Date.now() - 60_000).toISOString() },
  { id: "demo-2", username: "sara_k", provider: "OfferToro", offerTitle: "Survey Complete", amount: 120, avatar: fallbackAvatar("sara_k"), completedAt: new Date(Date.now() - 3 * 60_000).toISOString() },
  { id: "demo-3", username: "mehedi", provider: "BitLabs", offerTitle: "Sign-up Bonus", amount: 75, avatar: fallbackAvatar("mehedi"), completedAt: new Date(Date.now() - 7 * 60_000).toISOString() },
  { id: "demo-4", username: "tanvir01", provider: "AdGem", offerTitle: "Reach Level 5", amount: 540, avatar: fallbackAvatar("tanvir01"), completedAt: new Date(Date.now() - 12 * 60_000).toISOString() },
  { id: "demo-5", username: "nila", provider: "Notik", offerTitle: "Daily Survey", amount: 90, avatar: fallbackAvatar("nila"), completedAt: new Date(Date.now() - 18 * 60_000).toISOString() },
  { id: "demo-6", username: "shanto", provider: "AyetStudios", offerTitle: "Watch & Earn", amount: 35, avatar: fallbackAvatar("shanto"), completedAt: new Date(Date.now() - 25 * 60_000).toISOString() },
  { id: "demo-7", username: "rina_22", provider: "AdGate", offerTitle: "Install & Open", amount: 180, avatar: fallbackAvatar("rina_22"), completedAt: new Date(Date.now() - 33 * 60_000).toISOString() },
  { id: "demo-8", username: "fahim", provider: "OfferToro", offerTitle: "Quick Quiz", amount: 60, avatar: fallbackAvatar("fahim"), completedAt: new Date(Date.now() - 45 * 60_000).toISOString() },
];

const countryToFlag = (cc: string) => {
  if (!cc || cc.length !== 2) return "";
  const A = 0x1f1e6;
  const base = "A".charCodeAt(0);
  return String.fromCodePoint(
    A + (cc.toUpperCase().charCodeAt(0) - base),
    A + (cc.toUpperCase().charCodeAt(1) - base)
  );
};

const UserActivity = () => {
  const [items, setItems] = useState<Activity[]>(DEMO_ACTIVITIES);
  const [userFlag, setUserFlag] = useState<string>(() => {
    if (typeof window === "undefined") return "🇧🇩";
    return window.localStorage.getItem("user_flag") || "🇧🇩";
  });
  const { value: logoCfg, version: logoVersion } = useSiteSetting<{ avatarUrl: string }>("site_logo", { avatarUrl: "" });
  const { value: trackerCfg } = useSiteSetting<{ enabled: boolean; scrolling: boolean }>(
    "live_tracker",
    { enabled: true, scrolling: false }
  );
  const coinIcon = withCacheBuster(logoCfg.avatarUrl, logoVersion);
  const defaultAvatar = coinIcon;

  const load = async () => {
    const { data } = await supabase
      .from("completed_offers")
      .select(
        `id, payout, title, created_at, user_id, status,
         offers ( title ),
         providers ( name )`
      )
      .order("created_at", { ascending: false })
      .limit(30);

    if (!data?.length) {
      // Keep demo data visible until real conversions exist
      return;
    }

    // fetch profiles for the user_ids
    const userIds = Array.from(new Set(data.map((d: any) => d.user_id).filter(Boolean)));
    const { data: profiles } = await supabase
      .from("profiles")
      .select("user_id, display_name, username, avatar_url")
      .in("user_id", userIds);

    const profileMap = new Map(
      (profiles || []).map((p: any) => [p.user_id, p])
    );

    const mapped: Activity[] = data.map((row: any) => {
      const p = profileMap.get(row.user_id);
      const name =
        p?.username ||
        p?.display_name ||
        (row.user_id ? `user_${row.user_id.slice(0, 4)}` : "user");
      return {
        id: row.id,
        username: name.length > 10 ? `${name.slice(0, 8)}…` : name,
        provider: row.providers?.name || "Provider",
        offerTitle: row.offers?.title || row.title || "Offer",
        amount: Number(row.payout) || 0,
        avatar: p?.avatar_url || defaultAvatar || fallbackAvatar(name),
        completedAt: row.created_at,
      };
    });

    setItems(mapped);
  };

  // Quickly turn a single new completed_offer row into an Activity and prepend it
  const prependNew = async (row: any) => {
    if (!row?.id) return;
    let username = row.user_id ? `user_${row.user_id.slice(0, 4)}` : "user";
    let avatar = defaultAvatar || fallbackAvatar(username);
    if (row.user_id) {
      const { data: p } = await supabase
        .from("profiles")
        .select("display_name, username, avatar_url")
        .eq("user_id", row.user_id)
        .maybeSingle();
      const name = p?.username || p?.display_name || username;
      username = name.length > 10 ? `${name.slice(0, 8)}…` : name;
      avatar = p?.avatar_url || defaultAvatar || fallbackAvatar(name);
    }
    let providerName = "Provider";
    if (row.provider_id) {
      const { data: pr } = await supabase
        .from("providers")
        .select("name")
        .eq("id", row.provider_id)
        .maybeSingle();
      providerName = pr?.name || providerName;
    }
    const next: Activity = {
      id: row.id,
      username,
      provider: providerName,
      offerTitle: row.title || "Offer",
      amount: Number(row.payout) || 0,
      avatar,
      completedAt: row.created_at || new Date().toISOString(),
    };
    setItems((prev) => {
      // Replace demo items the first time real data shows up
      const realOnly = prev.some((p) => p.id.startsWith("demo-")) ? [] : prev.filter((p) => p.id !== next.id);
      return [next, ...realOnly].slice(0, 30);
    });
  };

  useEffect(() => {
    load();

    // Realtime: prepend immediately when a new completed_offer is inserted,
    // and refresh on updates so status/payout edits stay accurate.
    const channel = supabase
      .channel("completed_offers_ticker")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "completed_offers" },
        (payload) => prependNew(payload.new)
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "completed_offers" },
        () => load()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Detect visitor's country by IP and show their flag in the tracker.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("https://ipapi.co/json/", { cache: "no-store" });
        if (!res.ok) return;
        const data = await res.json();
        const cc: string | undefined = data?.country_code;
        const flag = cc ? countryToFlag(cc) : "";
        if (!cancelled && flag) {
          setUserFlag(flag);
          try {
            window.localStorage.setItem("user_flag", flag);
          } catch {
            // ignore
          }
        }
      } catch {
        // network failure — keep cached / default flag
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (!items.length) return null;
  if (trackerCfg.enabled === false) return null;

  // Duplicate list only when the marquee is animating, so a stopped tracker
  // doesn't show the items twice in a row.
  const loop = trackerCfg.scrolling ? [...items, ...items] : items;

  return (
    <div className="mt-2 px-3 sm:px-4">
      <div className="flex items-stretch gap-2 overflow-hidden rounded-xl border border-white/5 bg-card/40 p-1.5">
        {/* Flag block — visitor's country detected from IP */}
        <div className="flex shrink-0 items-center justify-center px-2.5" title="Your country">
          <span className="text-xl leading-none">{userFlag}</span>
        </div>

        {/* Marquee / static list — when stopped, allow touch/drag scrolling */}
        <div
          className={`relative flex-1 ${
            trackerCfg.scrolling
              ? "overflow-hidden"
              : "overflow-x-auto overflow-y-hidden [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
          }`}
          style={trackerCfg.scrolling ? undefined : { WebkitOverflowScrolling: "touch", touchAction: "pan-x" }}
        >
          {/* Edge fades */}
          <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-6 bg-gradient-to-r from-background to-transparent" />
          <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-6 bg-gradient-to-l from-background to-transparent" />

          <div className={`flex w-max gap-2 ${trackerCfg.scrolling ? "animate-marquee" : ""}`}>
            <TooltipProvider delayDuration={100}>
              {loop.map((u, idx) => (
                <Tooltip key={`${u.id}-${idx}`}>
                  <TooltipTrigger asChild>
                    <div className="flex shrink-0 cursor-pointer items-center gap-2 rounded-lg bg-card/80 px-2 py-1.5 transition hover:bg-card">
                      <img
                        src={u.avatar}
                        alt={u.username}
                        className="h-7 w-7 shrink-0 rounded-full bg-muted object-cover"
                        loading="lazy"
                      />
                      <div className="flex min-w-0 flex-col leading-tight">
                        <span className="truncate text-[11px] font-semibold text-foreground">
                          {u.username}
                        </span>
                        <span className="truncate text-[9px] text-muted-foreground">
                          {u.provider}
                        </span>
                      </div>
                      <div className="ml-1 flex shrink-0 items-center gap-1 rounded-full bg-background/60 px-1.5 py-0.5">
                        {coinIcon ? (
                          <img
                            src={coinIcon}
                            alt="Coin"
                            className="h-3.5 w-3.5 object-contain"
                            loading="lazy"
                          />
                        ) : (
                          <Coins className="h-3 w-3 text-gold" />
                        )}
                        <span className="text-[11px] font-bold text-foreground">
                          {formatCoins(u.amount)}
                        </span>
                      </div>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent side="bottom" className="max-w-[240px]">
                    <div className="flex flex-col gap-1 text-xs">
                      <p className="font-bold text-primary">{u.username}</p>
                      <p>
                        <span className="text-muted-foreground">Offer:</span>{" "}
                        <span className="font-medium">{u.offerTitle}</span>
                      </p>
                      <p>
                        <span className="text-muted-foreground">Wall:</span>{" "}
                        <span className="font-medium">{u.provider}</span>
                      </p>
                      <p>
                        <span className="text-muted-foreground">Reward:</span>{" "}
                        <span className="font-bold text-gold">
                          {formatCoins(u.amount)} coins
                        </span>
                      </p>
                      <p className="text-[10px] text-muted-foreground">
                        {formatTime(u.completedAt)}
                      </p>
                    </div>
                  </TooltipContent>
                </Tooltip>
              ))}
            </TooltipProvider>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserActivity;
