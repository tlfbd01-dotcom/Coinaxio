import { ReactNode, useEffect } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useAuthDialog } from "@/components/AuthDialogProvider";

interface Props {
  children: ReactNode;
  requireAdmin?: boolean;
}

const ProtectedRoute = ({ children, requireAdmin = false }: Props) => {
  const { user, isAdmin, roles, loading } = useAuth();
  const { open } = useAuthDialog();

  useEffect(() => {
    if (!loading && !user) open("signin");
  }, [loading, user, open]);

  // While auth is hydrating (e.g. on a hard refresh), show a loader instead of
  // bouncing the user away — otherwise refreshing /dashboard briefly redirects
  // to "/" and the user can't tell which page they're on.
  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background text-sm text-muted-foreground">
        Loading…
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/" replace />;
  }

  // For admin-only routes, wait until roles have actually been fetched before
  // deciding to redirect — otherwise an admin refreshing /admin gets bounced
  // to /dashboard for a moment while roles are still loading.
  if (requireAdmin && !isAdmin) {
    if (roles.length === 0) {
      return (
        <div className="flex min-h-screen items-center justify-center bg-background text-sm text-muted-foreground">
          Loading…
        </div>
      );
    }
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
