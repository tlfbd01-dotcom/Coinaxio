import { useEffect, useState } from "react";
import { Sparkles, Play } from "lucide-react";
import { useSiteSetting } from "@/hooks/useSiteSetting";

export interface FeaturedBannerItem {
  label: string;
  title: string;
  subtitle: string;
  caption: string;
  imageUrl: string;
  ctaUrl: string;
  overlayOpacity: number; // 0-100
}

export interface FeaturedBannersConfig {
  title: string;
  left: FeaturedBannerItem;
  right: FeaturedBannerItem;
}

export const defaultFeaturedBanners: FeaturedBannersConfig = {
  title: "Featured Partners",
  left: {
    label: "GAME",
    title: "EARN UP TO 250$",
    subtitle: "SIMPLE, FAST, REAL",
    caption: "ubScale",
    imageUrl: "",
    ctaUrl: "",
    overlayOpacity: 50,
  },
  right: {
    label: "SECUREUM.IO",
    title: "BEST VPS HOSTING",
    subtitle: "START FROM 8.99$",
    caption: "",
    imageUrl: "",
    ctaUrl: "",
    overlayOpacity: 50,
  },
};

const Banner = ({
  item,
  fallbackGradient,
  accentClass,
}: {
  item: FeaturedBannerItem;
  fallbackGradient: string;
  accentClass: string;
}) => {
  const hasImage = !!item.imageUrl;
  const [aspect, setAspect] = useState<number | null>(null);

  // Detect natural aspect ratio of the partner image so the container can match it.
  useEffect(() => {
    if (!hasImage) {
      setAspect(null);
      return;
    }
    let cancelled = false;
    const img = new Image();
    img.onload = () => {
      if (cancelled) return;
      if (img.naturalWidth > 0 && img.naturalHeight > 0) {
        setAspect(img.naturalWidth / img.naturalHeight);
      }
    };
    img.onerror = () => !cancelled && setAspect(null);
    img.src = item.imageUrl;
    return () => {
      cancelled = true;
    };
  }, [hasImage, item.imageUrl]);

  const style: React.CSSProperties = hasImage
    ? {
        backgroundImage: `linear-gradient(hsla(0,0%,0%,${item.overlayOpacity / 100}), hsla(0,0%,0%,${item.overlayOpacity / 100})), url(${item.imageUrl})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        // Match the image aspect ratio when known; clamp so a tall/short image
        // never breaks the 2-column row. Falls back to content-driven height.
        aspectRatio: aspect ? `${aspect}` : undefined,
        minHeight: "5.5rem",
        maxHeight: "12rem",
      }
    : {};

  const Tag = item.ctaUrl ? "a" : "div";
  const tagProps = item.ctaUrl
    ? { href: item.ctaUrl, target: "_blank", rel: "noopener noreferrer" }
    : {};

  return (
    <Tag
      {...(tagProps as Record<string, string>)}
      style={style}
      className={`glass-card gradient-border-bottom relative flex flex-col justify-between gap-1.5 overflow-hidden rounded-2xl border border-white/10 p-2.5 transition hover:scale-[1.01] sm:p-3 ${
        hasImage ? "" : `min-h-[5.5rem] sm:min-h-[6.5rem] ${fallbackGradient}`
      }`}
    >
      <div className="absolute right-2 top-2 flex h-5 w-5 items-center justify-center rounded-full bg-black/50 text-xs sm:h-6 sm:w-6">
        <Play className="h-2.5 w-2.5 fill-current sm:h-3 sm:w-3" />
      </div>
      <span className={`text-[10px] font-bold sm:text-xs ${accentClass}`}>
        {item.label}
      </span>
      <div>
        <p className="text-xs font-bold sm:text-sm">{item.title}</p>
        <p className="text-[10px] text-gray-300 sm:text-xs">{item.subtitle}</p>
      </div>
      {item.caption && (
        <span className={`text-right text-[9px] sm:text-[10px] ${accentClass}`}>
          {item.caption}
        </span>
      )}
    </Tag>
  );
};

const FeaturedBanners = () => {
  const { value } = useSiteSetting<FeaturedBannersConfig>(
    "featured_banners",
    defaultFeaturedBanners
  );

  return (
    <section className="mt-5 px-4 sm:mt-6 sm:px-6">
      <h2 className="mb-3 flex items-center gap-2 text-lg font-bold sm:text-xl">
        <Sparkles className="h-4 w-4 text-primary sm:h-5 sm:w-5" />{" "}
        {value.title || "Featured Partners"}
      </h2>
      <div className="grid grid-cols-2 gap-2.5 sm:gap-3">
        <Banner
          item={value.left}
          fallbackGradient="bg-gradient-to-br from-purple-900/40 to-blue-900/30"
          accentClass="text-purple-300"
        />
        <Banner
          item={value.right}
          fallbackGradient="bg-gradient-to-br from-emerald-900/40 to-teal-900/30"
          accentClass="text-emerald-300"
        />
      </div>
    </section>
  );
};

export default FeaturedBanners;
