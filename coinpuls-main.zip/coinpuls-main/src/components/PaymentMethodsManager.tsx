import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useStorageUpload } from "@/hooks/useStorageUpload";
import { Upload, Pencil, Trash2, Plus, X, Save } from "lucide-react";

interface PM {
  id: string;
  slug: string;
  name: string;
  logo_url: string | null;
  min_amount: number;
  max_amount: number | null;
  fee_percent: number;
  sort_order: number;
  is_enabled: boolean;
}

interface FormState {
  slug: string;
  name: string;
  logo_url: string;
  min_amount: number;
  max_amount: number | "";
  fee_percent: number;
  sort_order: number;
}

const emptyForm: FormState = {
  slug: "",
  name: "",
  logo_url: "",
  min_amount: 1,
  max_amount: "",
  fee_percent: 0,
  sort_order: 0,
};

const PaymentMethodsManager = () => {
  const [items, setItems] = useState<PM[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const { upload, uploading } = useStorageUpload({ folder: "payment-methods" });

  const load = async () => {
    const { data } = await supabase
      .from("payment_methods")
      .select("id, slug, name, logo_url, min_amount, max_amount, fee_percent, sort_order, is_enabled")
      .order("sort_order");
    setItems((data as PM[]) ?? []);
  };
  useEffect(() => { load(); }, []);

  const reset = () => {
    setEditingId(null);
    setForm(emptyForm);
    if (fileRef.current) fileRef.current.value = "";
  };

  const startEdit = (p: PM) => {
    setEditingId(p.id);
    setForm({
      slug: p.slug,
      name: p.name,
      logo_url: p.logo_url ?? "",
      min_amount: Number(p.min_amount),
      max_amount: p.max_amount == null ? "" : Number(p.max_amount),
      fee_percent: Number(p.fee_percent),
      sort_order: p.sort_order,
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleLogo = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await upload(file);
    if (url) setForm((f) => ({ ...f, logo_url: url }));
  };

  const submit = async () => {
    if (!form.slug.trim() || !form.name.trim()) {
      toast({ title: "Slug & name required", variant: "destructive" });
      return;
    }
    setBusy(true);
    const payload = {
      slug: form.slug.trim().toLowerCase(),
      name: form.name.trim(),
      logo_url: form.logo_url || null,
      min_amount: Number(form.min_amount) || 0,
      max_amount: form.max_amount === "" ? null : Number(form.max_amount),
      fee_percent: Number(form.fee_percent) || 0,
      sort_order: Number(form.sort_order) || 0,
    };
    const { error } = editingId
      ? await supabase.from("payment_methods").update(payload).eq("id", editingId)
      : await supabase.from("payment_methods").insert(payload);
    setBusy(false);
    if (error) {
      toast({ title: "Failed", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: editingId ? "Updated" : "Added" });
    reset();
    load();
  };

  const toggle = async (p: PM) => {
    await supabase.from("payment_methods").update({ is_enabled: !p.is_enabled }).eq("id", p.id);
    load();
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this payment method?")) return;
    await supabase.from("payment_methods").delete().eq("id", id);
    if (editingId === id) reset();
    load();
  };

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-5">
      <section className="rounded-2xl border border-white/10 bg-neutral-900/60 p-4 sm:p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-base font-bold text-primary sm:text-lg">
            {editingId ? <Pencil className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
            {editingId ? "Edit Method" : "Add New Method"}
          </h2>
          {editingId && (
            <button onClick={reset} className="flex items-center gap-1 rounded-full bg-white/5 px-3 py-1 text-xs font-bold text-muted-foreground hover:bg-white/10">
              <X className="h-3 w-3" /> Cancel
            </button>
          )}
        </div>

        <div className="mb-4 flex items-center gap-3">
          <div className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-white/10 bg-black/40">
            {form.logo_url ? (
              <img src={form.logo_url} alt="logo" className="h-full w-full object-contain" />
            ) : (
              <span className="text-[10px] text-muted-foreground">No logo</span>
            )}
          </div>
          <div className="flex flex-col gap-2">
            <input ref={fileRef} type="file" accept="image/*" onChange={handleLogo} className="hidden" />
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              disabled={uploading}
              className="flex items-center gap-2 rounded-lg bg-primary px-3 py-2 text-xs font-bold text-primary-foreground disabled:opacity-50"
            >
              <Upload className="h-3.5 w-3.5" />
              {uploading ? "Uploading…" : "Upload Logo"}
            </button>
            {form.logo_url && (
              <button
                type="button"
                onClick={() => setForm((f) => ({ ...f, logo_url: "" }))}
                className="text-[10px] font-semibold text-destructive hover:underline"
              >
                Remove logo
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Field label="Slug (unique id)" hint="e.g. bkash, ltc, binance">
            <input value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} placeholder="bkash" className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none focus:border-primary" />
          </Field>
          <Field label="Display name">
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="bKash" className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none focus:border-primary" />
          </Field>
          <Field label="Min withdraw amount">
            <input type="number" min={0} step="0.01" value={form.min_amount} onChange={(e) => setForm({ ...form, min_amount: Number(e.target.value) })} className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none focus:border-primary" />
          </Field>
          <Field label="Max withdraw (optional)">
            <input type="number" min={0} step="0.01" value={form.max_amount} onChange={(e) => setForm({ ...form, max_amount: e.target.value === "" ? "" : Number(e.target.value) })} placeholder="No limit" className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none focus:border-primary" />
          </Field>
          <Field label="Fee (%)">
            <input type="number" min={0} step="0.01" value={form.fee_percent} onChange={(e) => setForm({ ...form, fee_percent: Number(e.target.value) })} className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none focus:border-primary" />
          </Field>
          <Field label="Sort order">
            <input type="number" value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: Number(e.target.value) })} className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none focus:border-primary" />
          </Field>
        </div>

        <button onClick={submit} disabled={busy || uploading} className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-primary py-2.5 text-sm font-bold text-primary-foreground disabled:opacity-50">
          <Save className="h-4 w-4" />
          {busy ? "Saving…" : editingId ? "Update Method" : "Add Method"}
        </button>
      </section>

      <section className="rounded-2xl border border-white/10 bg-neutral-900/60 p-4 sm:p-5">
        <h2 className="mb-3 text-base font-bold text-primary sm:text-lg">All Methods ({items.length})</h2>
        <div className="flex flex-col gap-2">
          {items.length === 0 && <p className="py-6 text-center text-xs text-muted-foreground">No payment methods yet.</p>}
          {items.map((p) => (
            <div key={p.id} className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 p-3">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-black/40">
                {p.logo_url ? <img src={p.logo_url} alt={p.name} className="h-full w-full object-contain" /> : <span className="text-[9px] text-muted-foreground">{p.slug.slice(0, 3).toUpperCase()}</span>}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{p.name}</p>
                <p className="text-[10px] text-muted-foreground">{p.slug} · min {p.min_amount}{p.max_amount ? ` · max ${p.max_amount}` : ""} · fee {p.fee_percent}%</p>
              </div>
              <div className="flex shrink-0 items-center gap-1.5">
                <button onClick={() => toggle(p)} className={`rounded-full px-3 py-1 text-[11px] font-bold ${p.is_enabled ? "bg-primary/20 text-primary" : "bg-white/10 text-muted-foreground"}`}>{p.is_enabled ? "On" : "Off"}</button>
                <button onClick={() => startEdit(p)} className="rounded-full bg-white/10 p-1.5 text-foreground hover:bg-white/20" aria-label="Edit"><Pencil className="h-3.5 w-3.5" /></button>
                <button onClick={() => remove(p.id)} className="rounded-full bg-destructive/20 p-1.5 text-destructive hover:bg-destructive/30" aria-label="Delete"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

const Field = ({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) => (
  <label className="flex flex-col gap-1">
    <span className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">{label}</span>
    {children}
    {hint && <span className="text-[10px] text-muted-foreground/70">{hint}</span>}
  </label>
);

export default PaymentMethodsManager;
