import { createContext, ReactNode, useContext, useState } from "react";
import AuthDialog from "@/components/AuthDialog";

type Mode = "signin" | "signup";

interface AuthDialogContextValue {
  open: (mode?: Mode) => void;
  close: () => void;
}

const AuthDialogContext = createContext<AuthDialogContextValue | null>(null);

export const AuthDialogProvider = ({ children }: { children: ReactNode }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [mode, setMode] = useState<Mode>("signin");

  const open = (m: Mode = "signin") => {
    setMode(m);
    setIsOpen(true);
  };

  return (
    <AuthDialogContext.Provider value={{ open, close: () => setIsOpen(false) }}>
      {children}
      <AuthDialog open={isOpen} onOpenChange={setIsOpen} initialMode={mode} />
    </AuthDialogContext.Provider>
  );
};

export const useAuthDialog = () => {
  const ctx = useContext(AuthDialogContext);
  if (!ctx) throw new Error("useAuthDialog must be used within AuthDialogProvider");
  return ctx;
};
