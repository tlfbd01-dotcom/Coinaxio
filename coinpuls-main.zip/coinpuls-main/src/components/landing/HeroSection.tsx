import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowRight, Sparkles, Mail, Lock, User, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuthDialog } from "@/components/AuthDialogProvider";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { toast } from "@/hooks/use-toast";

const ROTATING = ["Testing Apps", "Playing Games", "Taking Surveys", "Watching Videos"];

const HeroSection = () => {
  const [idx, setIdx] = useState(0);
  const [bgUrl, setBgUrl] = useState<string | null>(null);
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(false);
  const [agree, setAgree] = useState(false);
  const [busy, setBusy] = useState(false);
  const [googleBusy, setGoogleBusy] = useState(false);
  const { open } = useAuthDialog();
  const navigate = useNavigate();

  const isSignIn = mode === "signin";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    if (!isSignIn && !agree) {
      toast({ title: "Privacy policy", description: "Please agree to continue", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      if (isSignIn) {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        toast({ title: "Signed in" });
        navigate("/dashboard");
      } else {
        const { error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/dashboard`,
            data: { display_name: name.trim() || email.split("@")[0] },
          },
        });
        if (error) throw error;
        toast({ title: "Account created", description: "Welcome!" });
        navigate("/dashboard");
      }
    } catch (err: any) {
      toast({ title: "Auth error", description: err.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const handleGoogle = async () => {
    setGoogleBusy(true);
    try {
      const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
      if (result.error) {
        toast({ title: "Google sign-in failed", description: result.error.message, variant: "destructive" });
      }
    } catch (err: any) {
      toast({ title: "Google sign-in failed", description: err?.message ?? "Unknown", variant: "destructive" });
    } finally {
      setGoogleBusy(false);
    }
  };

  const handleReset = async () => {
    if (!email) {
      toast({ title: "Email lagbe", description: "Email field e email din", variant: "destructive" });
      return;
    }
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    toast(
      error
        ? { title: "Error", description: error.message, variant: "destructive" }
        : { title: "Reset link pathano hoyeche", description: "Email check korun" },
    );
  };

  useEffect(() => {
    const t = setInterval(() => setIdx((i) => (i + 1) % ROTATING.length), 2200);
    return () => clearInterval(t);
  }, []);


  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("homepage_images")
        .select("image_url")
        .eq("slot", "hero-bg")
        .eq("is_active", true)
        .order("sort_order")
        .limit(1)
        .maybeSingle();
      if (data?.image_url) setBgUrl(data.image_url);
    })();
  }, []);

  return (
    <section className="relative isolate overflow-hidden px-4 pt-10 pb-8 sm:px-6 sm:pt-14 sm:pb-12">
      {bgUrl && (
        <>
          <div
            aria-hidden
            className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[340px] sm:h-[400px] bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: `url(${bgUrl})`,
              maskImage: "linear-gradient(to bottom, black 60%, transparent 100%)",
              WebkitMaskImage: "linear-gradient(to bottom, black 60%, transparent 100%)",
            }}
          />
          <div
            aria-hidden
            className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[340px] sm:h-[400px] bg-gradient-to-b from-background/30 via-background/50 to-background"
          />
        </>
      )}
      <div className="mx-auto grid max-w-6xl items-center gap-8 lg:grid-cols-[1.15fr_1fr]">
        <div className="space-y-5 text-center lg:text-left">
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-[11px] font-bold uppercase tracking-widest text-primary">
            <Sparkles className="h-3 w-3" /> #1 Rewards Platform
          </div>
          <h1 className="text-4xl font-extrabold leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl">
            <span className="text-gradient-primary">Get paid</span> for{" "}
            <span
              key={idx}
              className="inline-block animate-fade-in bg-gradient-to-r from-primary via-primary-glow to-primary bg-[length:200%_auto] bg-clip-text text-transparent"
              style={{ animation: "fade-in 0.5s ease-out" }}
            >
              {ROTATING[idx]}
            </span>
            <br />
            and Surveys.
          </h1>
          <p className="mx-auto max-w-md text-sm text-muted-foreground sm:text-base lg:mx-0">
            Earn up to <span className="font-bold text-primary">$10.00</span> per offer. Cash out instantly via PayPal, crypto, or gift cards.
          </p>
          <div className="flex flex-wrap justify-center gap-3 lg:justify-start">
            <Button
              size="lg"
              onClick={() => open("signup")}
              className="bg-primary text-primary-foreground font-bold transition-transform hover:-translate-y-0.5 hover:bg-primary/90"
            >
              Start Earning <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => open("signin")}
              className="border-white/20 bg-white/5 font-semibold hover:bg-white/10"
            >
              Sign In
            </Button>
          </div>
        </div>

        {/* Login/Signup card — popup-style (matches AuthDialog) */}
        <div className="mx-auto w-full max-w-[310px] rounded-2xl border border-white/10 bg-[#0d1620] p-5 lg:mx-0">
          <div className="mb-4">
            <h2 className="text-xl font-extrabold tracking-tight">{isSignIn ? "Sign In" : "Sign Up"}</h2>
            <p className="mt-0.5 text-xs text-muted-foreground">
              {isSignIn ? "Sign in to your account" : "Create a new account"}
            </p>
          </div>

          <div className="mb-4 grid grid-cols-2 gap-1 rounded-xl bg-white/[0.04] p-1">
            <button
              type="button"
              onClick={() => setMode("signin")}
              className={`rounded-lg py-2 text-xs font-bold transition ${isSignIn ? "bg-primary text-primary-foreground shadow" : "text-foreground/80 hover:text-foreground"}`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => setMode("signup")}
              className={`rounded-lg py-2 text-xs font-bold transition ${!isSignIn ? "bg-primary text-primary-foreground shadow" : "text-foreground/80 hover:text-foreground"}`}
            >
              Sign Up
            </button>
          </div>

          {isSignIn && (
            <>
              <button
                type="button"
                onClick={handleGoogle}
                disabled={googleBusy}
                className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] py-2.5 text-xs font-bold transition hover:bg-white/[0.06] disabled:opacity-60"
              >
                <svg className="h-4 w-4" viewBox="0 0 48 48" aria-hidden>
                  <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.6 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 12.95 4 4 12.95 4 24s8.95 20 20 20 20-8.95 20-20c0-1.3-.1-2.3-.4-3.5z"/>
                  <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 16 19 13 24 13c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/>
                  <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35 26.7 36 24 36c-5.1 0-9.6-3.4-11.2-8l-6.5 5C9.6 39.6 16.2 44 24 44z"/>
                  <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.2-4.1 5.6l6.2 5.2C41 35.6 44 30.3 44 24c0-1.3-.1-2.3-.4-3.5z"/>
                </svg>
                {googleBusy ? "Redirecting…" : "Login with Google"}
              </button>
              <div className="my-4 flex items-center gap-3">
                <div className="h-px flex-1 bg-white/10" />
                <span className="text-[10px] font-bold tracking-widest text-muted-foreground">OR</span>
                <div className="h-px flex-1 bg-white/10" />
              </div>
            </>
          )}

          <form onSubmit={handleSubmit} className="flex flex-col gap-3">
            {!isSignIn && (
              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold">Name</label>
                <div className="relative">
                  <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <input
                    type="text"
                    placeholder="Name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full rounded-lg border border-white/10 bg-white/[0.03] pl-9 pr-3 py-2.5 text-sm outline-none transition focus:border-primary focus:bg-white/[0.05] placeholder:text-muted-foreground/60"
                  />
                </div>
              </div>
            )}

            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold">Email</label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="email"
                  required
                  placeholder="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-lg border border-white/10 bg-white/[0.03] pl-9 pr-3 py-2.5 text-sm outline-none transition focus:border-primary focus:bg-white/[0.05] placeholder:text-muted-foreground/60"
                />
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold">Password</label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-lg border border-white/10 bg-white/[0.03] pl-9 pr-9 py-2.5 text-sm outline-none transition focus:border-primary focus:bg-white/[0.05] placeholder:text-muted-foreground/60"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((s) => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {isSignIn ? (
              <div className="flex items-center justify-between gap-2">
                <label className="flex cursor-pointer items-center gap-1.5 text-xs font-semibold">
                  <input
                    type="checkbox"
                    checked={remember}
                    onChange={(e) => setRemember(e.target.checked)}
                    className="h-3.5 w-3.5 cursor-pointer rounded border-white/20 bg-white/5 accent-primary"
                  />
                  Remember me
                </label>
                <button type="button" onClick={handleReset} className="text-xs font-bold text-primary hover:underline">
                  Forgot Password?
                </button>
              </div>
            ) : (
              <label className="flex cursor-pointer items-start gap-2 text-xs font-semibold">
                <input
                  type="checkbox"
                  checked={agree}
                  onChange={(e) => setAgree(e.target.checked)}
                  className="mt-0.5 h-3.5 w-3.5 cursor-pointer rounded border-white/20 bg-white/5 accent-primary"
                />
                <span>
                  I agree with{" "}
                  <Link to="/privacy" className="font-bold text-primary hover:underline">privacy policy</Link>
                </span>
              </label>
            )}

            <button
              type="submit"
              disabled={busy}
              className="mt-1 rounded-lg bg-primary py-3 text-sm font-extrabold uppercase tracking-wide text-primary-foreground transition hover:opacity-90 disabled:opacity-50"
            >
              {busy ? "Please wait…" : isSignIn ? "Sign In" : "Register"}
            </button>
          </form>

          <p className="mt-3 text-center text-xs font-semibold">
            {isSignIn ? (
              <>
                <span>Dont have Account? </span>
                <button type="button" onClick={() => setMode("signup")} className="font-bold text-primary hover:underline">
                  Create account
                </button>
              </>
            ) : (
              <>
                <span>Already have an account? </span>
                <button type="button" onClick={() => setMode("signin")} className="font-bold text-primary hover:underline">
                  Sign In
                </button>
              </>
            )}
          </p>

          {!isSignIn && (
            <>
              <div className="my-4 flex items-center gap-3">
                <div className="h-px flex-1 bg-white/10" />
                <span className="text-[10px] font-bold tracking-widest text-muted-foreground">OR SIGN IN WITH OTHERS</span>
                <div className="h-px flex-1 bg-white/10" />
              </div>
              <button
                type="button"
                onClick={handleGoogle}
                disabled={googleBusy}
                className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] py-2.5 text-xs font-bold transition hover:bg-white/[0.06] disabled:opacity-60"
              >
                <svg className="h-4 w-4" viewBox="0 0 48 48" aria-hidden>
                  <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.6 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 12.95 4 4 12.95 4 24s8.95 20 20 20 20-8.95 20-20c0-1.3-.1-2.3-.4-3.5z"/>
                  <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 16 19 13 24 13c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/>
                  <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35 26.7 36 24 36c-5.1 0-9.6-3.4-11.2-8l-6.5 5C9.6 39.6 16.2 44 24 44z"/>
                  <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.2-4.1 5.6l6.2 5.2C41 35.6 44 30.3 44 24c0-1.3-.1-2.3-.4-3.5z"/>
                </svg>
                {googleBusy ? "Redirecting…" : "Login with Google"}
              </button>
            </>
          )}

          <p className="mt-4 text-center text-[10px] leading-relaxed text-muted-foreground">
            Users are prohibited from using multiple accounts, completing offers on another user's account, or using any type of VPN, VPS, or Emulator software.
          </p>
        </div>

      </div>
    </section>
  );
};

export default HeroSection;
