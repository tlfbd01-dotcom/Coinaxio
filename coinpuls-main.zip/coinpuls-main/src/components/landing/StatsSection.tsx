import { useEffect, useRef, useState } from "react";
import { Users, DollarSign, CheckCircle2, Globe } from "lucide-react";

const STATS = [
  { icon: Users, label: "Total Users", value: 124350, prefix: "" },
  { icon: DollarSign, label: "Total Paid", value: 2480000, prefix: "$" },
  { icon: CheckCircle2, label: "Offers Done", value: 980000, prefix: "" },
  { icon: Globe, label: "Countries", value: 187, prefix: "" },
];

const useCountUp = (target: number, start: boolean, duration = 1500) => {
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!start) return;
    const t0 = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / duration);
      setN(Math.floor(target * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, start, duration]);
  return n;
};

const StatItem = ({ s, start }: { s: typeof STATS[number]; start: boolean }) => {
  const n = useCountUp(s.value, start);
  const Icon = s.icon;
  const formatted =
    s.value >= 1000 ? `${(n / 1000).toFixed(n >= 1000000 ? 1 : 0)}${n >= 1000000 ? "M" : "K"}+` : n.toLocaleString();
  return (
    <div className="glass-card flex flex-col items-center gap-2 rounded-2xl border border-white/10 p-4 transition hover:-translate-y-0.5 hover:border-primary/40 sm:p-5">
      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
        <Icon className="h-5 w-5" />
      </div>
      <div className="text-2xl font-extrabold text-gradient-primary sm:text-3xl">
        {s.prefix}
        {formatted}
      </div>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground sm:text-xs">{s.label}</div>
    </div>
  );
};

const StatsSection = () => {
  const ref = useRef<HTMLDivElement>(null);
  const [start, setStart] = useState(false);

  useEffect(() => {
    if (!ref.current) return;
    const obs = new IntersectionObserver(
      ([e]) => e.isIntersecting && setStart(true),
      { threshold: 0.2 }
    );
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  return (
    <section ref={ref} className="mt-6 px-4 sm:mt-8 sm:px-6">
      <div className="mx-auto grid max-w-6xl grid-cols-2 gap-3 sm:gap-4 md:grid-cols-4">
        {STATS.map((s) => (
          <StatItem key={s.label} s={s} start={start} />
        ))}
      </div>
    </section>
  );
};

export default StatsSection;
