import { UserPlus, MousePointerClick, Coins, Wallet } from "lucide-react";

const STEPS = [
  { icon: UserPlus, title: "Sign Up Free", desc: "Create your account in seconds — no credit card required." },
  { icon: MousePointerClick, title: "Pick an Offer", desc: "Browse hundreds of surveys, games & app trials." },
  { icon: Coins, title: "Earn Coins", desc: "Complete the offer and instantly receive your reward." },
  { icon: Wallet, title: "Cash Out", desc: "Withdraw via PayPal, crypto, or gift cards anytime." },
];

const HowItWorks = () => (
  <section className="mt-8 px-4 sm:mt-12 sm:px-6">
    <div className="mx-auto max-w-6xl">
      <div className="mb-6 text-center">
        <h2 className="text-2xl font-extrabold sm:text-3xl">
          How It <span className="text-gradient-primary">Works</span>
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">Four simple steps to start earning today.</p>
      </div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {STEPS.map((s, i) => {
          const Icon = s.icon;
          return (
            <div
              key={s.title}
              className="glass-card group relative rounded-2xl border border-white/10 p-5 transition hover:-translate-y-1 hover:border-primary/40 hover:shadow-glow"
            >
              <span className="absolute right-3 top-3 text-3xl font-black text-primary/20">
                0{i + 1}
              </span>
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary transition group-hover:bg-primary group-hover:text-primary-foreground">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="font-bold">{s.title}</h3>
              <p className="mt-1 text-xs text-muted-foreground">{s.desc}</p>
            </div>
          );
        })}
      </div>
    </div>
  </section>
);

export default HowItWorks;
