import { ArrowRight, Rocket } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuthDialog } from "@/components/AuthDialogProvider";

const CtaBanner = () => {
  const { open } = useAuthDialog();
  return (
    <section className="mt-8 px-4 sm:mt-12 sm:px-6">
      <div className="relative mx-auto max-w-6xl overflow-hidden rounded-3xl border border-primary/30 bg-gradient-to-br from-primary/15 via-background to-primary/5 p-6 text-center shadow-glow sm:p-10">
        <div className="pointer-events-none absolute -left-20 -top-20 h-60 w-60 rounded-full bg-primary/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-20 -right-20 h-60 w-60 rounded-full bg-primary/20 blur-3xl" />

        <div className="relative">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-[11px] font-bold uppercase tracking-widest text-primary">
            <Rocket className="h-3 w-3" /> Ready to start?
          </div>
          <h2 className="text-3xl font-extrabold leading-tight sm:text-4xl">
            Join <span className="text-gradient-primary">120,000+</span> earners today
          </h2>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            Your free account is one click away. Start earning in the next 30 seconds.
          </p>
          <Button
            size="lg"
            onClick={() => open("signup")}
            className="mt-5 bg-primary text-primary-foreground font-bold shadow-glow transition-transform hover:-translate-y-0.5 hover:bg-primary/90"
          >
            Create Free Account <ArrowRight className="ml-1 h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default CtaBanner;
