import { useMemo } from "react";

/**
 * Subtle floating coin particles in the background.
 * Pure CSS — no JS animation loop, performance-friendly.
 */
const CoinParticles = () => {
  const particles = useMemo(
    () =>
      Array.from({ length: 14 }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        size: 8 + Math.random() * 18,
        delay: Math.random() * 8,
        duration: 12 + Math.random() * 14,
        opacity: 0.08 + Math.random() * 0.12,
      })),
    []
  );

  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 z-0 overflow-hidden"
      style={{ contain: "strict" }}
    >
      {particles.map((p) => (
        <span
          key={p.id}
          className="absolute rounded-full bg-primary"
          style={{
            left: `${p.left}%`,
            bottom: `-${p.size}px`,
            width: p.size,
            height: p.size,
            opacity: p.opacity,
            boxShadow: "0 0 12px hsl(var(--primary) / 0.6)",
            animation: `coin-rise ${p.duration}s linear ${p.delay}s infinite`,
          }}
        />
      ))}
      <style>{`
        @keyframes coin-rise {
          0%   { transform: translateY(0) rotate(0deg); opacity: 0; }
          10%  { opacity: 1; }
          90%  { opacity: 1; }
          100% { transform: translateY(-110vh) rotate(360deg); opacity: 0; }
        }
      `}</style>
    </div>
  );
};

export default CoinParticles;
