import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { HelpCircle } from "lucide-react";

const FAQS = [
  { q: "Is WallsCash really free to use?", a: "Yes — it's 100% free. We never charge you to sign up or complete offers. You only earn." },
  { q: "How much can I earn?", a: "Earnings range from a few cents to over $10 per offer. Power users earn $50-$200/month." },
  { q: "When do I get paid?", a: "Withdrawals are processed instantly in most cases. PayPal & crypto usually arrive within minutes." },
  { q: "What payment methods are supported?", a: "PayPal, Bitcoin, Ethereum, Litecoin, USDT, and a wide range of gift cards (Amazon, Google Play, Steam, etc.)." },
  { q: "Is my data safe?", a: "Absolutely. We use 256-bit SSL encryption and never share your information with third parties." },
];

const FaqSection = () => (
  <section className="mt-8 px-4 sm:mt-12 sm:px-6">
    <div className="mx-auto max-w-3xl">
      <div className="mb-6 text-center">
        <div className="mb-2 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-[11px] font-bold uppercase tracking-widest text-primary">
          <HelpCircle className="h-3 w-3" /> FAQ
        </div>
        <h2 className="text-2xl font-extrabold sm:text-3xl">
          Frequently Asked <span className="text-gradient-primary">Questions</span>
        </h2>
      </div>
      <Accordion type="single" collapsible className="space-y-2">
        {FAQS.map((f, i) => (
          <AccordionItem
            key={i}
            value={`f-${i}`}
            className="glass-card rounded-xl border border-white/10 px-4 data-[state=open]:border-primary/40"
          >
            <AccordionTrigger className="text-left text-sm font-semibold hover:no-underline">
              {f.q}
            </AccordionTrigger>
            <AccordionContent className="text-xs text-muted-foreground sm:text-sm">
              {f.a}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  </section>
);

export default FaqSection;
