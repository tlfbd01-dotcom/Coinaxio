import { Lock, Shield, Zap, Headphones, MessageCircle, CreditCard } from "lucide-react";

const BADGES = [
  { icon: Lock, label: "SSL Secured", desc: "256-bit encryption" },
  { icon: Shield, label: "Data Protected", desc: "GDPR compliant" },
  { icon: Zap, label: "Instant Payouts", desc: "Cash out anytime" },
  { icon: Headphones, label: "24/7 Support", desc: "Always available" },
  { icon: MessageCircle, label: "Live Chat", desc: "Real humans" },
  { icon: CreditCard, label: "Secure Payments", desc: "Verified providers" },
];

const TrustBadges = () => (
  <section className="mt-6 px-4 sm:mt-8 sm:px-6">
    <div className="mx-auto grid max-w-6xl grid-cols-2 gap-2 sm:grid-cols-3 sm:gap-3 lg:grid-cols-6">
      {BADGES.map(({ icon: Icon, label, desc }) => (
        <div
          key={label}
          className="flex items-center gap-2.5 rounded-full border border-primary/15 bg-card/60 px-3 py-2 transition hover:border-primary/40"
        >
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
            <Icon className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <p className="truncate text-[11px] font-bold leading-tight">{label}</p>
            <p className="truncate text-[9px] text-muted-foreground">{desc}</p>
          </div>
        </div>
      ))}
    </div>
  </section>
);

export default TrustBadges;
