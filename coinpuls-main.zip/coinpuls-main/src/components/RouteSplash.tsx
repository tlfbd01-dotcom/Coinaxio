import { useEffect, useRef, useState } from "react";
import { useLocation } from "react-router-dom";
import { useSiteSetting, withCacheBuster } from "@/hooks/useSiteSetting";
import { supabase } from "@/integrations/supabase/client";

interface LogoCfg {
  url: string;
  loadingUrl: string;
  text: string;
}

const defaults: LogoCfg = { url: "", loadingUrl: "", text: "COINTO" };

const RouteSplash = () => {
  const location = useLocation();
  const { value: logo, loading: settingLoading, version: logoVersion } = useSiteSetting<LogoCfg>("site_logo", defaults);
  const [visible, setVisible] = useState(false);
  const pathnameRef = useRef(location.pathname);
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const showBriefly = () => {
    setVisible(true);
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    hideTimerRef.current = setTimeout(() => setVisible(false), 1500);
  };

  useEffect(() => {
    if (location.pathname === pathnameRef.current) return;
    pathnameRef.current = location.pathname;
    // Suppress splash when explicitly requested (e.g. logo tap)
    if (typeof window !== "undefined" && (window as any).__skipNextSplash) {
      (window as any).__skipNextSplash = false;
      return;
    }
    showBriefly();
  }, [location.pathname]);

  useEffect(() => {
    // Track current user id so we only flash splash on a *real* sign-in/sign-out
    // transition, not on tab focus / token refresh / initial session events.
    let currentUserId: string | null | undefined = undefined;
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      const nextUserId = session?.user?.id ?? null;

      // First callback after mount just records the baseline — never show splash.
      if (currentUserId === undefined) {
        currentUserId = nextUserId;
        return;
      }

      // Ignore events that don't represent a true auth transition.
      if (event === "TOKEN_REFRESHED" || event === "USER_UPDATED" || event === "INITIAL_SESSION") {
        currentUserId = nextUserId;
        return;
      }

      if (
        (event === "SIGNED_IN" || event === "SIGNED_OUT") &&
        nextUserId !== currentUserId
      ) {
        currentUserId = nextUserId;
        showBriefly();
      } else {
        currentUserId = nextUserId;
      }
    });
    return () => {
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
      sub.subscription.unsubscribe();
    };
  }, []);

  if (!visible) return null;

  // Don't render a stale (localStorage-cached) logo before fresh DB value arrives
  const icon = settingLoading ? "" : withCacheBuster(logo.url || logo.loadingUrl, logoVersion);

  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center gap-8 bg-background">
      <div className="flex items-center justify-center">
        {icon && (
          <img
            src={icon}
            alt="Logo"
            className="h-56 w-56 object-contain sm:h-72 sm:w-72"
          />
        )}
      </div>
      <div className="flex gap-2">
        <span className="h-2.5 w-2.5 animate-bounce rounded-full bg-primary [animation-delay:-0.3s]" />
        <span className="h-2.5 w-2.5 animate-bounce rounded-full bg-primary [animation-delay:-0.15s]" />
        <span className="h-2.5 w-2.5 animate-bounce rounded-full bg-primary" />
        <span className="h-2.5 w-2.5 animate-bounce rounded-full bg-primary [animation-delay:0.15s]" />
      </div>
    </div>
  );
};

export default RouteSplash;
