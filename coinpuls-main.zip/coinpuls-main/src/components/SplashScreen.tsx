import { useEffect, useState } from "react";
import { useSiteSetting, withCacheBuster } from "@/hooks/useSiteSetting";

interface LogoCfg {
  url: string;
  loadingUrl: string;
  text: string;
}

const defaults: LogoCfg = { url: "", loadingUrl: "", text: "COINTO" };

const SplashScreen = ({ onDone }: { onDone: () => void }) => {
  const { value: logo, loading: settingLoading, version: logoVersion } = useSiteSetting<LogoCfg>("site_logo", defaults);
  // Only use icon once we have fresh value from DB (not stale localStorage cache),
  // otherwise an old cached logo can flash on the splash after admin updates it.
  const icon = settingLoading ? "" : withCacheBuster(logo.url || logo.loadingUrl, logoVersion);
  const [iconReady, setIconReady] = useState(false);
  const [elapsed, setElapsed] = useState(0);

  // Tick every 100ms to show elapsed time in UI
  useEffect(() => {
    const start = Date.now();
    const id = setInterval(() => setElapsed(Date.now() - start), 100);
    return () => clearInterval(id);
  }, []);

  // Preload icon image so it never flickers in
  useEffect(() => {
    console.log("[Splash] icon url:", icon);
    if (!icon) {
      setIconReady(true);
      return;
    }
    setIconReady(false);
    const img = new Image();
    let done = false;
    const finish = (reason: string) => {
      if (done) return;
      done = true;
      console.log("[Splash] icon ready:", reason);
      setIconReady(true);
    };
    img.onload = () => finish("loaded");
    img.onerror = () => finish("error");
    img.src = icon;
    const t = setTimeout(() => finish("timeout"), 1000);
    return () => {
      done = true;
      clearTimeout(t);
    };
  }, [icon]);

  // Log state changes
  useEffect(() => {
    console.log("[Splash] state", { settingLoading, iconReady });
  }, [settingLoading, iconReady]);

  // Dismiss as soon as ready
  const ready = !settingLoading && iconReady;
  useEffect(() => {
    if (!ready) return;
    console.log("[Splash] ready, dismissing in 400ms");
    const t = setTimeout(onDone, 400);
    return () => clearTimeout(t);
  }, [ready, onDone]);

  // Hard safety: never let the splash hang for more than 2.5s total
  useEffect(() => {
    const t = setTimeout(() => {
      console.warn("[Splash] hard timeout 2500ms — forcing dismiss");
      onDone();
    }, 2500);
    return () => clearTimeout(t);
  }, [onDone]);

  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center gap-8 bg-background">
      <div
        className={`flex items-center justify-center transition-opacity duration-200 ${
          icon && iconReady ? "opacity-100" : "opacity-0"
        }`}
      >
        {icon && (
          <img
            src={icon}
            alt="Logo"
            className="h-64 w-64 object-contain sm:h-80 sm:w-80"
          />
        )}
      </div>
      <div className="flex gap-2">
        <span className="h-2.5 w-2.5 animate-bounce rounded-full bg-primary [animation-delay:-0.3s]" />
        <span className="h-2.5 w-2.5 animate-bounce rounded-full bg-primary [animation-delay:-0.15s]" />
        <span className="h-2.5 w-2.5 animate-bounce rounded-full bg-primary" />
        <span className="h-2.5 w-2.5 animate-bounce rounded-full bg-primary [animation-delay:0.15s]" />
      </div>
    </div>
  );
};

export default SplashScreen;
