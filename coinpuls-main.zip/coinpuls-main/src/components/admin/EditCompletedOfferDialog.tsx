import { useEffect, useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Pencil } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { dollarsToCoins, coinsToDollars } from "@/lib/coins";

export interface CompletedOfferRow {
  id: string;
  username: string | null;
  provider_name: string | null;
  title: string | null;
  payout: number;
  country: string | null;
  provider_tx_id: string | null;
}

interface Props {
  row: CompletedOfferRow | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onSaved: () => void;
}

const Field = ({
  label,
  value,
  onChange,
  readOnly,
}: {
  label: string;
  value: string;
  onChange?: (v: string) => void;
  readOnly?: boolean;
}) => (
  <div>
    <label className="mb-1.5 block text-xs font-semibold text-muted-foreground">
      {label}
    </label>
    <input
      value={value}
      readOnly={readOnly}
      onChange={(e) => onChange?.(e.target.value)}
      className={`w-full rounded-lg border border-white/10 bg-black/40 px-3 py-2.5 text-sm outline-none focus:border-primary ${
        readOnly ? "cursor-not-allowed opacity-70" : ""
      }`}
    />
  </div>
);

const EditCompletedOfferDialog = ({ row, open, onOpenChange, onSaved }: Props) => {
  const [title, setTitle] = useState("");
  const [payout, setPayout] = useState("0");
  const [txId, setTxId] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!row) return;
    setTitle(row.title ?? "");
    setPayout(String(dollarsToCoins(row.payout ?? 0)));
    setTxId(row.provider_tx_id ?? "");
  }, [row]);

  if (!row) return null;

  const save = async () => {
    setBusy(true);
    const { error } = await supabase
      .from("completed_offers")
      .update({
        title,
        payout: coinsToDollars(Number(payout) || 0),
        provider_tx_id: txId || null,
      })
      .eq("id", row.id);
    setBusy(false);
    if (error) {
      toast({ title: "Save failed", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Offer updated" });
    onSaved();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md border-white/10 bg-neutral-950 p-0">
        <div className="flex items-center gap-2 border-b border-white/10 px-5 py-4">
          <Pencil className="h-5 w-5 text-primary" />
          <h2 className="text-base font-bold">Edit Offer</h2>
        </div>

        <div className="space-y-3 px-5 py-5">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Username" value={row.username ?? "—"} readOnly />
            <Field label="Offerwall" value={row.provider_name ?? "—"} readOnly />
          </div>
          <Field label="Offer Name" value={title} onChange={setTitle} />
          <div className="grid grid-cols-2 gap-3">
            <Field label="Coin" value={payout} onChange={setPayout} />
            <Field label="Country" value={row.country ?? ""} readOnly />
          </div>
          <Field label="Transaction ID" value={txId} onChange={setTxId} />
          <Field label="IP Address" value="N/A" readOnly />

          <div className="flex justify-end gap-2 pt-3">
            <button
              onClick={() => onOpenChange(false)}
              className="rounded-full border border-white/10 bg-white/5 px-5 py-2 text-xs font-semibold transition hover:bg-white/10"
            >
              Cancel
            </button>
            <button
              onClick={save}
              disabled={busy}
              className="rounded-full bg-primary px-5 py-2 text-xs font-bold text-primary-foreground shadow-[0_0_20px_hsl(var(--primary)/0.4)] transition hover:opacity-90 disabled:opacity-50"
            >
              {busy ? "Saving…" : "Save"}
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EditCompletedOfferDialog;
