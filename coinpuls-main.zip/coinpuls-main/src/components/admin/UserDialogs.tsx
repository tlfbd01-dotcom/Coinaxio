import { useEffect, useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { Eye, Pencil, Copy } from "lucide-react";
import { formatCoins } from "@/lib/coins";

interface BaseUser {
  user_id: string;
  email: string | null;
  display_name: string | null;
  username: string | null;
  balance: number;
  is_banned: boolean;
  created_at: string;
}

interface Tx {
  id: string;
  title: string | null;
  payout: number;
  status: string;
  created_at: string;
}

const fmtDateTime = (s: string) => {
  const d = new Date(s);
  return d.toLocaleString();
};

const copy = (val: string) => {
  navigator.clipboard.writeText(val);
  toast({ title: "Copied" });
};

/* ---------------- View Dialog ---------------- */
export const UserDetailsDialog = ({
  user,
  open,
  onOpenChange,
}: {
  user: BaseUser | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) => {
  const [txs, setTxs] = useState<Tx[]>([]);

  useEffect(() => {
    if (!user || !open) return;
    supabase
      .from("completed_offers")
      .select("id,title,payout,status,created_at")
      .eq("user_id", user.user_id)
      .order("created_at", { ascending: false })
      .limit(20)
      .then(({ data }) => setTxs((data as Tx[]) ?? []));
  }, [user, open]);

  if (!user) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl border-white/10 bg-neutral-950 p-0">
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
          <div className="flex items-center gap-2">
            <Eye className="h-5 w-5 text-primary" />
            <h2 className="text-base font-bold">
              User Details: <span className="text-primary">{user.username ?? "—"}</span>
            </h2>
          </div>
        </div>

        <div className="space-y-4 px-5 py-5">
          <section className="rounded-xl border border-white/10 bg-black/30 p-4">
            <h3 className="mb-3 text-xs font-bold uppercase tracking-wider text-primary">
              Profile Information
            </h3>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Field label="User ID" value={user.user_id} mono copyable />
              <Field label="Username" value={user.username ?? "—"} copyable />
              <Field label="Email" value={user.email ?? "—"} copyable />
              <Field
                label="Balance"
                custom={
                  <span className="font-bold text-primary">
                    {formatCoins(user.balance)} coins
                  </span>
                }
              />
              <Field
                label="Status"
                custom={
                  <span
                    className={`inline-block rounded-md px-2 py-0.5 text-[10px] font-bold ${
                      user.is_banned
                        ? "bg-destructive/20 text-destructive"
                        : "bg-primary/20 text-primary"
                    }`}
                  >
                    {user.is_banned ? "BANNED" : "ACTIVE"}
                  </span>
                }
              />
              <Field label="Joined Date & Time" value={fmtDateTime(user.created_at)} />
              <Field label="Last Login IP" value="N/A" />
              <Field label="Device Info" value="N/A" />
            </div>
          </section>

          <section className="rounded-xl border border-white/10 bg-black/30 p-4">
            <h3 className="mb-3 text-xs font-bold uppercase tracking-wider text-primary">
              Transaction History ({txs.length})
            </h3>
            {txs.length === 0 ? (
              <p className="py-6 text-center text-xs text-muted-foreground">
                No transactions found
              </p>
            ) : (
              <div className="max-h-60 space-y-2 overflow-y-auto">
                {txs.map((t) => (
                  <div
                    key={t.id}
                    className="flex items-center justify-between rounded-lg border border-white/5 bg-white/5 px-3 py-2 text-xs"
                  >
                    <div className="min-w-0">
                      <p className="truncate font-semibold">{t.title ?? "Offer"}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {fmtDateTime(t.created_at)} • {t.status}
                      </p>
                    </div>
                    <span className="font-bold text-primary">
                      {formatCoins(t.payout)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </section>

          <div className="flex justify-end">
            <button
              onClick={() => onOpenChange(false)}
              className="rounded-lg border border-white/10 bg-white/5 px-5 py-2 text-xs font-semibold transition hover:bg-white/10"
            >
              Close
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

const Field = ({
  label,
  value,
  custom,
  mono,
  copyable,
}: {
  label: string;
  value?: string;
  custom?: React.ReactNode;
  mono?: boolean;
  copyable?: boolean;
}) => (
  <div className="rounded-lg border border-white/10 bg-black/40 p-3">
    <p className="mb-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
      {label}
    </p>
    <div className="flex items-center justify-between gap-2">
      {custom ?? (
        <span className={`truncate text-xs ${mono ? "font-mono" : "font-semibold"}`}>
          {value}
        </span>
      )}
      {copyable && value && value !== "—" && (
        <button
          onClick={() => copy(value)}
          className="text-muted-foreground transition hover:text-primary"
          aria-label="Copy"
        >
          <Copy className="h-3.5 w-3.5" />
        </button>
      )}
    </div>
  </div>
);

/* ---------------- Edit Dialog ---------------- */
export const EditUserDialog = ({
  user,
  open,
  onOpenChange,
  onSaved,
}: {
  user: BaseUser | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onSaved: () => void;
}) => {
  const [tab, setTab] = useState<"profile" | "history">("profile");
  const [balance, setBalance] = useState("0");
  const [status, setStatus] = useState<"active" | "banned">("active");
  const [showOffers, setShowOffers] = useState(true);
  const [busy, setBusy] = useState(false);
  const [history, setHistory] = useState<Tx[]>([]);

  useEffect(() => {
    if (!user || !open) return;
    setBalance(String(user.balance ?? 0));
    setStatus(user.is_banned ? "banned" : "active");
    supabase
      .from("profiles")
      .select("show_offers")
      .eq("user_id", user.user_id)
      .maybeSingle()
      .then(({ data }) => setShowOffers((data as any)?.show_offers ?? true));
    supabase
      .from("completed_offers")
      .select("id,title,payout,status,created_at")
      .eq("user_id", user.user_id)
      .order("created_at", { ascending: false })
      .limit(20)
      .then(({ data }) => setHistory((data as Tx[]) ?? []));
  }, [user, open]);

  if (!user) return null;

  const save = async () => {
    setBusy(true);
    const { error } = await supabase
      .from("profiles")
      .update({
        balance: Number(balance) || 0,
        is_banned: status === "banned",
        show_offers: showOffers,
      })
      .eq("user_id", user.user_id);
    setBusy(false);
    if (error) {
      toast({ title: "Save failed", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "User updated" });
    onSaved();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md border-white/10 bg-neutral-950 p-0">
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
          <div className="flex items-center gap-2">
            <Pencil className="h-5 w-5 text-primary" />
            <h2 className="text-base font-bold">
              Edit User: <span className="text-primary">{user.username ?? "—"}</span>
            </h2>
          </div>
        </div>

        <div className="px-5 py-4">
          <div className="mb-4 grid grid-cols-2 gap-1 rounded-xl border border-white/10 bg-black/40 p-1">
            <button
              onClick={() => setTab("profile")}
              className={`rounded-lg py-2 text-xs font-bold transition ${
                tab === "profile"
                  ? "bg-neutral-800 text-foreground"
                  : "text-muted-foreground"
              }`}
            >
              Edit Profile
            </button>
            <button
              onClick={() => setTab("history")}
              className={`rounded-lg py-2 text-xs font-bold transition ${
                tab === "history"
                  ? "bg-neutral-800 text-foreground"
                  : "text-muted-foreground"
              }`}
            >
              Activity History
            </button>
          </div>

          {tab === "profile" ? (
            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-xs font-semibold">Balance (৳)</label>
                <input
                  type="number"
                  step="0.01"
                  value={balance}
                  onChange={(e) => setBalance(e.target.value)}
                  className="w-full rounded-lg border border-white/10 bg-black/40 px-3 py-2.5 text-sm outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-semibold">Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full rounded-lg border border-white/10 bg-black/40 px-3 py-2.5 text-sm outline-none focus:border-primary"
                >
                  <option value="active">Active</option>
                  <option value="banned">Banned</option>
                </select>
              </div>

              <div className="flex items-center justify-between rounded-xl border border-white/10 bg-black/40 p-3">
                <div className="min-w-0 pr-3">
                  <p className="text-xs font-bold">Live Tracker & My Offers</p>
                  <p className="text-[11px] text-muted-foreground">
                    Allow this user to see Live Tracker and Offers page
                  </p>
                </div>
                <button
                  onClick={() => setShowOffers((v) => !v)}
                  className={`relative h-6 w-11 flex-shrink-0 rounded-full transition ${
                    showOffers ? "bg-primary" : "bg-white/10"
                  }`}
                  aria-label="Toggle offers visibility"
                >
                  <span
                    className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${
                      showOffers ? "left-[22px]" : "left-0.5"
                    }`}
                  />
                </button>
              </div>

              <div className="rounded-xl border border-white/10 bg-black/40 p-3">
                <div className="grid grid-cols-2 gap-y-2 text-[11px] text-muted-foreground">
                  <p>
                    <span className="font-semibold text-foreground/70">Last IP:</span> N/A
                  </p>
                  <p>
                    <span className="font-semibold text-foreground/70">Device:</span> N/A
                  </p>
                  <p className="truncate">
                    <span className="font-semibold text-foreground/70">Email:</span>{" "}
                    {user.email ?? "—"}
                  </p>
                  <p>
                    <span className="font-semibold text-foreground/70">Joined:</span>{" "}
                    {new Date(user.created_at).toLocaleDateString()}
                  </p>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={save}
                  disabled={busy}
                  className="flex-1 rounded-full bg-primary py-2.5 text-xs font-bold text-primary-foreground shadow-[0_0_20px_hsl(var(--primary)/0.4)] transition hover:opacity-90 disabled:opacity-50"
                >
                  {busy ? "Saving…" : "Save Changes"}
                </button>
                <button
                  onClick={() => onOpenChange(false)}
                  className="rounded-full border border-white/10 bg-white/5 px-5 py-2.5 text-xs font-semibold transition hover:bg-white/10"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="max-h-80 space-y-2 overflow-y-auto">
              {history.length === 0 ? (
                <p className="py-6 text-center text-xs text-muted-foreground">
                  No activity yet
                </p>
              ) : (
                history.map((t) => (
                  <div
                    key={t.id}
                    className="flex items-center justify-between rounded-lg border border-white/5 bg-white/5 px-3 py-2 text-xs"
                  >
                    <div className="min-w-0">
                      <p className="truncate font-semibold">{t.title ?? "Offer"}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {fmtDateTime(t.created_at)} • {t.status}
                      </p>
                    </div>
                    <span className="font-bold text-primary">
                      {formatCoins(t.payout)}
                    </span>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
