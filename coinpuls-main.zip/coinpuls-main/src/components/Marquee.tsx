import coin from "@/assets/coin.png";
import { useSiteSetting, withCacheBuster } from "@/hooks/useSiteSetting";

const Marquee = () => {
  const items = Array.from({ length: 12 });
  const { value: logo, version: logoVersion } = useSiteSetting<{ url: string; text: string }>(
    "site_logo",
    { url: "", text: "COINTO" }
  );
  const logoUrl = withCacheBuster(logo.url, logoVersion);

  return (
    <div className="relative overflow-hidden border-y border-border/40 bg-card/40 py-5">
      <div className="flex w-max animate-marquee gap-12">
        {[...items, ...items].map((_, i) => (
          <div key={i} className="flex items-center gap-4 whitespace-nowrap">
            {logoUrl ? (
              <img
                src={logoUrl}
                alt={logo.text || "Logo"}
                className="h-8 w-auto object-contain"
              />
            ) : (
              <span
                className="text-2xl font-bold tracking-widest text-foreground/80"
                style={{ fontFamily: "Sora" }}
              >
                {logo.text || "COINTO"}
              </span>
            )}
            <img src={coin} alt="" width={32} height={32} loading="lazy" className="h-8 w-8" />
            <span className="text-2xl font-bold text-gradient-gold" style={{ fontFamily: "Sora" }}>
              {(Math.floor(Math.random() * 9000) + 1000).toLocaleString()}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Marquee;
