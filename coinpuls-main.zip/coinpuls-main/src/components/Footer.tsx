import { Link } from "react-router-dom";
import { Facebook, Twitter, Instagram, Youtube, Send, MessageCircle, Github, Globe } from "lucide-react";
import { useSiteSetting, withCacheBuster } from "@/hooks/useSiteSetting";

interface SocialLinks {
  facebook: string;
  twitter: string;
  instagram: string;
  youtube: string;
  telegram: string;
  whatsapp: string;
  discord: string;
  website: string;
}

const emptyLinks: SocialLinks = {
  facebook: "",
  twitter: "",
  instagram: "",
  youtube: "",
  telegram: "",
  whatsapp: "",
  discord: "",
  website: "",
};

const socialItems: { key: keyof SocialLinks; icon: typeof Globe; label: string }[] = [
  { key: "facebook", icon: Facebook, label: "Facebook" },
  { key: "twitter", icon: Twitter, label: "Twitter" },
  { key: "instagram", icon: Instagram, label: "Instagram" },
  { key: "youtube", icon: Youtube, label: "YouTube" },
  { key: "telegram", icon: Send, label: "Telegram" },
  { key: "whatsapp", icon: MessageCircle, label: "WhatsApp" },
  { key: "discord", icon: Github, label: "Discord" },
  { key: "website", icon: Globe, label: "Website" },
];

const Footer = () => {
  const { value: logo, version: logoVersion } = useSiteSetting<{ url: string; text: string }>(
    "site_logo",
    { url: "", text: "COINTO" }
  );
  const logoUrl = withCacheBuster(logo.url, logoVersion);
  const { value: links } = useSiteSetting<SocialLinks>("site_social_links", emptyLinks);

  const activeSocials = socialItems.filter((s) => links[s.key]?.trim());

  return (
    <div className="mb-4 mt-6 px-4 sm:mt-8 sm:px-6">
      <div className="glass-card rounded-2xl p-4 text-center sm:p-5">
        {logoUrl ? (
          <img
            src={logoUrl}
            alt={logo.text || "Logo"}
            className="mx-auto h-12 w-auto object-contain sm:h-14"
          />
        ) : (
          <h2 className="text-2xl font-extrabold tracking-wider text-primary sm:text-3xl">
            {logo.text || "COINTO"}
          </h2>
        )}
        <p className="mx-auto mt-2 max-w-xs text-xs text-muted-foreground sm:max-w-sm sm:text-sm">
          Cointo is a rewards-based platform that allows users to earn money by completing
          various tasks and offers, such as surveys, app downloads, sign-ups, and more.
        </p>

        {activeSocials.length > 0 && (
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            {activeSocials.map(({ key, icon: Icon, label }) => (
              <a
                key={key}
                href={links[key]}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-muted-foreground transition hover:bg-primary/20 hover:text-primary"
              >
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        )}

        <div className="mt-4 flex justify-center gap-6 text-xs sm:mt-5 sm:gap-8 sm:text-sm">
          <div>
            <p className="mb-1 font-bold">About</p>
            <Link to="/terms" className="block text-muted-foreground hover:text-foreground">
              Terms of Service
            </Link>
            <Link to="/privacy" className="block text-muted-foreground hover:text-foreground">
              Privacy Policy
            </Link>
          </div>
          <div>
            <p className="mb-1 font-bold">Pages</p>
            <Link to="/dashboard" className="block text-muted-foreground hover:text-foreground">
              Dashboard
            </Link>
            <Link to="/profile" className="block text-muted-foreground hover:text-foreground">
              Profile
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
