import { LayoutGrid, Users, Coins, Gift, UserCircle } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const left = [
  { icon: LayoutGrid, label: "Dashboard", to: "/dashboard" },
  { icon: Users, label: "Leaderboard", to: "/leaderboard" },
];
const right = [
  { icon: Gift, label: "Offers", to: "/all-offers" },
  { icon: UserCircle, label: "Profile", to: "/profile" },
];

const BottomNav = () => {
  const { pathname } = useLocation();
  const isActive = (to: string) => pathname === to;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 flex w-full items-center justify-around border-t border-white/10 bg-background/90 px-2 py-2 backdrop-blur-lg lg:hidden">
      {left.map((it) => (
        <Link
          key={it.label}
          to={it.to}
          className={`flex flex-col items-center transition hover:text-foreground ${
            isActive(it.to) ? "text-foreground" : "text-muted-foreground"
          }`}
        >
          <it.icon className="h-5 w-5 sm:h-6 sm:w-6" />
          <span className="mt-1 text-[10px] sm:text-xs">{it.label}</span>
        </Link>
      ))}

      <Link to="/withdraw" className="-mt-6 flex flex-col items-center sm:-mt-7">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-glow-lg sm:h-14 sm:w-14">
          <Coins className="h-5 w-5 sm:h-6 sm:w-6" />
        </div>
        <span className="mt-1 text-[10px] font-bold text-primary sm:text-xs">Earn</span>
      </Link>

      {right.map((it) => (
        <Link
          key={it.label}
          to={it.to}
          className={`flex flex-col items-center transition hover:text-foreground ${
            isActive(it.to) ? "text-foreground" : "text-muted-foreground"
          }`}
        >
          <it.icon className="h-5 w-5 sm:h-6 sm:w-6" />
          <span className="mt-1 text-[10px] sm:text-xs">{it.label}</span>
        </Link>
      ))}
    </div>
  );
};

export default BottomNav;
