import { LucideIcon } from "lucide-react";

type Props = {
  icon: LucideIcon;
  title: string;
  action?: { label: string; href?: string };
};

const SectionHeader = ({ icon: Icon, title, action }: Props) => {
  return (
    <div className="mb-4 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <Icon className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-bold tracking-tight" style={{ fontFamily: 'Sora' }}>
          {title}
        </h2>
      </div>
      {action && (
        <a
          href={action.href ?? "#"}
          className="flex items-center gap-1 text-xs font-semibold text-primary hover:underline"
        >
          {action.label} →
        </a>
      )}
    </div>
  );
};

export default SectionHeader;
