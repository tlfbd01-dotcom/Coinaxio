import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { useSiteSetting } from "@/hooks/useSiteSetting";

export interface BgVisual {
  type: "solid" | "gradient" | "image";
  color?: string; // HSL "222 47% 11%"
  solidColor?: string;
  gradientFrom?: string;
  gradientTo?: string;
  gradientAngle?: number;
  imageUrl?: string;
  overlayOpacity?: number; // 0-100
  overlay?: number; // legacy
}

export interface BgOverride extends BgVisual {
  id: string;
  paths: string[]; // exact pathnames or wildcards (/admin/*)
}

export interface BgConfig extends BgVisual {
  enabled: boolean;
  scope: "all" | "include" | "exclude";
  paths: string[];
  overrides?: BgOverride[];
}

const defaults: BgConfig = {
  type: "solid",
  color: "222 47% 11%",
  gradientFrom: "240 10% 8%",
  gradientTo: "260 30% 12%",
  gradientAngle: 135,
  imageUrl: "",
  overlayOpacity: 60,
  enabled: true,
  scope: "all",
  paths: [],
  overrides: [],
};

const matchPath = (pathname: string, patterns: string[]) => {
  return patterns.some((raw) => {
    const p = raw.trim();
    if (!p) return false;
    if (p === pathname) return true;
    if (p.endsWith("/*")) return pathname.startsWith(p.slice(0, -1));
    return false;
  });
};

const buildBg = (
  v: BgVisual,
  body: HTMLElement
): string => {
  const overlayPct = (v.overlayOpacity ?? v.overlay ?? 0) / 100;
  const angle = v.gradientAngle ?? 135;
  const solid = v.color ? `hsl(${v.color})` : v.solidColor || "";

  if (v.type === "solid" && solid) {
    return solid;
  }
  if (v.type === "gradient" && v.gradientFrom && v.gradientTo) {
    const from = v.gradientFrom.includes("%") ? `hsl(${v.gradientFrom})` : v.gradientFrom;
    const to = v.gradientTo.includes("%") ? `hsl(${v.gradientTo})` : v.gradientTo;
    return `linear-gradient(${angle}deg, ${from}, ${to})`;
  }
  if (v.type === "image" && v.imageUrl) {
    const overlay = `linear-gradient(rgba(0,0,0,${overlayPct}), rgba(0,0,0,${overlayPct}))`;
    body.style.backgroundSize = "cover";
    body.style.backgroundPosition = "center";
    body.style.backgroundAttachment = "fixed";
    return `${overlay}, url("${v.imageUrl}")`;
  }
  return "";
};

const SiteBackground = () => {
  const { value: cfg } = useSiteSetting<BgConfig>("site_background", defaults);
  const { pathname } = useLocation();

  useEffect(() => {
    const body = document.body;
    const prev = {
      background: body.style.background,
      backgroundSize: body.style.backgroundSize,
      backgroundPosition: body.style.backgroundPosition,
      backgroundAttachment: body.style.backgroundAttachment,
    };

    const reset = () => {
      body.style.background = prev.background;
      body.style.backgroundSize = prev.backgroundSize;
      body.style.backgroundPosition = prev.backgroundPosition;
      body.style.backgroundAttachment = prev.backgroundAttachment;
    };

    if (cfg.enabled === false) return reset;

    // Per-page override takes precedence
    const override = (cfg.overrides || []).find((o) =>
      matchPath(pathname, o.paths || [])
    );

    if (override) {
      const bg = buildBg(override, body);
      if (bg) body.style.background = bg;
      return reset;
    }

    // Base scope
    if (cfg.scope === "include" && !matchPath(pathname, cfg.paths || [])) return reset;
    if (cfg.scope === "exclude" && matchPath(pathname, cfg.paths || [])) return reset;

    const bg = buildBg(cfg, body);
    if (bg) body.style.background = bg;

    return reset;
  }, [cfg, pathname]);

  return null;
};

export default SiteBackground;
