import { ReactNode } from "react";
import Header from "./Header";
import BottomNav from "./BottomNav";
import DesktopSidebar from "./DesktopSidebar";
import CoinParticles from "./landing/CoinParticles";

interface PageShellProps {
  title: string;
  subtitle?: string;
  children?: ReactNode;
  hideBottomNav?: boolean;
  /** @deprecated kept for backward compatibility, no longer renders */
  showBack?: boolean;
}

const PageShell = ({ title, subtitle, children, hideBottomNav }: PageShellProps) => {
  return (
    <div className="relative mx-auto flex min-h-screen w-full overflow-x-clip bg-background text-foreground">
      <CoinParticles />
      <DesktopSidebar />
      <div className="flex min-h-screen min-w-0 flex-1 flex-col pb-24 lg:pb-0">
        <Header />

        <div className="flex flex-col border-b border-white/5 px-4 py-3 sm:px-6">
          <h1 className="text-base font-bold sm:text-lg">{title}</h1>
          {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
        </div>

        <main className="flex-1 px-4 py-5 sm:px-6">
          {children ?? (
            <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-white/5 bg-white/5 p-10 text-center">
              <p className="text-sm text-muted-foreground">
                This page is coming soon. The shell and routing are in place — functionality will be wired in next.
              </p>
            </div>
          )}
        </main>
      </div>

      {!hideBottomNav && <BottomNav />}
    </div>
  );
};

export default PageShell;
