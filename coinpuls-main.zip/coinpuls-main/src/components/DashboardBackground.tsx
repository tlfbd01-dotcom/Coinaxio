import { useCallback, useEffect, useState } from "react";
import { AlertCircle, RefreshCw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const DashboardBackground = () => {
  const [bgUrl, setBgUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchBg = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: qErr } = await supabase
        .from("homepage_images")
        .select("image_url")
        .eq("slot", "dashboard-bg")
        .eq("is_active", true)
        .order("sort_order")
        .limit(1)
        .maybeSingle();

      if (qErr) throw qErr;
      setBgUrl(data?.image_url ?? null);
    } catch (e: any) {
      console.error("[DashboardBackground] failed to load:", e);
      setError(e?.message ?? "Failed to load background");
      setBgUrl(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchBg();
  }, [fetchBg]);

  if (loading) {
    // Subtle skeleton tint while we fetch — no blocking UI
    return (
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 -z-20 animate-pulse bg-white/[0.02]"
      />
    );
  }

  if (error) {
    return (
      <div className="fixed bottom-4 right-4 z-50 flex max-w-xs items-center gap-2 rounded-lg border border-destructive/40 bg-background/95 px-3 py-2 text-xs shadow-lg backdrop-blur">
        <AlertCircle className="h-4 w-4 shrink-0 text-destructive" />
        <span className="flex-1 text-muted-foreground">Background failed to load</span>
        <button
          onClick={fetchBg}
          className="flex items-center gap-1 rounded-md border border-white/15 px-2 py-1 font-semibold transition hover:bg-white/10"
        >
          <RefreshCw className="h-3 w-3" /> Retry
        </button>
      </div>
    );
  }

  if (!bgUrl) return null;

  return (
    <>
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 -z-20 bg-cover bg-center bg-no-repeat opacity-40"
        style={{ backgroundImage: `url(${bgUrl})` }}
      />
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 -z-10 bg-gradient-to-b from-background/60 via-background/80 to-background"
      />
    </>
  );
};

export default DashboardBackground;
