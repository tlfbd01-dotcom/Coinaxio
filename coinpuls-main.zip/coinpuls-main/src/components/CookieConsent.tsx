import { useEffect, useState } from "react";
import { Cookie, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const STORAGE_KEY = "cookie-consent-v1";

const CookieConsent = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      const t = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(t);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem(STORAGE_KEY, "accepted");
    setVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem(STORAGE_KEY, "declined");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div
      role="dialog"
      aria-live="polite"
      aria-label="Cookie consent"
      className="fixed bottom-4 left-1/2 z-[60] w-[calc(100%-2rem)] max-w-md -translate-x-1/2 lg:bottom-6 lg:left-6 lg:translate-x-0"
    >
      <div className="glass-card relative overflow-hidden rounded-2xl border border-primary/20 p-4 shadow-card-soft animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent" />

        <button
          onClick={handleDecline}
          aria-label="Close"
          className="absolute right-3 top-3 rounded-full p-1 text-muted-foreground transition-colors hover:bg-white/10 hover:text-foreground"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="flex items-start gap-3 pr-6">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary shadow-glow">
            <Cookie className="h-5 w-5" />
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="text-sm font-semibold text-foreground">
              We use cookies 🍪
            </h3>
            <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
              We use cookies to enhance your experience, analyze traffic, and personalize content. By clicking "Accept All", you agree to our use of cookies.
            </p>
          </div>
        </div>

        <div className="mt-4 flex items-center gap-2">
          <Button
            onClick={handleDecline}
            variant="ghost"
            size="sm"
            className="flex-1 text-xs hover:bg-white/5"
          >
            Decline
          </Button>
          <Button
            onClick={handleAccept}
            size="sm"
            className="flex-1 bg-primary text-primary-foreground text-xs font-semibold shadow-glow hover:bg-primary/90"
          >
            Accept All
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CookieConsent;
