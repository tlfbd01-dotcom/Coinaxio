import { useEffect, useRef, useState } from "react";
import {
  Menu,
  LayoutDashboard,
  Wallet,
  Trophy,
  Gift,
  User,
  LogOut,
  Coins,
  Shield,
  X,
  ChevronDown,
  ChevronRight,
  Users,
  Star,
  Building2,
  CreditCard,
  AlertTriangle,
  History,
  UserCog,
  KeyRound,
  Image as ImageIcon,
  LayoutGrid,
  Share2,
  Volume2,
  Palette,
  Activity,
  Images,
  Gauge,
  CheckCircle2,
  Download,
  Bell,
  DollarSign,
  Rocket,
  Handshake,
  BarChart3,
  Headphones,
  Settings,
} from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useSiteSetting, withCacheBuster } from "@/hooks/useSiteSetting";
import AuthDialog from "@/components/AuthDialog";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useDesktopSidebar } from "@/hooks/useDesktopSidebar";
import { formatCoins } from "@/lib/coins";

interface SubItem {
  to: string;
  label: string;
  badge?: number;
}

interface NavGroup {
  key: string;
  label: string;
  icon: typeof DollarSign;
  to?: string;
  subItems?: SubItem[];
}

const navGroups: NavGroup[] = [
  { key: "earn", label: "Earn", icon: DollarSign, to: "/" },
  {
    key: "offers",
    label: "Offers",
    icon: Rocket,
    subItems: [
      { to: "/all-offers", label: "All", badge: 1 },
      { to: "/all-offers?cat=games", label: "Games" },
      { to: "/all-offers?cat=surveys", label: "Surveys" },
      { to: "/all-offers?cat=others", label: "Others", badge: 1 },
    ],
  },
  {
    key: "partners",
    label: "Partners",
    icon: Handshake,
    subItems: [
      { to: "/all-offers?type=offers", label: "Offers" },
      { to: "/all-offers?type=surveys", label: "Surveys" },
    ],
  },
  { key: "cashout", label: "Cashout", icon: Wallet, to: "/withdraw" },
  { key: "ranking", label: "Ranking", icon: BarChart3, to: "/leaderboard" },
  { key: "affiliates", label: "Affiliates", icon: Users, to: "/profile" },
  { key: "support", label: "Support", icon: Headphones, to: "/profile" },
];

const adminItems = [
  { to: "/admin", label: "Overview", icon: Gauge },
  { to: "/admin/users", label: "All Users", icon: Users },
  { to: "/admin/withdraw", label: "Withdrawals", icon: Wallet },
  { to: "/admin/offers", label: "Complete Offers", icon: Gift },
  { to: "/admin/featured-offers", label: "Featured Offers", icon: Star },
  { to: "/admin/featured-banners", label: "Featured Banners", icon: Images },
  { to: "/admin/providers", label: "Providers", icon: Building2 },
  
  { to: "/admin/chargeback", label: "Chargeback", icon: AlertTriangle },
  { to: "/admin/postback-history", label: "Postback History", icon: History },
  { to: "/admin/notik-import", label: "Notik Import", icon: Download },
  { to: "/admin/roles", label: "Role Management", icon: UserCog },
  { to: "/admin/password", label: "Password Reset", icon: KeyRound },
  { to: "/admin/logo", label: "Logo", icon: ImageIcon },
  { to: "/admin/offerwall", label: "Offerwall", icon: LayoutGrid },
  { to: "/admin/social", label: "Social Links", icon: Share2 },
  { to: "/admin/sound", label: "Sound", icon: Volume2 },
  { to: "/admin/background", label: "Background", icon: Palette },
  { to: "/admin/live-tracker", label: "Live Tracker", icon: Activity },
  { to: "/admin/homepage-images", label: "Homepage Images", icon: Images },
];

const Header = () => {
  const { user, loading, isAdmin, signOut } = useAuth();
  const location = useLocation();
  const { toggle: toggleDesktopSidebar } = useDesktopSidebar();
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"signin" | "signup">("signin");
  const [menuOpen, setMenuOpen] = useState(false);
  const [openGroup, setOpenGroup] = useState<string | null>(null);
  const [adminOpen, setAdminOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [profile, setProfile] = useState<{ display_name: string | null; avatar_url: string | null; balance: number } | null>(null);
  const [coinPopup, setCoinPopup] = useState<{ amount: number; key: number } | null>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!user) {
      setProfile(null);
      return;
    }
    let prevBalance: number | null = null;
    const load = async () => {
      const { data } = await supabase
        .from("profiles")
        .select("display_name, avatar_url, balance")
        .eq("user_id", user.id)
        .maybeSingle();
      if (data) {
        if (prevBalance != null && Number(data.balance) > prevBalance) {
          const delta = Number(data.balance) - prevBalance;
          // Show celebratory popup
          setCoinPopup({ amount: delta, key: Date.now() });
          setTimeout(() => setCoinPopup(null), 4500);
          // Balance went up — play reward sound
          try {
            const { data: s } = await supabase
              .from("site_settings")
              .select("value")
              .eq("key", "site_sounds")
              .maybeSingle();
            const cfg: any = s?.value ?? {};
            if (cfg?.enabled !== false && cfg?.rewardUrl) {
              const audio = new Audio(cfg.rewardUrl);
              audio.volume = Math.min(1, Math.max(0, (cfg.volume ?? 70) / 100));
              audio.play().catch(() => {});
            }
          } catch {/* noop */}
        }
        prevBalance = Number(data.balance);
        setProfile(data);
      }
    };
    load();

    const channel = supabase
      .channel(`profile_balance_${user.id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "profiles", filter: `user_id=eq.${user.id}` },
        () => load()
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setProfileOpen(false);
      }
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const openAuth = (m: "signin" | "signup") => {
    setAuthMode(m);
    setAuthOpen(true);
  };

  const isActive = (to?: string) => to && (to === "/" ? location.pathname === "/" : location.pathname.startsWith(to.split("?")[0]));

  const displayName = profile?.display_name ?? user?.email?.split("@")[0] ?? "Account";
  const balance = profile?.balance ?? 0;
  const initials = (profile?.display_name ?? user?.email ?? "U").slice(0, 2).toUpperCase();

  // Realtime site logo (admin can update from /admin/logo and it reflects instantly)
  const { value: logoCfg, version: logoVersion } = useSiteSetting<{ url: string; text: string; avatarUrl: string }>(
    "site_logo",
    { url: "", text: "COINTO", avatarUrl: "" }
  );
  const logoUrl = withCacheBuster(logoCfg.url, logoVersion);
  const coinIcon = withCacheBuster(logoCfg.avatarUrl, logoVersion);

  return (
    <>
      <nav className="sticky top-0 z-30 flex items-center justify-between gap-2 border-b border-white/5 bg-background/80 px-3 py-2.5 backdrop-blur-md sm:px-4 sm:py-3">
        {/* Left: Hamburger + Logo (always visible) */}
        <div className="flex items-center gap-2.5">
        {/* Desktop: toggles the persistent DesktopSidebar */}
        <button
          type="button"
          onClick={toggleDesktopSidebar}
          className="hidden text-foreground lg:inline-flex"
          aria-label="Toggle sidebar"
        >
          <Menu className="h-6 w-6" />
        </button>

        {/* Mobile/Tablet: opens the sheet menu */}
        <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
          <SheetTrigger asChild>
            <button className="text-foreground lg:hidden" aria-label="Menu">
              <Menu className="h-6 w-6" />
            </button>
          </SheetTrigger>
          <SheetContent
            side="left"
            className="flex w-72 flex-col border-white/10 bg-background p-0 text-foreground"
          >
            {/* Logo header */}
            <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
              <Link
                to="/"
                onClick={() => {
                  (window as any).__skipNextSplash = true;
                  setMenuOpen(false);
                }}
                className="flex items-center"
              >
                {logoUrl ? (
                  <img
                    src={logoUrl}
                    alt={logoCfg.text || "Logo"}
                    className="h-10 w-auto object-contain"
                  />
                ) : (
                  <span className="text-lg font-extrabold tracking-tight text-primary">
                    {logoCfg.text || "COINTO"}
                  </span>
                )}
              </Link>
              <button
                onClick={() => setMenuOpen(false)}
                aria-label="Close"
                className="rounded-full p-1 text-muted-foreground transition hover:bg-white/10 hover:text-foreground"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Nav groups */}
            <div className="flex flex-1 flex-col gap-1 overflow-y-auto px-3 py-3">
              {navGroups.map((g) => {
                const Icon = g.icon;
                const active = isActive(g.to);
                const isOpen = openGroup === g.key;

                if (g.subItems) {
                  return (
                    <div key={g.key} className="flex flex-col">
                      <button
                        onClick={() => setOpenGroup(isOpen ? null : g.key)}
                        
                        className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition-all duration-300 ease-out ${
                          isOpen
                            ? "bg-primary/10 text-primary"
                            : "text-foreground/90 hover:bg-white/5 hover:translate-x-0.5"
                        }`}
                      >
                        <Icon className="h-5 w-5" />
                        <span className="flex-1 text-left">{g.label}</span>
                        <ChevronDown
                          className={`h-4 w-4 transition-transform ${isOpen ? "rotate-180" : ""}`}
                        />
                      </button>
                      {isOpen && (
                        <div className="ml-4 mt-1 flex flex-col gap-0.5 border-l border-white/10 pl-3">
                          {g.subItems.map((s) => (
                            <Link
                              key={s.to}
                              to={s.to}
                              onClick={() => setMenuOpen(false)}
                              className="flex items-center gap-3 rounded-lg px-2 py-2 text-sm text-foreground/80 transition hover:bg-white/5 hover:text-foreground"
                            >
                              <span className="h-1.5 w-1.5 rounded-full border border-foreground/30" />
                              <span className="flex-1">{s.label}</span>
                              {s.badge && (
                                <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1.5 text-[10px] font-bold text-primary-foreground">
                                  {s.badge}
                                </span>
                              )}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                }

                return (
                  <Link
                    key={g.key}
                    to={g.to!}
                    onClick={() => setMenuOpen(false)}
                    className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition-all duration-300 ease-out ${
                      active
                        ? "bg-primary text-primary-foreground translate-x-1"
                        : "text-foreground/90 hover:bg-white/5 hover:translate-x-0.5"
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="flex-1">{g.label}</span>
                    {g.key === "partners" && <ChevronRight className="h-4 w-4 opacity-70" />}
                  </Link>
                );
              })}

              {isAdmin && (
                <div className="mt-3 border-t border-white/10 pt-3">
                  <button
                    onClick={() => setAdminOpen((v) => !v)}
                    className="flex w-full items-center gap-3 rounded-xl bg-primary/10 px-3 py-3 text-sm font-bold text-primary transition hover:bg-primary/20"
                    aria-expanded={adminOpen}
                  >
                    <Shield className="h-5 w-5" />
                    <span className="flex-1 text-left">Admin Panel</span>
                    <ChevronDown
                      className={`h-4 w-4 transition-transform ${adminOpen ? "rotate-180" : ""}`}
                    />
                  </button>

                  {adminOpen && (
                    <div className="mt-1 flex flex-col gap-0.5 border-l border-primary/30 pl-2">
                      {adminItems.map((item) => {
                        const Icon = item.icon;
                        return (
                          <Link
                            key={item.to}
                            to={item.to}
                            onClick={() => setMenuOpen(false)}
                            className="flex items-center gap-3 rounded-lg px-3 py-2 text-xs font-medium text-muted-foreground transition hover:bg-white/5 hover:text-foreground"
                          >
                            <Icon className="h-4 w-4" />
                            <span>{item.label}</span>
                          </Link>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="border-t border-white/10 px-4 py-3 text-[10px] uppercase tracking-widest text-muted-foreground">
              Legal
            </div>
            <div className="border-t border-white/10 px-3 py-3">
              {user ? (
                <button
                  onClick={async () => {
                    await signOut();
                    setMenuOpen(false);
                  }}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 py-2.5 text-sm font-semibold transition hover:bg-white/5"
                >
                  <LogOut className="h-4 w-4" /> Sign Out
                </button>
              ) : (
                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      openAuth("signin");
                    }}
                    className="rounded-xl border border-white/20 py-2.5 text-sm font-semibold transition hover:bg-white/5"
                  >
                    Sign In
                  </button>
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      openAuth("signup");
                    }}
                    className="rounded-xl bg-primary py-2.5 text-sm font-bold text-primary-foreground transition hover:opacity-90"
                  >
                    Create Account
                  </button>
                </div>
              )}
            </div>
          </SheetContent>
        </Sheet>

          {/* Logo (always visible, links to home) */}
          <Link
            to="/"
            onClick={() => {
              (window as any).__skipNextSplash = true;
            }}
            className="flex items-center"
            aria-label="Home"
          >
            {logoUrl ? (
              <img
                src={logoUrl}
                alt={logoCfg.text || "Logo"}
                className="h-9 w-auto object-contain sm:h-10"
              />
            ) : (
              <span className="text-lg font-extrabold tracking-tight text-primary sm:text-xl">
                {logoCfg.text || "COINTO"}
              </span>
            )}
          </Link>
        </div>

        {/* Right: balance + profile + bell (auth) OR sign in/up */}
        {loading ? (
          <div className="h-8" />
        ) : user ? (
          <div className="flex items-center gap-2">
            {/* Balance pill */}
            <Link
              to="/withdraw"
              className="flex items-center gap-1.5 rounded-full bg-white/5 px-3 py-1.5 text-xs font-bold text-foreground transition hover:bg-white/10"
            >
              {coinIcon ? (
                <img src={coinIcon} alt="Coin" className="h-4 w-4 object-contain" />
              ) : (
                <Coins className="h-4 w-4 text-yellow-400" />
              )}
              <span>{formatCoins(balance)}</span>
              <Wallet className="ml-1 h-3.5 w-3.5 text-muted-foreground" />
            </Link>

            {/* Profile dropdown */}
            <div ref={profileRef} className="relative">
              <button
                onClick={() => setProfileOpen((v) => !v)}
                className="flex items-center gap-1.5 rounded-full bg-white/5 px-1 py-1 pr-2 text-xs font-semibold transition hover:bg-white/10"
              >
                <span className="relative">
                  {profile?.avatar_url ? (
                    <img
                      src={profile.avatar_url}
                      alt={displayName}
                      className="h-7 w-7 rounded-full object-cover"
                    />
                  ) : (
                    <span className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-primary to-primary-glow text-[10px] font-bold text-primary-foreground">
                      {initials}
                    </span>
                  )}
                  <span className="absolute bottom-0 right-0 h-2 w-2 rounded-full border border-background bg-emerald-400" />
                </span>
                <span className="max-w-[100px] truncate">{displayName}</span>
                <ChevronDown className="h-3.5 w-3.5 opacity-70" />
              </button>

              {profileOpen && (
                <div className="absolute right-0 top-full z-40 mt-2 w-52 overflow-hidden rounded-xl border border-white/10 bg-background shadow-xl">
                  <div className="border-b border-white/10 px-3 py-2">
                    <p className="truncate text-xs font-semibold">{displayName}</p>
                    <p className="truncate text-[10px] text-muted-foreground">{user.email}</p>
                  </div>
                  <Link
                    to="/dashboard"
                    onClick={() => setProfileOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 text-xs font-medium text-foreground/90 transition hover:bg-white/5"
                  >
                    <LayoutDashboard className="h-4 w-4" /> Dashboard
                  </Link>
                  <Link
                    to="/profile"
                    onClick={() => setProfileOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 text-xs font-medium text-foreground/90 transition hover:bg-white/5"
                  >
                    <Settings className="h-4 w-4" /> Profile Settings
                  </Link>
                  <Link
                    to="/my-offers"
                    onClick={() => setProfileOpen(false)}
                    className="flex items-center gap-2 px-3 py-2 text-xs font-medium text-foreground/90 transition hover:bg-white/5"
                  >
                    <Gift className="h-4 w-4" /> My Offers
                  </Link>
                  {isAdmin && (
                    <Link
                      to="/admin"
                      onClick={() => setProfileOpen(false)}
                      className="flex items-center gap-2 px-3 py-2 text-xs font-bold text-primary transition hover:bg-primary/10"
                    >
                      <Shield className="h-4 w-4" /> Admin Panel
                    </Link>
                  )}
                  <button
                    onClick={async () => {
                      setProfileOpen(false);
                      await signOut();
                    }}
                    className="flex w-full items-center gap-2 border-t border-white/10 px-3 py-2 text-xs font-medium text-destructive transition hover:bg-destructive/10"
                  >
                    <LogOut className="h-4 w-4" /> Sign Out
                  </button>
                </div>
              )}
            </div>

            {/* Bell */}
            <button
              aria-label="Notifications"
              className="flex h-8 w-8 items-center justify-center rounded-full bg-white/5 text-foreground transition hover:bg-white/10"
            >
              <Bell className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <div className="flex gap-2">
            <button
              onClick={() => openAuth("signin")}
              className="rounded-full border border-white/30 px-4 py-1.5 text-xs font-semibold transition hover:bg-white/10 sm:px-5 sm:py-2 sm:text-sm"
            >
              Sign In
            </button>
            <button
              onClick={() => openAuth("signup")}
              className="rounded-full bg-primary px-4 py-1.5 text-xs font-bold text-primary-foreground shadow-glow transition hover:opacity-90 sm:px-5 sm:py-2 sm:text-sm"
            >
              Sign Up
            </button>
          </div>
        )}
      </nav>

      <AuthDialog open={authOpen} onOpenChange={setAuthOpen} initialMode={authMode} />

      {coinPopup && (
        <div
          key={coinPopup.key}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={() => setCoinPopup(null)}
        >
          <div
            className="relative w-full max-w-sm overflow-hidden rounded-3xl border border-primary/40 bg-gradient-to-br from-background via-background to-primary/20 p-6 text-center shadow-2xl shadow-primary/30 animate-in zoom-in-95 slide-in-from-bottom-4 duration-300"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setCoinPopup(null)}
              className="absolute right-3 top-3 rounded-full p-1 text-muted-foreground transition hover:bg-white/10 hover:text-foreground"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>
            <div className="mx-auto mb-3 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-yellow-400 to-amber-600 shadow-lg shadow-yellow-500/40">
              {coinIcon ? (
                <img src={coinIcon} alt="Coin" className="h-12 w-12 object-contain animate-bounce" />
              ) : (
                <Coins className="h-12 w-12 text-white animate-bounce" />
              )}
            </div>
            <p className="text-xs font-bold uppercase tracking-widest text-primary">Reward Earned!</p>
            <p className="mt-2 text-4xl font-extrabold text-foreground">
              +{formatCoins(coinPopup.amount)}
            </p>
            <p className="mt-1 text-sm text-muted-foreground">coins added to your balance</p>
            <button
              onClick={() => setCoinPopup(null)}
              className="mt-5 w-full rounded-xl bg-primary py-2.5 text-sm font-bold text-primary-foreground transition hover:opacity-90"
            >
              Awesome!
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default Header;
