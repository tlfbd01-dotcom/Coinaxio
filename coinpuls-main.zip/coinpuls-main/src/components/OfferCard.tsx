import coin from "@/assets/coin.png";
import { ArrowUpRight } from "lucide-react";

export type Offer = {
  title: string;
  geo: string;
  description: string;
  coins: number;
  usd: string;
  emoji: string;
  hot?: boolean;
};

const OfferCard = ({ offer }: { offer: Offer }) => {
  return (
    <div className="group relative mx-auto w-full max-w-[310px] overflow-hidden rounded-2xl border border-border/60 bg-gradient-card p-5 shadow-card-soft transition-all duration-300 hover:-translate-y-1 hover:border-primary/50 hover:shadow-glow">
      {offer.hot && (
        <div className="absolute right-3 top-3 rounded-full bg-destructive/20 px-2 py-0.5 text-[10px] font-bold uppercase text-destructive">
          🔥 Hot
        </div>
      )}
      <div className="flex items-start gap-4">
        <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-secondary text-2xl">
          {offer.emoji}
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="truncate font-semibold">{offer.title}</h3>
          <p className="text-xs text-muted-foreground">{offer.geo}</p>
          <p className="mt-1 line-clamp-2 text-xs text-muted-foreground/80">{offer.description}</p>
        </div>
      </div>

      <div className="mt-5 flex items-center justify-between border-t border-border/40 pt-4">
        <div className="flex items-center gap-2">
          <img src={coin} alt="" width={20} height={20} loading="lazy" className="h-5 w-5" />
          <span className="font-bold text-gradient-gold">{offer.coins.toLocaleString()}</span>
          <span className="text-xs text-muted-foreground">≈ ${offer.usd}</span>
        </div>
        <button className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary transition-colors group-hover:bg-gradient-primary group-hover:text-primary-foreground">
          <ArrowUpRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

export default OfferCard;
