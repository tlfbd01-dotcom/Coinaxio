import { ReactNode } from "react";
import { Shield } from "lucide-react";
import Header from "@/components/Header";
import DesktopSidebar from "@/components/DesktopSidebar";

interface AdminShellProps {
  title: string;
  description?: string;
  children?: ReactNode;
}

const AdminShell = ({ title, description, children }: AdminShellProps) => {
  return (
    <div className="mx-auto flex min-h-screen w-full overflow-x-hidden bg-background text-foreground">
      <DesktopSidebar />
      <div className="flex min-h-screen min-w-0 flex-1 flex-col">
        <Header />

        <div className="flex items-center gap-3 border-b border-white/5 px-4 py-3 sm:px-6">
          <Shield className="h-5 w-5 text-primary" />
          <div className="flex flex-1 flex-col">
            <h1 className="text-base font-bold sm:text-lg">{title}</h1>
            {description && <p className="text-xs text-muted-foreground">{description}</p>}
          </div>
        </div>

        <main className="flex-1 px-4 py-5 sm:px-6">
          {children ?? (
            <div className="glass-card flex flex-col items-center justify-center gap-3 rounded-2xl p-10 text-center">
              <p className="text-sm text-muted-foreground">
                Admin module placeholder. Functionality and access control will be wired up next.
              </p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default AdminShell;
