import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Rocket, ChevronRight, ChevronLeft, Monitor } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { formatCoins } from "@/lib/coins";

interface Offer {
  id: string;
  title: string;
  image_url: string | null;
  payout: number;
  country: string | null;
  click_url: string | null;
}

const COLOR_POOL = [
  "from-orange-500 to-red-500",
  "from-blue-500 to-indigo-600",
  "from-purple-500 to-pink-500",
  "from-emerald-500 to-teal-600",
  "from-pink-500 to-rose-500",
  "from-amber-500 to-orange-600",
  "from-cyan-500 to-blue-600",
];

const PopularOffers = () => {
  const row1Ref = useRef<HTMLDivElement>(null);
  const row2Ref = useRef<HTMLDivElement>(null);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    const load = async () => {
      const { data: feat } = await supabase
        .from("featured_offers")
        .select("offer_id, title, image_url, cta_url, sort_order")
        .eq("is_active", true)
        .order("sort_order")
        .limit(100);

      if (feat && feat.length > 0 && feat.some((f: any) => f.offer_id)) {
        const ids = feat.map((f: any) => f.offer_id).filter(Boolean);
        const { data: offerRows } = await supabase
          .from("offers")
          .select("id, title, image_url, payout, country, click_url")
          .in("id", ids);
        if (offerRows && offerRows.length && active) {
          const map = new Map(offerRows.map((o) => [o.id, o]));
          const ordered = ids.map((id) => map.get(id)).filter(Boolean) as Offer[];
          setOffers(ordered);
          setLoading(false);
          return;
        }
      }

      const { data } = await supabase
        .from("offers")
        .select("id, title, image_url, payout, country, click_url")
        .eq("is_active", true)
        .order("payout", { ascending: false })
        .limit(100);
      if (active) {
        setOffers(data ?? []);
        setLoading(false);
      }
    };
    load();
    return () => { active = false; };
  }, []);

  const scroll = (dir: "left" | "right") => {
    const delta = dir === "left" ? -200 : 200;
    row1Ref.current?.scrollBy({ left: delta, behavior: "smooth" });
    row2Ref.current?.scrollBy({ left: delta, behavior: "smooth" });
  };

  const renderCard = (o: Offer, idx: number) => {
    const colorClass = COLOR_POOL[idx % COLOR_POOL.length];
    return (
      <a
        key={o.id}
        href={o.click_url ?? "#"}
        target="_blank"
        rel="noreferrer"
        className="glass-card group relative flex w-[95px] shrink-0 flex-col items-start gap-1.5 rounded-xl border border-white/10 p-1.5 text-left transition hover:border-primary/40"
      >
        <div className={`relative flex h-[70px] w-full items-center justify-center overflow-hidden rounded-lg bg-gradient-to-br ${colorClass}`}>
          {o.image_url ? (
            <img src={o.image_url} alt={o.title} className="h-full w-full object-cover" loading="lazy" />
          ) : (
            <span className="text-2xl font-black text-white">{o.title.charAt(0).toUpperCase()}</span>
          )}
          <div className="absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-md bg-black/50">
            <Monitor className="h-2.5 w-2.5 text-white" />
          </div>
        </div>
        <div className="w-full">
          <p className="truncate text-[10px] font-semibold leading-tight">{o.title}</p>
          <p className="truncate text-[9px] text-muted-foreground">{o.country ?? "All"}</p>
        </div>
        <div className="inline-flex items-center gap-1 rounded-md bg-primary/90 px-1.5 py-0.5 text-[10px] font-bold text-primary-foreground">
          <span className="flex h-2.5 w-2.5 items-center justify-center rounded-full bg-yellow-300 text-[7px] text-black">¢</span>
          {formatCoins(o.payout)}
        </div>
      </a>
    );
  };

  const row1 = offers.slice(0, 50);
  const row2 = offers.slice(50, 100);

  return (
    <section className="mt-5 w-full px-3 sm:mt-6 sm:px-6">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="flex items-center gap-2 text-lg font-bold sm:text-xl">
          <Rocket className="h-4 w-4 text-primary sm:h-5 sm:w-5" /> Popular Offers
        </h2>
        <div className="flex items-center gap-2">
          <Link to="/all-offers" className="text-xs text-primary sm:text-sm">View All</Link>
          <button onClick={() => scroll("left")} className="flex h-6 w-6 items-center justify-center rounded-md border border-white/10 bg-white/5 text-foreground/80 transition hover:border-primary/40" aria-label="Previous">
            <ChevronLeft className="h-3.5 w-3.5" />
          </button>
          <button onClick={() => scroll("right")} className="flex h-6 w-6 items-center justify-center rounded-md border border-white/10 bg-white/5 text-foreground/80 transition hover:border-primary/40" aria-label="Next">
            <ChevronRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {loading && (
        <div className="flex gap-2 overflow-hidden">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-[130px] w-[95px] shrink-0 animate-pulse rounded-xl bg-white/5" />
          ))}
        </div>
      )}

      {!loading && offers.length === 0 && (
        <p className="py-6 text-xs text-muted-foreground">No offers yet. Sync from admin → Notik Import.</p>
      )}

      {!loading && row1.length > 0 && (
        <div ref={row1Ref} className="mb-3 flex gap-2 overflow-x-auto pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {row1.map((o, i) => renderCard(o, i))}
        </div>
      )}
      {!loading && row2.length > 0 && (
        <div ref={row2Ref} className="flex gap-2 overflow-x-auto pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {row2.map((o, i) => renderCard(o, i + 10))}
        </div>
      )}
    </section>
  );
};

export default PopularOffers;
