import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Wallet,
  Gift,
  User,
  LogOut,
  Coins,
  Shield,
  ChevronDown,
  Users,
  Star,
  Building2,
  CreditCard,
  AlertTriangle,
  History,
  UserCog,
  KeyRound,
  Image as ImageIcon,
  LayoutGrid,
  Share2,
  Volume2,
  Palette,
  Activity,
  Images,
  Gauge,
  CheckCircle2,
  Download,
  DollarSign,
  Rocket,
  Handshake,
  BarChart3,
  Headphones,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useSiteSetting, withCacheBuster } from "@/hooks/useSiteSetting";
import { useAuthDialog } from "@/components/AuthDialogProvider";
import { useDesktopSidebar } from "@/hooks/useDesktopSidebar";

interface SubItem {
  to: string;
  label: string;
  badge?: number;
}

interface NavGroup {
  key: string;
  label: string;
  icon: typeof DollarSign;
  to?: string;
  subItems?: SubItem[];
}

const navGroups: NavGroup[] = [
  { key: "earn", label: "Earn", icon: DollarSign, to: "/" },
  {
    key: "offers",
    label: "Offers",
    icon: Rocket,
    subItems: [
      { to: "/all-offers", label: "All" },
      { to: "/all-offers?cat=games", label: "Games" },
      { to: "/all-offers?cat=surveys", label: "Surveys" },
      { to: "/all-offers?cat=others", label: "Others" },
    ],
  },
  {
    key: "partners",
    label: "Partners",
    icon: Handshake,
    subItems: [
      { to: "/all-offers?type=offers", label: "Offers" },
      { to: "/all-offers?type=surveys", label: "Surveys" },
    ],
  },
  { key: "cashout", label: "Cashout", icon: Wallet, to: "/withdraw" },
  { key: "ranking", label: "Ranking", icon: BarChart3, to: "/leaderboard" },
  { key: "affiliates", label: "Affiliates", icon: Users, to: "/profile" },
  { key: "support", label: "Support", icon: Headphones, to: "/profile" },
];

const adminItems = [
  { to: "/admin", label: "Overview", icon: Gauge },
  { to: "/admin/users", label: "All Users", icon: Users },
  { to: "/admin/withdraw", label: "Withdrawals", icon: Wallet },
  { to: "/admin/offers", label: "Complete Offers", icon: Gift },
  { to: "/admin/featured-offers", label: "Featured Offers", icon: Star },
  { to: "/admin/featured-banners", label: "Featured Banners", icon: Images },
  { to: "/admin/providers", label: "Providers", icon: Building2 },
  
  { to: "/admin/chargeback", label: "Chargeback", icon: AlertTriangle },
  { to: "/admin/postback-history", label: "Postback History", icon: History },
  
  { to: "/admin/roles", label: "Role Management", icon: UserCog },
  { to: "/admin/password", label: "Password Reset", icon: KeyRound },
  { to: "/admin/logo", label: "Logo", icon: ImageIcon },
  { to: "/admin/offerwall", label: "Offerwall", icon: LayoutGrid },
  { to: "/admin/social", label: "Social Links", icon: Share2 },
  { to: "/admin/sound", label: "Sound", icon: Volume2 },
  { to: "/admin/background", label: "Background", icon: Palette },
  { to: "/admin/live-tracker", label: "Live Tracker", icon: Activity },
  { to: "/admin/homepage-images", label: "Homepage Images", icon: Images },
];

const DesktopSidebar = () => {
  const { user, isAdmin, signOut } = useAuth();
  const location = useLocation();
  const { open: openAuth } = useAuthDialog();
  const { visible } = useDesktopSidebar();
  const [openGroup, setOpenGroup] = useState<string | null>("offers");
  const [adminOpen, setAdminOpen] = useState(false);

  const { value: logoCfg, version: logoVersion } = useSiteSetting<{ url: string; text: string }>(
    "site_logo",
    { url: "", text: "COINTO" }
  );
  const logoUrl = withCacheBuster(logoCfg.url, logoVersion);

  const isActive = (to?: string) =>
    !!to && (to === "/" ? location.pathname === "/" : location.pathname.startsWith(to.split("?")[0]));

  if (!visible) return null;

  return (
    <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-white/10 bg-neutral-900/95 backdrop-blur-md lg:flex">
      {/* Logo */}
      <Link to="/" className="flex items-center border-b border-white/10 px-5 py-4">
        {logoUrl ? (
          <img
            src={logoUrl}
            alt={logoCfg.text || "Logo"}
            className="h-10 w-auto object-contain"
          />
        ) : (
          <span className="text-lg font-extrabold tracking-tight text-primary">
            {logoCfg.text || "COINTO"}
          </span>
        )}
      </Link>

      {/* Nav */}
      <div className="flex flex-1 flex-col gap-1 overflow-y-auto px-3 py-3">
        {navGroups.map((g) => {
          const Icon = g.icon;
          const active = isActive(g.to);
          const isOpen = openGroup === g.key;

          if (g.subItems) {
            return (
              <div key={g.key} className="flex flex-col">
                <button
                  onClick={() => setOpenGroup(isOpen ? null : g.key)}
                  className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-all duration-300 ease-out ${
                    isOpen ? "bg-primary/10 text-primary translate-x-0.5" : "text-foreground/90 hover:bg-white/5 hover:translate-x-0.5"
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span className="flex-1 text-left">{g.label}</span>
                  <ChevronDown
                    className={`h-4 w-4 transition-transform ${isOpen ? "rotate-180" : ""}`}
                  />
                </button>
                {isOpen && (
                  <div className="ml-4 mt-1 flex flex-col gap-0.5 border-l border-white/10 pl-3">
                    {g.subItems.map((s) => (
                      <Link
                        key={s.to}
                        to={s.to}
                        className="flex items-center gap-3 rounded-lg px-2 py-1.5 text-sm text-foreground/80 transition hover:bg-white/5 hover:text-foreground"
                      >
                        <span className="h-1.5 w-1.5 rounded-full border border-foreground/30" />
                        <span className="flex-1">{s.label}</span>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            );
          }

          return (
            <Link
              key={g.key}
              to={g.to!}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-all duration-300 ease-out ${
                active
                  ? "bg-primary text-primary-foreground translate-x-1"
                  : "text-foreground/90 hover:bg-white/5 hover:translate-x-0.5"
              }`}
            >
              <Icon className="h-5 w-5" />
              <span className="flex-1">{g.label}</span>
            </Link>
          );
        })}

        {isAdmin && (
          <div className="mt-3 border-t border-white/10 pt-3">
            <button
              onClick={() => setAdminOpen((v) => !v)}
              className="flex w-full items-center gap-3 rounded-xl bg-primary/10 px-3 py-2.5 text-sm font-bold text-primary transition hover:bg-primary/20"
            >
              <Shield className="h-5 w-5" />
              <span className="flex-1 text-left">Admin Panel</span>
              <ChevronDown
                className={`h-4 w-4 transition-transform ${adminOpen ? "rotate-180" : ""}`}
              />
            </button>
            {adminOpen && (
              <div className="mt-1 flex flex-col gap-0.5 border-l border-primary/30 pl-2">
                {adminItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.to}
                      to={item.to}
                      className="flex items-center gap-3 rounded-lg px-3 py-1.5 text-xs font-medium text-muted-foreground transition hover:bg-white/5 hover:text-foreground"
                    >
                      <Icon className="h-4 w-4" />
                      <span>{item.label}</span>
                    </Link>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="border-t border-white/10 px-3 py-3">
        {user ? (
          <button
            onClick={() => signOut()}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 py-2.5 text-sm font-semibold transition hover:bg-white/5"
          >
            <LogOut className="h-4 w-4" /> Sign Out
          </button>
        ) : (
          <div className="flex flex-col gap-2">
            <button
              onClick={() => openAuth("signin")}
              className="rounded-xl border border-white/20 py-2.5 text-sm font-semibold transition hover:bg-white/5"
            >
              Sign In
            </button>
            <button
              onClick={() => openAuth("signup")}
              className="rounded-xl bg-primary py-2.5 text-sm font-bold text-primary-foreground transition hover:opacity-90"
            >
              Create Account
            </button>
          </div>
        )}
      </div>
    </aside>
  );
};

export default DesktopSidebar;
