import { FormEvent, useState } from "react";
import { z } from "zod";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";
import { Coins, LogOut, LayoutDashboard, Eye, EyeOff, Mail, Lock, User } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";

const emailSchema = z
  .string()
  .trim()
  .min(1, { message: "Email is required" })
  .email({ message: "Invalid email address" })
  .max(255);

const passwordSigninSchema = z.string().min(1, { message: "Password is required" }).max(72);

const passwordSignupSchema = z
  .string()
  .min(8, { message: "Password must be at least 8 characters" })
  .max(72)
  .regex(/[A-Za-z]/, { message: "Password must contain a letter" })
  .regex(/[0-9]/, { message: "Password must contain a number" });

const displayNameSchema = z.string().trim().min(1, { message: "Name is required" }).max(50);

interface FieldErrors {
  email?: string;
  password?: string;
  displayName?: string;
  agree?: string;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialMode?: "signin" | "signup";
}

const AuthDialog = ({ open, onOpenChange, initialMode = "signin" }: Props) => {
  const [mode, setMode] = useState<"signin" | "signup">(initialMode);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(false);
  const [agree, setAgree] = useState(false);
  const [busy, setBusy] = useState(false);
  const [googleBusy, setGoogleBusy] = useState(false);
  const [errors, setErrors] = useState<FieldErrors>({});
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  const isSignIn = mode === "signin";

  const switchMode = (m: "signin" | "signup") => {
    setMode(m);
    setErrors({});
  };

  const validate = (): FieldErrors => {
    const next: FieldErrors = {};
    const emailResult = emailSchema.safeParse(email);
    if (!emailResult.success) next.email = emailResult.error.issues[0].message;

    const pwSchema = mode === "signup" ? passwordSignupSchema : passwordSigninSchema;
    const pwResult = pwSchema.safeParse(password);
    if (!pwResult.success) next.password = pwResult.error.issues[0].message;

    if (mode === "signup") {
      const dnResult = displayNameSchema.safeParse(displayName);
      if (!dnResult.success) next.displayName = dnResult.error.issues[0].message;
      if (!agree) next.agree = "You must agree to the privacy policy";
    }
    return next;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const fieldErrors = validate();
    setErrors(fieldErrors);
    if (Object.keys(fieldErrors).length > 0) return;

    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/dashboard`,
            data: { display_name: displayName.trim() || email.split("@")[0] },
          },
        });
        if (error) throw error;
        toast({ title: "Account created", description: "Welcome to COINTO!" });
        onOpenChange(false);
        navigate("/dashboard");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        toast({ title: "Signed in" });
        onOpenChange(false);
        navigate("/dashboard");
      }
      setEmail(""); setPassword(""); setDisplayName(""); setErrors({});
    } catch (err: any) {
      toast({ title: "Auth error", description: err.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const handleGoogle = async () => {
    setGoogleBusy(true);
    try {
      const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
      if (result.error) {
        toast({ title: "Google sign-in failed", description: result.error.message, variant: "destructive" });
        setGoogleBusy(false);
        return;
      }
      if (result.redirected) return;
      onOpenChange(false);
    } catch (err: any) {
      toast({ title: "Google sign-in failed", description: err?.message ?? "Unknown error", variant: "destructive" });
    } finally {
      setGoogleBusy(false);
    }
  };

  const handleReset = async () => {
    if (!email) {
      toast({ title: "Email lagbe", description: "Email field e email din", variant: "destructive" });
      return;
    }
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    toast(
      error
        ? { title: "Error", description: error.message, variant: "destructive" }
        : { title: "Reset link pathano hoyeche", description: "Email check korun" },
    );
  };

  // Logged-in state
  if (user) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="w-[310px] max-w-[310px] border-white/10 bg-background p-5">
          <div className="mb-4 flex items-center gap-2 text-base font-bold">
            <Coins className="h-5 w-5 text-primary" />
            <span className="truncate">{user.email}</span>
          </div>
          <div className="flex flex-col gap-2">
            <Link
              to="/dashboard"
              onClick={() => onOpenChange(false)}
              className="flex items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground transition hover:opacity-90"
            >
              <LayoutDashboard className="h-4 w-4" /> Go to Dashboard
            </Link>
            <button
              onClick={async () => { await signOut(); onOpenChange(false); }}
              className="flex items-center justify-center gap-2 rounded-xl border border-white/10 py-3 text-sm font-semibold transition hover:bg-white/5"
            >
              <LogOut className="h-4 w-4" /> Sign Out
            </button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  const GoogleIcon = () => (
    <svg className="h-4 w-4" viewBox="0 0 48 48" aria-hidden>
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.6 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 12.95 4 4 12.95 4 24s8.95 20 20 20 20-8.95 20-20c0-1.3-.1-2.3-.4-3.5z"/>
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 16 19 13 24 13c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/>
      <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35 26.7 36 24 36c-5.1 0-9.6-3.4-11.2-8l-6.5 5C9.6 39.6 16.2 44 24 44z"/>
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.2-4.1 5.6l6.2 5.2C41 35.6 44 30.3 44 24c0-1.3-.1-2.3-.4-3.5z"/>
    </svg>
  );

  const inputCls = (err?: string) =>
    `w-full rounded-lg border bg-white/[0.03] pl-9 pr-3 py-2.5 text-sm outline-none transition focus:bg-white/[0.05] placeholder:text-muted-foreground/60 ${
      err ? "border-destructive focus:border-destructive" : "border-white/10 focus:border-primary"
    }`;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[310px] max-w-[310px] gap-0 overflow-hidden border-white/10 bg-[#0d1620] p-5">
        {/* Header */}
        <div className="mb-4">
          <h2 className="text-xl font-extrabold tracking-tight">{isSignIn ? "Sign In" : "Sign Up"}</h2>
          <p className="mt-0.5 text-xs text-muted-foreground">
            {isSignIn ? "Sign in to your account" : "Create a new account"}
          </p>
        </div>

        {/* Tab switcher */}
        <div className="mb-4 grid grid-cols-2 gap-1 rounded-xl bg-white/[0.04] p-1">
          <button
            type="button"
            onClick={() => switchMode("signin")}
            className={`rounded-lg py-2 text-xs font-bold transition ${
              isSignIn ? "bg-primary text-primary-foreground shadow" : "text-foreground/80 hover:text-foreground"
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => switchMode("signup")}
            className={`rounded-lg py-2 text-xs font-bold transition ${
              !isSignIn ? "bg-primary text-primary-foreground shadow" : "text-foreground/80 hover:text-foreground"
            }`}
          >
            Sign Up
          </button>
        </div>

        {/* Sign-in: Google on top */}
        {isSignIn && (
          <>
            <button
              type="button"
              onClick={handleGoogle}
              disabled={googleBusy}
              className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] py-2.5 text-xs font-bold transition hover:bg-white/[0.06] disabled:opacity-60"
            >
              <GoogleIcon />
              {googleBusy ? "Redirecting…" : "Login with Google"}
            </button>
            <div className="my-4 flex items-center gap-3">
              <div className="h-px flex-1 bg-white/10" />
              <span className="text-[10px] font-bold tracking-widest text-muted-foreground">OR</span>
              <div className="h-px flex-1 bg-white/10" />
            </div>
          </>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-3">
          {!isSignIn && (
            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold">Name</label>
              <div className="relative">
                <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Name"
                  value={displayName}
                  onChange={(e) => { setDisplayName(e.target.value); if (errors.displayName) setErrors((p) => ({ ...p, displayName: undefined })); }}
                  className={inputCls(errors.displayName)}
                />
              </div>
              {errors.displayName && <p className="text-[11px] font-semibold text-destructive">{errors.displayName}</p>}
            </div>
          )}

          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold">Email</label>
            <div className="relative">
              <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => { setEmail(e.target.value); if (errors.email) setErrors((p) => ({ ...p, email: undefined })); }}
                className={inputCls(errors.email)}
              />
            </div>
            {errors.email && <p className="text-[11px] font-semibold text-destructive">{errors.email}</p>}
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold">Password</label>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Password"
                value={password}
                onChange={(e) => { setPassword(e.target.value); if (errors.password) setErrors((p) => ({ ...p, password: undefined })); }}
                className={`${inputCls(errors.password)} pr-9`}
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            {errors.password && <p className="text-[11px] font-semibold text-destructive">{errors.password}</p>}
          </div>

          {isSignIn ? (
            <div className="flex items-center justify-between gap-2">
              <label className="flex cursor-pointer items-center gap-1.5 text-xs font-semibold">
                <input
                  type="checkbox"
                  checked={remember}
                  onChange={(e) => setRemember(e.target.checked)}
                  className="h-3.5 w-3.5 cursor-pointer rounded border-white/20 bg-white/5 accent-primary"
                />
                Remember me
              </label>
              <button type="button" onClick={handleReset} className="text-xs font-bold text-primary hover:underline">
                Forgot Password?
              </button>
            </div>
          ) : (
            <div>
              <label className="flex cursor-pointer items-start gap-2 text-xs font-semibold">
                <input
                  type="checkbox"
                  checked={agree}
                  onChange={(e) => { setAgree(e.target.checked); if (errors.agree) setErrors((p) => ({ ...p, agree: undefined })); }}
                  className="mt-0.5 h-3.5 w-3.5 cursor-pointer rounded border-white/20 bg-white/5 accent-primary"
                />
                <span>
                  I agree with{" "}
                  <Link to="/privacy" onClick={() => onOpenChange(false)} className="font-bold text-primary hover:underline">
                    privacy policy
                  </Link>
                </span>
              </label>
              {errors.agree && <p className="mt-1 text-[11px] font-semibold text-destructive">{errors.agree}</p>}
            </div>
          )}

          <button
            type="submit"
            disabled={busy}
            className="mt-1 rounded-lg bg-primary py-3 text-sm font-extrabold uppercase tracking-wide text-primary-foreground transition hover:opacity-90 disabled:opacity-50"
          >
            {busy ? "Please wait…" : isSignIn ? "Sign In" : "Register"}
          </button>
        </form>

        <p className="mt-3 text-center text-xs font-semibold">
          {isSignIn ? (
            <>
              <span className="text-foreground">Dont have Account? </span>
              <button type="button" onClick={() => switchMode("signup")} className="font-bold text-primary hover:underline">
                Create account
              </button>
            </>
          ) : (
            <>
              <span className="text-foreground">Already have an account? </span>
              <button type="button" onClick={() => switchMode("signin")} className="font-bold text-primary hover:underline">
                Sign In
              </button>
            </>
          )}
        </p>

        {/* Sign-up: Google at bottom */}
        {!isSignIn && (
          <>
            <div className="my-4 flex items-center gap-3">
              <div className="h-px flex-1 bg-white/10" />
              <span className="text-[10px] font-bold tracking-widest text-muted-foreground">OR SIGN IN WITH OTHERS</span>
              <div className="h-px flex-1 bg-white/10" />
            </div>
            <button
              type="button"
              onClick={handleGoogle}
              disabled={googleBusy}
              className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] py-2.5 text-xs font-bold transition hover:bg-white/[0.06] disabled:opacity-60"
            >
              <GoogleIcon />
              {googleBusy ? "Redirecting…" : "Login with Google"}
            </button>
          </>
        )}

        <p className="mt-4 text-center text-[10px] leading-relaxed text-muted-foreground">
          {isSignIn ? (
            <>
              By signing in, you are agreeing to our{" "}
              <Link to="/terms" onClick={() => onOpenChange(false)} className="font-bold text-primary hover:underline">Terms of Service</Link>{" "}
              and{" "}
              <Link to="/privacy" onClick={() => onOpenChange(false)} className="font-bold text-primary hover:underline">Privacy Policy</Link>.{" "}
            </>
          ) : null}
          Users are prohibited from using multiple accounts, completing offers on another user's account, or using any type of VPN, VPS, or Emulator software.
        </p>
      </DialogContent>
    </Dialog>
  );
};

export default AuthDialog;
