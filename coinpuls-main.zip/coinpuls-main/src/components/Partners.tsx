import { useEffect, useState } from "react";
import { Handshake, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useAuth } from "@/hooks/useAuth";
import { useAuthDialog } from "@/components/AuthDialogProvider";
import { useSiteSetting, withCacheBuster } from "@/hooks/useSiteSetting";

interface Provider {
  id: string;
  name: string;
  slug: string;
  logo_url: string | null;
  description: string | null;
  config: Record<string, unknown> | null;
}

const Partners = () => {
  const [providers, setProviders] = useState<Provider[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState<Provider | null>(null);
  const [iframeLoaded, setIframeLoaded] = useState(false);
  const { user } = useAuth();
  const { open: openAuth } = useAuthDialog();
  const { value: logoCfg, version: logoVersion } = useSiteSetting<{ url: string; text: string; avatarUrl: string }>(
    "site_logo",
    { url: "", text: "COINTO", avatarUrl: "" }
  );
  const splashLogo = withCacheBuster(logoCfg.url || logoCfg.avatarUrl, logoVersion);

  useEffect(() => {
    setIframeLoaded(false);
  }, [active?.id]);


  useEffect(() => {
    let mounted = true;
    (async () => {
      const { data } = await supabase
        .from("providers")
        .select("id, name, slug, logo_url, description, config")
        .eq("is_enabled", true)
        .order("sort_order", { ascending: true })
        .order("name", { ascending: true });
      if (mounted) {
        setProviders((data ?? []) as Provider[]);
        setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  const rawUrl = active
    ? ((active.config ?? {}) as Record<string, string>).click_url ?? ""
    : "";
  const appId = active
    ? ((active.config ?? {}) as Record<string, string>).app_id ?? ""
    : "";
  const activeUrl = rawUrl
    .replace(/\{user_id\}/gi, user?.id ?? "")
    .replace(/\[USER_ID\]/gi, user?.id ?? "")
    .replace(/\{YOUR_USER_ID\}/gi, user?.id ?? "")
    .replace(/\{app_id\}/gi, appId);

  if (loading) {
    return (
      <section className="mt-5 px-4 sm:mt-6 sm:px-6">
        <h2 className="mb-3 flex items-center gap-2 text-lg font-bold sm:text-xl">
          <Handshake className="h-4 w-4 text-primary sm:h-5 sm:w-5" /> Offer Partners
        </h2>
        <div className="grid grid-cols-4 gap-2 sm:grid-cols-4 sm:gap-3 md:grid-cols-5 lg:grid-cols-7">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="glass-card h-16 animate-pulse rounded-xl bg-white/5" />
          ))}
        </div>
      </section>
    );
  }

  if (providers.length === 0) return null;

  return (
    <section className="mt-5 px-4 sm:mt-6 sm:px-6">
      <h2 className="mb-3 flex items-center gap-2 text-lg font-bold sm:text-xl">
        <Handshake className="h-4 w-4 text-primary sm:h-5 sm:w-5" /> Offer Partners
      </h2>
      <div className="grid grid-cols-4 gap-2 sm:grid-cols-4 sm:gap-3 md:grid-cols-5 lg:grid-cols-7">
        {providers.map((p) => (
          <button
            key={p.id}
            onClick={() => (user ? setActive(p) : openAuth("signup"))}
            className="glass-card gradient-border-bottom flex flex-col items-start justify-between rounded-xl border border-white/5 p-3 text-left transition hover:border-primary/40 hover:scale-[1.02] sm:p-4 lg:h-36"
          >
            <div className="flex w-full flex-1 items-center justify-center py-2">
              {p.logo_url ? (
                <img
                  src={p.logo_url}
                  alt={p.name}
                  className="max-h-12 w-auto max-w-full object-contain sm:max-h-14 lg:max-h-16"
                  loading="lazy"
                />
              ) : (
                <div className="flex h-12 items-center justify-center text-sm font-bold uppercase text-primary sm:h-14">
                  {p.name.slice(0, 2)}
                </div>
              )}
            </div>
            <div className="w-full">
              <p className="truncate text-xs font-bold sm:text-sm">{p.name}</p>
              <p className="mt-0.5 text-[10px] text-yellow-400 sm:text-xs">★★★★★</p>
            </div>
          </button>
        ))}
      </div>

      <Dialog open={!!active} onOpenChange={(o) => !o && setActive(null)}>
        <DialogContent
          className="flex h-[90vh] max-h-[90vh] w-[95vw] max-w-3xl flex-col gap-0 overflow-hidden border-white/10 bg-background p-0"
        >
          {/* Header with provider logo */}
          <div className="flex items-center justify-between gap-3 border-b border-white/10 bg-card/60 px-4 py-3">
            <div className="flex items-center gap-3">
              {active?.logo_url ? (
                <img
                  src={active.logo_url}
                  alt={active.name}
                  className="h-9 w-9 rounded-lg bg-white/5 object-contain p-0.5"
                />
              ) : (
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-xs font-bold uppercase text-primary">
                  {active?.name.slice(0, 2)}
                </div>
              )}
              <div className="text-left">
                <p className="text-sm font-extrabold leading-tight">{active?.name}</p>
                <p className="text-[10px] uppercase tracking-widest text-muted-foreground">
                  Offerwall
                </p>
              </div>
            </div>
            <button
              onClick={() => setActive(null)}
              className="rounded-full p-1 text-muted-foreground transition hover:bg-white/10 hover:text-foreground"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Iframe body */}
          <div className="relative flex-1 overflow-hidden bg-black">
            {activeUrl ? (
              <>
                <iframe
                  key={active?.id}
                  src={activeUrl}
                  title={active?.name}
                  onLoad={() => setIframeLoaded(true)}
                  className={`h-full w-full border-0 transition-opacity duration-300 ${iframeLoaded ? "opacity-100" : "opacity-0"}`}
                  allow="clipboard-write; fullscreen"
                />
                {!iframeLoaded && (
                  <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-5 bg-gradient-to-br from-background via-background to-primary/10">
                    {splashLogo ? (
                      <img
                        src={splashLogo}
                        alt={logoCfg.text || "Loading"}
                        className="h-20 w-auto animate-pulse object-contain drop-shadow-[0_0_30px_hsl(var(--primary)/0.6)]"
                      />
                    ) : (
                      <span className="animate-pulse text-3xl font-extrabold tracking-tight text-primary drop-shadow-[0_0_30px_hsl(var(--primary)/0.6)]">
                        {logoCfg.text || "MONEYGAINE"}
                      </span>
                    )}
                    <div className="flex items-center gap-2">
                      <span className="h-2 w-2 animate-bounce rounded-full bg-primary [animation-delay:-0.3s]" />
                      <span className="h-2 w-2 animate-bounce rounded-full bg-primary [animation-delay:-0.15s]" />
                      <span className="h-2 w-2 animate-bounce rounded-full bg-primary" />
                    </div>
                    <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Loading offerwall…</p>
                  </div>
                )}
              </>
            ) : (
              <div className="flex h-full items-center justify-center p-6 text-center text-sm text-muted-foreground">
                No offer available
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default Partners;
