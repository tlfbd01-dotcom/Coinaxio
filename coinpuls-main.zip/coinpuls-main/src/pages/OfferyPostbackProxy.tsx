import { useEffect } from "react";

// Backwards-compat redirect. Real postbacks should target the edge function URL directly.
const OfferyPostbackProxy = () => {
  useEffect(() => {
    const url = new URL(window.location.href);
    const projectRef = (import.meta.env.VITE_SUPABASE_URL ?? "").match(/https:\/\/([^.]+)/)?.[1];
    if (projectRef) {
      const target = `https://${projectRef}.supabase.co/functions/v1/offery-postback${url.search}`;
      window.location.replace(target);
    }
  }, []);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4 text-center text-xs text-muted-foreground">
      Postbacks should be sent to the edge function endpoint /functions/v1/offery-postback.
    </div>
  );
};

export default OfferyPostbackProxy;
