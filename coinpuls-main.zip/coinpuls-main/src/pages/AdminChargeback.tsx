import AdminShell from "@/components/AdminShell";
const AdminChargeback = () => <AdminShell title="Chargebacks" description="Track and resolve chargebacks" />;
export default AdminChargeback;
