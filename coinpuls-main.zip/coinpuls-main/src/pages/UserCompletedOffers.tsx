import { useEffect, useState } from "react";
import PageShell from "@/components/PageShell";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { formatCoins } from "@/lib/coins";

interface Item {
  id: string;
  title: string | null;
  payout: number;
  status: string;
  created_at: string;
}

const UserCompletedOffers = () => {
  const { user } = useAuth();
  const [items, setItems] = useState<Item[]>([]);

  useEffect(() => {
    if (!user) return;
    const load = () => {
      supabase
        .from("completed_offers")
        .select("id, title, payout, status, created_at")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .then(({ data }) => setItems(data ?? []));
    };
    load();

    const channel = supabase
      .channel(`completed_offers_${user.id}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "completed_offers", filter: `user_id=eq.${user.id}` },
        () => load()
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  return (
    <PageShell title="My Offers" subtitle="Completed offers history">
      <div className="flex flex-col gap-2">
        {items.length === 0 && (
          <p className="text-center text-xs text-muted-foreground">No completed offers yet.</p>
        )}
        {items.map((o) => (
          <div key={o.id} className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-4 py-3">
            <div>
              <p className="text-sm font-semibold">{o.title ?? "Offer"}</p>
              <p className="text-xs text-muted-foreground">{new Date(o.created_at).toLocaleDateString()}</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-bold text-primary">+{formatCoins(o.payout)}</p>
              <p className="text-[10px] uppercase text-muted-foreground">{o.status}</p>
            </div>
          </div>
        ))}
      </div>
    </PageShell>
  );
};

export default UserCompletedOffers;
