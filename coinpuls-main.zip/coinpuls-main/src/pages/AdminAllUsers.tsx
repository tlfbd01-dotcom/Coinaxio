import { useEffect, useMemo, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { UserDetailsDialog, EditUserDialog } from "@/components/admin/UserDialogs";
import {
  Users,
  Search,
  RefreshCw,
  Eye,
  Pencil,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
} from "lucide-react";

interface UserRow {
  user_id: string;
  email: string | null;
  display_name: string | null;
  username: string | null;
  balance: number;
  total_earned: number;
  is_banned: boolean;
  created_at: string;
}

const PAGE_SIZE = 15;

const AdminAllUsers = () => {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [q, setQ] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [viewUser, setViewUser] = useState<UserRow | null>(null);
  const [editUser, setEditUser] = useState<UserRow | null>(null);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase.rpc("admin_list_users");
    setLoading(false);
    if (error) {
      toast({ title: "Failed to load users", description: error.message, variant: "destructive" });
      return;
    }
    setUsers((data as UserRow[]) ?? []);
  };

  useEffect(() => {
    load();
  }, []);

  const toggleBan = async (id: string, banned: boolean) => {
    const { error } = await supabase
      .from("profiles")
      .update({ is_banned: !banned })
      .eq("user_id", id);
    if (error) {
      toast({ title: "Update failed", description: error.message, variant: "destructive" });
      return;
    }
    load();
  };

  const filtered = useMemo(() => {
    const ql = q.trim().toLowerCase();
    return users.filter((u) => {
      if (ql) {
        const hay = `${u.username ?? ""} ${u.display_name ?? ""} ${u.email ?? ""}`.toLowerCase();
        if (!hay.includes(ql)) return false;
      }
      const t = new Date(u.created_at).getTime();
      if (from && t < new Date(from).getTime()) return false;
      if (to && t > new Date(to).getTime() + 86_399_000) return false;
      return true;
    });
  }, [users, q, from, to]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const slice = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);
  const startIndex = (safePage - 1) * PAGE_SIZE;

  const totalBalance = users.reduce((a, u) => a + Number(u.balance ?? 0), 0);

  const fmtDate = (s: string) => {
    const d = new Date(s);
    return `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()}`;
  };
  const money = (n: number) =>
    `${(n * 1000).toLocaleString(undefined, { maximumFractionDigits: 0 })} coins`;

  return (
    <AdminShell title="Users" description="Manage platform users">
      <div className="flex flex-col gap-4 pb-10">
        {/* Header bar */}
        <div className="rounded-2xl border border-white/10 bg-neutral-900/60 p-4 sm:p-5">
          <div className="mb-4 flex items-center justify-between gap-2">
            <h2 className="flex items-center gap-2 text-base font-bold text-primary sm:text-lg">
              <Users className="h-5 w-5" /> All Users ({users.length})
            </h2>
            <button
              onClick={load}
              disabled={loading}
              className="rounded-lg border border-white/10 bg-white/5 p-2 text-muted-foreground transition hover:text-foreground disabled:opacity-50"
              aria-label="Refresh"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            </button>
          </div>

          {/* Filters */}
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                placeholder="Search username or email..."
                value={q}
                onChange={(e) => {
                  setQ(e.target.value);
                  setPage(1);
                }}
                className="w-full rounded-full border border-white/10 bg-black/40 py-2 pl-9 pr-3 text-sm outline-none focus:border-primary"
              />
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span>From:</span>
              <input
                type="date"
                value={from}
                onChange={(e) => {
                  setFrom(e.target.value);
                  setPage(1);
                }}
                className="rounded-md border border-white/10 bg-black/40 px-2 py-1.5 text-xs outline-none focus:border-primary"
              />
              <span>To:</span>
              <input
                type="date"
                value={to}
                onChange={(e) => {
                  setTo(e.target.value);
                  setPage(1);
                }}
                className="rounded-md border border-white/10 bg-black/40 px-2 py-1.5 text-xs outline-none focus:border-primary"
              />
            </div>
          </div>

          {/* Table */}
          <div className="mt-4 overflow-x-auto rounded-xl border border-white/10 bg-black/30">
            <table className="w-full min-w-[760px] text-left text-xs">
              <thead className="text-[11px] uppercase tracking-wider text-primary/90">
                <tr className="border-b border-white/10">
                  <th className="px-3 py-2.5">#</th>
                  <th className="px-3 py-2.5">Date</th>
                  <th className="px-3 py-2.5">Username</th>
                  <th className="px-3 py-2.5">Email</th>
                  <th className="px-3 py-2.5">Balance</th>
                  <th className="px-3 py-2.5">Last IP</th>
                  <th className="px-3 py-2.5">Device</th>
                  <th className="px-3 py-2.5">Status</th>
                  <th className="px-3 py-2.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                {slice.map((u, i) => (
                  <tr
                    key={u.user_id}
                    className="border-b border-white/5 transition hover:bg-white/5"
                  >
                    <td className="px-3 py-2.5 text-muted-foreground">{startIndex + i + 1}</td>
                    <td className="px-3 py-2.5 text-muted-foreground">{fmtDate(u.created_at)}</td>
                    <td className="px-3 py-2.5 font-semibold">{u.username ?? "—"}</td>
                    <td className="px-3 py-2.5 text-muted-foreground">{u.email ?? "—"}</td>
                    <td className="px-3 py-2.5 font-bold text-primary">
                      {money(Number(u.balance))}
                    </td>
                    <td className="px-3 py-2.5 text-muted-foreground">N/A</td>
                    <td className="px-3 py-2.5 text-muted-foreground">N/A</td>
                    <td className="px-3 py-2.5">
                      <span
                        className={`rounded-md px-2 py-0.5 text-[10px] font-bold ${
                          u.is_banned
                            ? "bg-destructive/20 text-destructive"
                            : "bg-primary/20 text-primary"
                        }`}
                      >
                        {u.is_banned ? "BANNED" : "ACTIVE"}
                      </span>
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => setViewUser(u)}
                          className="text-primary/80 transition hover:text-primary"
                          aria-label="View"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => setEditUser(u)}
                          className="text-primary/80 transition hover:text-primary"
                          aria-label="Edit"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {slice.length === 0 && (
                  <tr>
                    <td colSpan={9} className="px-3 py-8 text-center text-muted-foreground">
                      {loading ? "Loading…" : "No users found."}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="mt-3 flex items-center justify-center gap-1.5 text-xs">
            <button
              onClick={() => setPage(1)}
              disabled={safePage === 1}
              className="rounded-md p-1.5 text-muted-foreground transition hover:bg-white/5 disabled:opacity-30"
            >
              <ChevronsLeft className="h-4 w-4" />
            </button>
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={safePage === 1}
              className="rounded-md p-1.5 text-muted-foreground transition hover:bg-white/5 disabled:opacity-30"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="rounded-md bg-primary px-3 py-1 font-bold text-primary-foreground">
              {safePage} / {totalPages}
            </span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={safePage === totalPages}
              className="rounded-md p-1.5 text-muted-foreground transition hover:bg-white/5 disabled:opacity-30"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
            <button
              onClick={() => setPage(totalPages)}
              disabled={safePage === totalPages}
              className="rounded-md p-1.5 text-muted-foreground transition hover:bg-white/5 disabled:opacity-30"
            >
              <ChevronsRight className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Totals */}
        <div className="grid grid-cols-2 gap-3 rounded-2xl border border-white/10 bg-neutral-900/60 p-4 sm:p-5">
          <div className="flex flex-col gap-1">
            <span className="text-xs text-muted-foreground">Total Users</span>
            <span className="text-2xl font-extrabold text-primary">{users.length}</span>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-xs text-muted-foreground">Total Balance</span>
            <span className="text-2xl font-extrabold text-primary">{money(totalBalance)}</span>
          </div>
        </div>
      </div>

      <UserDetailsDialog
        user={viewUser}
        open={!!viewUser}
        onOpenChange={(v) => !v && setViewUser(null)}
      />
      <EditUserDialog
        user={editUser}
        open={!!editUser}
        onOpenChange={(v) => !v && setEditUser(null)}
        onSaved={load}
      />
    </AdminShell>
  );
};

export default AdminAllUsers;
