import { useEffect, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import {
  Users,
  CheckCircle2,
  DollarSign,
  Clock,
  Banknote,
  ArrowDownCircle,
  History,
  AlertTriangle,
  type LucideIcon,
} from "lucide-react";

interface Stats {
  users: number;
  completedOffers: number;
  totalRevenue: number;
  pendingWithdrawAmount: number;
  totalWithdrawn: number;
  pendingWithdrawCount: number;
  withdrawHistory: number;
  chargeback: number;
}

const initialStats: Stats = {
  users: 0,
  completedOffers: 0,
  totalRevenue: 0,
  pendingWithdrawAmount: 0,
  totalWithdrawn: 0,
  pendingWithdrawCount: 0,
  withdrawHistory: 0,
  chargeback: 0,
};

const AdminPanel = () => {
  const [stats, setStats] = useState<Stats>(initialStats);

  useEffect(() => {
    (async () => {
      const [
        users,
        completed,
        revenueRes,
        pendingAmtRes,
        paidAmtRes,
        pendingCount,
        historyCount,
        chargebackRes,
      ] = await Promise.all([
        supabase.from("profiles").select("id", { count: "exact", head: true }),
        supabase
          .from("completed_offers")
          .select("id", { count: "exact", head: true })
          .eq("status", "credited"),
        supabase.from("completed_offers").select("payout").eq("status", "credited"),
        supabase.from("withdrawals").select("amount").eq("status", "pending"),
        supabase.from("withdrawals").select("amount").eq("status", "paid"),
        supabase
          .from("withdrawals")
          .select("id", { count: "exact", head: true })
          .eq("status", "pending"),
        supabase.from("withdrawals").select("id", { count: "exact", head: true }),
        supabase.from("chargebacks").select("amount"),
      ]);

      const sum = (rows: { amount?: number; payout?: number }[] | null, key: "amount" | "payout") =>
        (rows ?? []).reduce((a, r) => a + Number((r as any)[key] ?? 0), 0);

      setStats({
        users: users.count ?? 0,
        completedOffers: completed.count ?? 0,
        totalRevenue: sum(revenueRes.data as any, "payout"),
        pendingWithdrawAmount: sum(pendingAmtRes.data as any, "amount"),
        totalWithdrawn: sum(paidAmtRes.data as any, "amount"),
        pendingWithdrawCount: pendingCount.count ?? 0,
        withdrawHistory: historyCount.count ?? 0,
        chargeback: sum(chargebackRes.data as any, "amount"),
      });
    })();
  }, []);

  const fmtMoney = (n: number) =>
    `$ ${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  type Card = {
    label: string;
    value: string;
    icon: LucideIcon;
    money?: boolean;
  };

  const cards: Card[] = [
    { label: "All users", value: String(stats.users), icon: Users },
    { label: "Completed Offers", value: String(stats.completedOffers), icon: CheckCircle2 },
    { label: "Total Revenue", value: fmtMoney(stats.totalRevenue), icon: CheckCircle2, money: true },
    {
      label: "Total pending Withdraw",
      value: `$ ${stats.pendingWithdrawAmount.toFixed(0)}`,
      icon: Clock,
      money: true,
    },
    { label: "Total Withdrawn", value: fmtMoney(stats.totalWithdrawn), icon: Banknote, money: true },
    {
      label: "Pending Withdraw",
      value: String(stats.pendingWithdrawCount),
      icon: ArrowDownCircle,
    },
    { label: "All withdraw History", value: String(stats.withdrawHistory), icon: History },
    {
      label: "Chargeback",
      value: `$ ${stats.chargeback.toFixed(0)}`,
      icon: AlertTriangle,
      money: true,
    },
  ];

  return (
    <AdminShell title="Dashboard" description="Overview of your platform">
      <h1 className="mb-4 text-2xl font-extrabold tracking-tight sm:text-3xl">Dashboard</h1>

      <div className="grid grid-cols-2 gap-3 sm:gap-4">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <div
              key={c.label}
              className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-neutral-900/60 p-4 transition hover:border-white/20"
            >
              <span className="text-xs font-medium text-muted-foreground sm:text-sm">
                {c.label}
              </span>
              <span className="text-2xl font-extrabold leading-none sm:text-3xl">{c.value}</span>
              <div className="flex items-center gap-1.5 text-xs font-semibold text-primary sm:text-sm">
                <Icon className="h-4 w-4" />
                <span className="truncate">{c.label}</span>
              </div>
            </div>
          );
        })}
      </div>
    </AdminShell>
  );
};

export default AdminPanel;
