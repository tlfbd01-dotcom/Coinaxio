import { useEffect, useRef, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Copy, Pencil, Plus, RefreshCw, Trash2, Upload, X } from "lucide-react";

interface ProviderRow {
  id: string;
  slug: string;
  name: string;
  description: string | null;
  logo_url: string | null;
  is_enabled: boolean;
  sort_order: number;
  config: Record<string, unknown>;
}

interface FormState {
  id?: string;
  name: string;
  slug: string;
  description: string;
  logo_url: string;
  is_enabled: boolean;
  sort_order: number;
  api_key: string;
  app_id: string;
  pub_id: string;
  secret: string;
  click_url: string;
  notes: string;
}

const emptyForm: FormState = {
  name: "",
  slug: "",
  description: "",
  logo_url: "",
  is_enabled: true,
  sort_order: 0,
  api_key: "",
  app_id: "",
  pub_id: "",
  secret: "",
  click_url: "",
  notes: "",
};

const slugify = (s: string) =>
  s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");

const AdminOfferwallCustomize = () => {
  const [providers, setProviders] = useState<ProviderRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const postbackBase = `${supabaseUrl}/functions/v1/provider-postback`;

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("providers")
      .select("*")
      .order("sort_order", { ascending: true })
      .order("name", { ascending: true });
    if (error) {
      toast.error(error.message);
    } else {
      setProviders((data ?? []) as ProviderRow[]);
    }
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const openCreate = () => {
    setForm(emptyForm);
    setShowForm(true);
  };

  const openEdit = (p: ProviderRow) => {
    const cfg = (p.config ?? {}) as Record<string, string>;
    setForm({
      id: p.id,
      name: p.name,
      slug: p.slug,
      description: p.description ?? "",
      logo_url: p.logo_url ?? "",
      is_enabled: p.is_enabled,
      sort_order: p.sort_order,
      api_key: cfg.api_key ?? "",
      app_id: cfg.app_id ?? "",
      pub_id: cfg.pub_id ?? "",
      secret: cfg.secret ?? "",
      click_url: cfg.click_url ?? "",
      notes: cfg.notes ?? "",
    });
    setShowForm(true);
  };

  const handleLogoUpload = async (file: File) => {
    if (!file) return;
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() || "png";
      const slug = form.slug || slugify(form.name) || `provider-${Date.now()}`;
      const path = `${slug}-${Date.now()}.${ext}`;
      const { error } = await supabase.storage
        .from("provider-logos")
        .upload(path, file, { upsert: true, contentType: file.type });
      if (error) throw error;
      const { data } = supabase.storage.from("provider-logos").getPublicUrl(path);
      setForm((f) => ({ ...f, logo_url: data.publicUrl }));
      toast.success("Logo uploaded");
    } catch (err: any) {
      toast.error(err.message ?? "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    if (!form.name.trim()) {
      toast.error("Name required");
      return;
    }
    const slug = form.slug.trim() || slugify(form.name);
    if (!slug) {
      toast.error("Slug required");
      return;
    }
    setSaving(true);
    const config = {
      api_key: form.api_key,
      app_id: form.app_id,
      pub_id: form.pub_id,
      secret: form.secret,
      click_url: form.click_url,
      notes: form.notes,
    };
    const payload = {
      name: form.name.trim(),
      slug,
      description: form.description || null,
      logo_url: form.logo_url || null,
      is_enabled: form.is_enabled,
      sort_order: form.sort_order || 0,
      config,
    };
    const res = form.id
      ? await supabase.from("providers").update(payload).eq("id", form.id)
      : await supabase.from("providers").insert(payload);
    setSaving(false);
    if (res.error) {
      toast.error(res.error.message);
      return;
    }
    toast.success(form.id ? "Provider updated" : "Provider added");
    setShowForm(false);
    setForm(emptyForm);
    load();
  };

  const handleDelete = async (p: ProviderRow) => {
    if (!confirm(`Delete provider "${p.name}"?`)) return;
    const { error } = await supabase.from("providers").delete().eq("id", p.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Deleted");
    load();
  };

  const toggleEnabled = async (p: ProviderRow) => {
    const { error } = await supabase
      .from("providers")
      .update({ is_enabled: !p.is_enabled })
      .eq("id", p.id);
    if (error) toast.error(error.message);
    else load();
  };

  const copy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard");
  };

  const [syncingId, setSyncingId] = useState<string | null>(null);
  const handleSync = async (p: ProviderRow) => {
    if (p.slug !== "notik") {
      toast.error("Sync currently supported only for Notik");
      return;
    }
    setSyncingId(p.id);
    try {
      const { data, error } = await supabase.functions.invoke("notik-sync", {
        body: { provider_id: p.id },
      });
      if (error) throw error;
      const d = data as any;
      if (d?.error) throw new Error(d.error);
      toast.success(`Synced: ${d?.inserted ?? 0} new, ${d?.updated ?? 0} updated`);
    } catch (err: any) {
      toast.error(err.message ?? "Sync failed");
    } finally {
      setSyncingId(null);
    }
  };

  return (
    <AdminShell title="Offerwall Customize" description="Manage offerwall providers, logos, API keys & postback URLs">
      <div className="space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold">Providers</h2>
            <p className="text-xs text-muted-foreground">{providers.length} total</p>
          </div>
          <Button size="sm" onClick={openCreate} className="gap-1.5">
            <Plus className="h-4 w-4" /> Add Provider
          </Button>
        </div>

        {loading ? (
          <div className="glass-card rounded-xl p-8 text-center text-sm text-muted-foreground">Loading…</div>
        ) : providers.length === 0 ? (
          <div className="glass-card rounded-xl p-8 text-center text-sm text-muted-foreground">
            No providers yet. Click "Add Provider" to start.
          </div>
        ) : (
          <div className="grid gap-3">
            {providers.map((p) => {
              const postbackUrl = `${postbackBase}/${p.slug}`;
              return (
                <div key={p.id} className="glass-card rounded-xl border border-white/5 p-4">
                  <div className="flex items-start gap-3">
                    {p.logo_url ? (
                      <img
                        src={p.logo_url}
                        alt={p.name}
                        className="h-12 w-12 rounded-lg object-cover"
                      />
                    ) : (
                      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-white/5 text-xs font-bold uppercase text-muted-foreground">
                        {p.name.slice(0, 2)}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold truncate">{p.name}</h3>
                        <span
                          className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                            p.is_enabled
                              ? "bg-emerald-500/20 text-emerald-400"
                              : "bg-white/10 text-muted-foreground"
                          }`}
                        >
                          {p.is_enabled ? "Active" : "Off"}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground truncate">slug: {p.slug}</p>
                      {p.description && <p className="mt-1 text-xs">{p.description}</p>}
                    </div>
                    <div className="flex items-center gap-1">
                      <Switch checked={p.is_enabled} onCheckedChange={() => toggleEnabled(p)} />
                    </div>
                  </div>

                  <div className="mt-3 rounded-lg bg-black/20 p-2.5">
                    <p className="mb-1 text-[10px] font-semibold uppercase text-muted-foreground">
                      Postback URL
                    </p>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 truncate text-[11px] text-primary">{postbackUrl}</code>
                      <button
                        onClick={() => copy(postbackUrl)}
                        className="rounded p-1 hover:bg-white/10"
                        aria-label="Copy"
                      >
                        <Copy className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="mt-3 flex gap-2">
                    <Button size="sm" variant="secondary" onClick={() => openEdit(p)} className="flex-1 gap-1.5">
                      <Pencil className="h-3.5 w-3.5" /> Edit
                    </Button>
                    {p.slug === "notik" && (
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => handleSync(p)}
                        disabled={syncingId === p.id}
                        className="gap-1.5"
                      >
                        <RefreshCw className={`h-3.5 w-3.5 ${syncingId === p.id ? "animate-spin" : ""}`} />
                        {syncingId === p.id ? "Syncing…" : "Sync"}
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(p)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {showForm && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 backdrop-blur sm:items-center sm:p-4"
          onClick={() => setShowForm(false)}
        >
          <div
            className="glass-card w-full max-w-lg overflow-hidden rounded-t-2xl border border-white/10 sm:rounded-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-white/5 p-4">
              <h3 className="font-bold">{form.id ? "Edit Provider" : "Add Provider"}</h3>
              <button onClick={() => setShowForm(false)} className="rounded-full p-1 hover:bg-white/10">
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="max-h-[70vh] space-y-4 overflow-y-auto p-4">
              <div className="flex items-center gap-3">
                {form.logo_url ? (
                  <img src={form.logo_url} alt="logo" className="h-16 w-16 rounded-lg object-cover" />
                ) : (
                  <div className="flex h-16 w-16 items-center justify-center rounded-lg bg-white/5 text-xs text-muted-foreground">
                    No logo
                  </div>
                )}
                <div className="flex-1">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => e.target.files?.[0] && handleLogoUpload(e.target.files[0])}
                  />
                  <Button
                    type="button"
                    size="sm"
                    variant="secondary"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploading}
                    className="gap-1.5"
                  >
                    <Upload className="h-3.5 w-3.5" />
                    {uploading ? "Uploading…" : "Upload Logo"}
                  </Button>
                  <p className="mt-1 text-[10px] text-muted-foreground">PNG/JPG/SVG, square preferred</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Name *</Label>
                  <Input
                    value={form.name}
                    onChange={(e) =>
                      setForm((f) => ({
                        ...f,
                        name: e.target.value,
                        slug: f.id ? f.slug : slugify(e.target.value),
                      }))
                    }
                    placeholder="CPX Research"
                  />
                </div>
                <div>
                  <Label className="text-xs">Slug *</Label>
                  <Input
                    value={form.slug}
                    onChange={(e) => setForm((f) => ({ ...f, slug: slugify(e.target.value) }))}
                    placeholder="cpx-research"
                  />
                </div>
              </div>

              <div>
                <Label className="text-xs">Description</Label>
                <Textarea
                  value={form.description}
                  onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                  rows={2}
                  placeholder="High-paying surveys"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Logo URL</Label>
                  <Input
                    value={form.logo_url}
                    onChange={(e) => setForm((f) => ({ ...f, logo_url: e.target.value }))}
                    placeholder="https://…"
                  />
                </div>
                <div>
                  <Label className="text-xs">Sort Order</Label>
                  <Input
                    type="number"
                    value={form.sort_order}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, sort_order: parseInt(e.target.value) || 0 }))
                    }
                  />
                </div>
              </div>

              <div className="space-y-3 rounded-xl border border-white/5 bg-black/20 p-3">
                <p className="text-xs font-semibold text-primary">Provider Credentials</p>
                <div>
                  <Label className="text-xs">App ID</Label>
                  <Input
                    value={form.app_id}
                    onChange={(e) => setForm((f) => ({ ...f, app_id: e.target.value }))}
                    placeholder="123456"
                  />
                </div>
                <div>
                  <Label className="text-xs">Publisher ID (pub_id)</Label>
                  <Input
                    value={form.pub_id}
                    onChange={(e) => setForm((f) => ({ ...f, pub_id: e.target.value }))}
                    placeholder="Notik publisher ID"
                  />
                </div>
                <div>
                  <Label className="text-xs">API Key</Label>
                  <Input
                    value={form.api_key}
                    onChange={(e) => setForm((f) => ({ ...f, api_key: e.target.value }))}
                    placeholder="sk_xxx…"
                    type="password"
                  />
                </div>
                <div>
                  <Label className="text-xs">Postback Secret</Label>
                  <Input
                    value={form.secret}
                    onChange={(e) => setForm((f) => ({ ...f, secret: e.target.value }))}
                    placeholder="Used to verify postback (optional)"
                    type="password"
                  />
                  <p className="mt-1 text-[10px] text-muted-foreground">
                    If set, postback must include `?secret=…` matching this value.
                  </p>
                </div>
                <div>
                  <Label className="text-xs">Click / Iframe URL</Label>
                  <Input
                    value={form.click_url}
                    onChange={(e) => setForm((f) => ({ ...f, click_url: e.target.value }))}
                    placeholder="https://offerwall.example.com/?uid={user_id}"
                  />
                  <p className="mt-1 text-[10px] text-muted-foreground">
                    Use {"{user_id}"} placeholder for user ID.
                  </p>
                </div>
                <div>
                  <Label className="text-xs">Notes</Label>
                  <Textarea
                    value={form.notes}
                    onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
                    rows={2}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between rounded-xl border border-white/5 p-3">
                <div>
                  <p className="text-sm font-semibold">Enabled</p>
                  <p className="text-[11px] text-muted-foreground">Show on homepage offerwall list</p>
                </div>
                <Switch
                  checked={form.is_enabled}
                  onCheckedChange={(v) => setForm((f) => ({ ...f, is_enabled: v }))}
                />
              </div>

              {form.slug && (
                <div className="rounded-xl bg-primary/10 p-3">
                  <p className="text-[10px] font-semibold uppercase text-primary">Postback URL</p>
                  <code className="mt-1 block break-all text-[11px]">
                    {postbackBase}/{form.slug}
                    {form.secret && `?secret=${form.secret}`}
                  </code>
                </div>
              )}
            </div>

            <div className="flex gap-2 border-t border-white/5 p-4">
              <Button variant="ghost" onClick={() => setShowForm(false)} className="flex-1">
                Cancel
              </Button>
              <Button onClick={handleSave} disabled={saving} className="flex-1">
                {saving ? "Saving…" : form.id ? "Update" : "Create"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </AdminShell>
  );
};

export default AdminOfferwallCustomize;
