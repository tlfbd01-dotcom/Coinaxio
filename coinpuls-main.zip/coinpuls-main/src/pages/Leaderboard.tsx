import { useEffect, useState } from "react";
import PageShell from "@/components/PageShell";
import { supabase } from "@/integrations/supabase/client";
import { Trophy, Medal, Award } from "lucide-react";
import { formatCoins } from "@/lib/coins";

interface Row {
  user_id: string;
  display_name: string | null;
  total_earned: number;
}

const Leaderboard = () => {
  const [rows, setRows] = useState<Row[]>([]);

  useEffect(() => {
    supabase
      .from("profiles")
      .select("user_id, display_name, total_earned")
      .order("total_earned", { ascending: false })
      .limit(50)
      .then(({ data }) => setRows(data ?? []));
  }, []);

  const icons = [Trophy, Medal, Award];

  return (
    <PageShell title="Leaderboard" subtitle="Top earners">
      <div className="flex flex-col gap-2">
        {rows.length === 0 && (
          <p className="text-center text-xs text-muted-foreground">No data yet.</p>
        )}
        {rows.map((r, i) => {
          const Icon = icons[i] ?? null;
          return (
            <div
              key={r.user_id}
              className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-4 py-3"
            >
              <div className="flex items-center gap-3">
                {Icon ? (
                  <Icon
                    className={`h-5 w-5 ${
                      i === 0 ? "text-yellow-400" : i === 1 ? "text-gray-300" : "text-orange-400"
                    }`}
                  />
                ) : (
                  <span className="w-5 text-center text-xs font-bold text-muted-foreground">
                    #{i + 1}
                  </span>
                )}
                <span className="text-sm font-semibold">{r.display_name ?? "Anonymous"}</span>
              </div>
              <span className="text-sm font-bold text-primary">
                {formatCoins(r.total_earned)}
              </span>
            </div>
          );
        })}
      </div>
    </PageShell>
  );
};

export default Leaderboard;
