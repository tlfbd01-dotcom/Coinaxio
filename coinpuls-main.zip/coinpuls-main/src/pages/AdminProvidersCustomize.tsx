import { useEffect, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface P {
  id: string;
  slug: string;
  name: string;
  logo_url: string | null;
  is_enabled: boolean;
  sort_order: number;
}

const AdminProvidersCustomize = () => {
  const [items, setItems] = useState<P[]>([]);
  const [form, setForm] = useState({ slug: "", name: "", logo_url: "" });

  const load = () => {
    supabase
      .from("providers")
      .select("id, slug, name, logo_url, is_enabled, sort_order")
      .order("sort_order")
      .then(({ data }) => setItems((data as P[]) ?? []));
  };
  useEffect(load, []);

  const add = async () => {
    if (!form.slug || !form.name) return;
    const { error } = await supabase.from("providers").insert(form);
    if (error) toast({ title: "Failed", description: error.message, variant: "destructive" });
    else {
      setForm({ slug: "", name: "", logo_url: "" });
      load();
    }
  };

  const toggle = async (p: P) => {
    await supabase.from("providers").update({ is_enabled: !p.is_enabled }).eq("id", p.id);
    load();
  };

  const remove = async (id: string) => {
    await supabase.from("providers").delete().eq("id", id);
    load();
  };

  return (
    <AdminShell title="Providers" description="Manage offerwall providers">
      <div className="mb-5 grid grid-cols-3 gap-2">
        <input
          placeholder="slug"
          value={form.slug}
          onChange={(e) => setForm({ ...form, slug: e.target.value })}
          className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs"
        />
        <input
          placeholder="name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs"
        />
        <input
          placeholder="logo url"
          value={form.logo_url}
          onChange={(e) => setForm({ ...form, logo_url: e.target.value })}
          className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs"
        />
      </div>
      <button
        onClick={add}
        className="mb-5 w-full rounded-lg bg-primary py-2 text-xs font-bold text-primary-foreground"
      >
        Add Provider
      </button>

      <div className="flex flex-col gap-2">
        {items.map((p) => (
          <div key={p.id} className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-3 py-2">
            <div className="flex items-center gap-2">
              {p.logo_url && <img src={p.logo_url} alt="" className="h-6 w-6 rounded" />}
              <div>
                <p className="text-sm font-semibold">{p.name}</p>
                <p className="text-[10px] text-muted-foreground">{p.slug}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => toggle(p)}
                className={`rounded-full px-3 py-1 text-xs font-bold ${
                  p.is_enabled ? "bg-primary/20 text-primary" : "bg-white/10 text-muted-foreground"
                }`}
              >
                {p.is_enabled ? "On" : "Off"}
              </button>
              <button
                onClick={() => remove(p.id)}
                className="rounded-full bg-destructive/20 px-3 py-1 text-xs font-bold text-destructive"
              >
                ✕
              </button>
            </div>
          </div>
        ))}
      </div>
    </AdminShell>
  );
};

export default AdminProvidersCustomize;
