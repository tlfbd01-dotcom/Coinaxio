import { useEffect, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { useStorageUpload } from "@/hooks/useStorageUpload";
import { toast } from "@/hooks/use-toast";
import { Plus, Trash2, Upload, Image as ImageIcon, ToggleRight, ToggleLeft, ArrowUp, ArrowDown, Home, LayoutDashboard } from "lucide-react";

interface HomepageImage {
  id: string;
  slot: string;
  image_url: string;
  link_url: string | null;
  alt: string | null;
  sort_order: number;
  is_active: boolean;
}

const SLOTS = ["hero-bg", "dashboard-bg", "hero", "featured-1", "featured-2", "banner", "popup", "side"];

const AdminHomepageImages = () => {
  const [items, setItems] = useState<HomepageImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingId, setSavingId] = useState<string | null>(null);
  const { upload, uploading } = useStorageUpload({ folder: "homepage" });

  const load = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("homepage_images")
      .select("*")
      .order("slot")
      .order("sort_order");
    setItems((data ?? []) as HomepageImage[]);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const create = async (slot: string = "hero") => {
    const slotItems = items.filter((i) => i.slot === slot);
    const { data, error } = await supabase
      .from("homepage_images")
      .insert({ slot, image_url: "", is_active: false, sort_order: slotItems.length })
      .select()
      .single();
    if (error) {
      toast({ title: "Create failed", description: error.message, variant: "destructive" });
      return;
    }
    setItems([...items, data as HomepageImage]);
  };

  const move = async (id: string, dir: -1 | 1) => {
    const it = items.find((x) => x.id === id);
    if (!it) return;
    const peers = items
      .filter((x) => x.slot === it.slot)
      .sort((a, b) => a.sort_order - b.sort_order);
    const idx = peers.findIndex((x) => x.id === id);
    const swapWith = peers[idx + dir];
    if (!swapWith) return;
    await update(id, { sort_order: swapWith.sort_order });
    await update(swapWith.id, { sort_order: it.sort_order });
  };

  const update = async (id: string, patch: Partial<HomepageImage>) => {
    setSavingId(id);
    const { error } = await supabase.from("homepage_images").update(patch).eq("id", id);
    setSavingId(null);
    if (error) {
      toast({ title: "Save failed", description: error.message, variant: "destructive" });
      return;
    }
    setItems(items.map((it) => (it.id === id ? { ...it, ...patch } : it)));
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this image?")) return;
    const { error } = await supabase.from("homepage_images").delete().eq("id", id);
    if (error) {
      toast({ title: "Delete failed", description: error.message, variant: "destructive" });
      return;
    }
    setItems(items.filter((it) => it.id !== id));
  };

  const handleUpload = async (id: string, file: File) => {
    const url = await upload(file);
    if (url) await update(id, { image_url: url });
  };

  return (
    <AdminShell title="Homepage Images" description="Manage homepage banners and graphics">
      <div className="mb-4 grid gap-2 sm:grid-cols-3">
        <button
          onClick={() => create("hero-bg")}
          className="flex items-center justify-center gap-1.5 rounded-lg border border-primary/30 bg-primary/10 px-3 py-2 text-xs font-bold text-primary transition hover:bg-primary/20"
        >
          <Home className="h-3.5 w-3.5" /> Add Homepage BG
        </button>
        <button
          onClick={() => create("dashboard-bg")}
          className="flex items-center justify-center gap-1.5 rounded-lg border border-primary/30 bg-primary/10 px-3 py-2 text-xs font-bold text-primary transition hover:bg-primary/20"
        >
          <LayoutDashboard className="h-3.5 w-3.5" /> Add Dashboard BG
        </button>
        <button
          onClick={() => create("hero")}
          className="flex items-center justify-center gap-1.5 rounded-lg bg-primary px-3 py-2 text-xs font-bold text-primary-foreground transition hover:opacity-90"
        >
          <Plus className="h-3.5 w-3.5" /> Add other image
        </button>
      </div>
      <p className="mb-3 text-[11px] text-muted-foreground">
        {items.length} image{items.length === 1 ? "" : "s"} · Use ↑/↓ to reorder within each slot. First active item per slot is shown.
      </p>

      {loading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : items.length === 0 ? (
        <div className="glass-card rounded-2xl p-10 text-center">
          <ImageIcon className="mx-auto h-8 w-8 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">No homepage images yet</p>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {items.map((it) => (
            <div key={it.id} className="glass-card flex flex-col gap-3 rounded-2xl p-3">
              <div className="flex gap-3">
                <div className="flex h-20 w-28 shrink-0 items-center justify-center overflow-hidden rounded-lg border border-white/10 bg-white/5">
                  {it.image_url ? (
                    <img src={it.image_url} alt={it.alt ?? ""} className="h-full w-full object-cover" />
                  ) : (
                    <ImageIcon className="h-6 w-6 text-muted-foreground" />
                  )}
                </div>
                <div className="flex flex-1 flex-col gap-2">
                  <div className="flex gap-2">
                    <select
                      value={it.slot}
                      onChange={(e) => update(it.id, { slot: e.target.value })}
                      className="flex-1 rounded-md border border-white/10 bg-white/5 px-2 py-1 text-xs outline-none"
                    >
                      {SLOTS.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                    <input
                      type="number"
                      value={it.sort_order}
                      onChange={(e) => update(it.id, { sort_order: Number(e.target.value) })}
                      className="w-16 rounded-md border border-white/10 bg-white/5 px-2 py-1 text-xs outline-none"
                    />
                    <button
                      onClick={() => update(it.id, { is_active: !it.is_active })}
                      className={`flex items-center gap-1 rounded-md px-2 py-1 text-xs font-semibold ${
                        it.is_active ? "bg-primary/15 text-primary" : "bg-white/5 text-muted-foreground"
                      }`}
                    >
                      {it.is_active ? <ToggleRight className="h-3.5 w-3.5" /> : <ToggleLeft className="h-3.5 w-3.5" />}
                      {it.is_active ? "On" : "Off"}
                    </button>
                  </div>
                  <input
                    value={it.alt ?? ""}
                    placeholder="Alt text"
                    onChange={(e) => update(it.id, { alt: e.target.value })}
                    className="rounded-md border border-white/10 bg-white/5 px-2 py-1 text-xs outline-none"
                  />
                  <input
                    value={it.link_url ?? ""}
                    placeholder="Link URL (optional)"
                    onChange={(e) => update(it.id, { link_url: e.target.value })}
                    className="rounded-md border border-white/10 bg-white/5 px-2 py-1 text-xs outline-none"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <label className="flex flex-1 cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed border-white/15 py-2 text-xs transition hover:border-primary/40">
                  <Upload className="h-3.5 w-3.5 text-primary" />
                  {uploading ? "Uploading…" : "Upload image"}
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) handleUpload(it.id, f);
                    }}
                  />
                </label>
                <button
                  onClick={() => move(it.id, -1)}
                  title="Move up"
                  className="flex items-center justify-center rounded-lg border border-white/15 px-2.5 py-2 text-xs transition hover:bg-white/10"
                >
                  <ArrowUp className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={() => move(it.id, 1)}
                  title="Move down"
                  className="flex items-center justify-center rounded-lg border border-white/15 px-2.5 py-2 text-xs transition hover:bg-white/10"
                >
                  <ArrowDown className="h-3.5 w-3.5" />
                </button>
                <button
                  onClick={() => remove(it.id)}
                  className="flex items-center gap-1 rounded-lg border border-destructive/40 px-3 py-2 text-xs font-semibold text-destructive transition hover:bg-destructive/10"
                >
                  <Trash2 className="h-3.5 w-3.5" /> Delete
                </button>
              </div>
              {savingId === it.id && (
                <p className="text-[10px] text-muted-foreground">Saving…</p>
              )}
            </div>
          ))}
        </div>
      )}
    </AdminShell>
  );
};

export default AdminHomepageImages;
