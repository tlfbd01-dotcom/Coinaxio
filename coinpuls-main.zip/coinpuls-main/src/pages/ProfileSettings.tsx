import { useEffect, useState } from "react";
import PageShell from "@/components/PageShell";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";

interface Profile {
  display_name: string | null;
  username: string | null;
  avatar_url: string | null;
  country: string | null;
}

const ProfileSettings = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<Profile>({
    display_name: "",
    username: "",
    avatar_url: "",
    country: "",
  });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("profiles")
      .select("display_name, username, avatar_url, country")
      .eq("user_id", user.id)
      .maybeSingle()
      .then(({ data }) => data && setProfile(data));
  }, [user]);

  const save = async () => {
    if (!user) return;
    setBusy(true);
    const { error } = await supabase
      .from("profiles")
      .update(profile)
      .eq("user_id", user.id);
    setBusy(false);
    toast(
      error
        ? { title: "Save failed", description: error.message, variant: "destructive" }
        : { title: "Profile updated" },
    );
  };

  const field = (key: keyof Profile, label: string, placeholder: string) => (
    <label className="flex flex-col gap-1">
      <span className="text-xs text-muted-foreground">{label}</span>
      <input
        type="text"
        value={profile[key] ?? ""}
        onChange={(e) => setProfile((p) => ({ ...p, [key]: e.target.value }))}
        placeholder={placeholder}
        className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none focus:border-primary"
      />
    </label>
  );

  return (
    <PageShell title="Profile Settings" subtitle="Manage your account">
      <div className="flex flex-col gap-3">
        {field("display_name", "Display Name", "Your name")}
        {field("username", "Username", "@username")}
        {field("avatar_url", "Avatar URL", "https://...")}
        {field("country", "Country", "BD")}
        <button
          onClick={save}
          disabled={busy}
          className="mt-2 rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground transition hover:opacity-90 disabled:opacity-50"
        >
          {busy ? "Saving…" : "Save Changes"}
        </button>
      </div>
    </PageShell>
  );
};

export default ProfileSettings;
