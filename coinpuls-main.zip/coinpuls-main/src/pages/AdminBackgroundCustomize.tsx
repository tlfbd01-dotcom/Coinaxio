import { useEffect, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { useStorageUpload } from "@/hooks/useStorageUpload";
import { toast } from "@/hooks/use-toast";
import { Upload, Power, Plus, Trash2 } from "lucide-react";
import { Switch } from "@/components/ui/switch";

const KEY = "site_background";

type Scope = "all" | "include" | "exclude";

interface BgVisual {
  type: "solid" | "gradient" | "image";
  color: string;
  gradientFrom: string;
  gradientTo: string;
  imageUrl: string;
  overlayOpacity: number;
}

interface BgOverride extends BgVisual {
  id: string;
  paths: string[];
}

interface BgConfig extends BgVisual {
  enabled: boolean;
  scope: Scope;
  paths: string[];
  overrides: BgOverride[];
}

const defaults: BgConfig = {
  type: "solid",
  color: "222 47% 11%",
  gradientFrom: "240 10% 8%",
  gradientTo: "260 30% 12%",
  imageUrl: "",
  overlayOpacity: 60,
  enabled: true,
  scope: "all",
  paths: [],
  overrides: [],
};

const newOverride = (paths: string[] = []): BgOverride => ({
  id: crypto.randomUUID(),
  type: "image",
  color: "222 47% 11%",
  gradientFrom: "240 10% 8%",
  gradientTo: "260 30% 12%",
  imageUrl: "",
  overlayOpacity: 50,
  paths,
});

const AdminBackgroundCustomize = () => {
  const [cfg, setCfg] = useState<BgConfig>(defaults);
  const [saving, setSaving] = useState(false);
  const { upload, uploading } = useStorageUpload({ folder: "backgrounds" });

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("site_settings")
        .select("value")
        .eq("key", KEY)
        .maybeSingle();
      if (data?.value && typeof data.value === "object") {
        setCfg({ ...defaults, ...(data.value as Partial<BgConfig>) });
      }
    })();
  }, []);

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await upload(file);
    if (url) setCfg({ ...cfg, imageUrl: url, type: "image" });
  };

  const updateOverride = (id: string, patch: Partial<BgOverride>) => {
    setCfg({
      ...cfg,
      overrides: (cfg.overrides || []).map((o) => (o.id === id ? { ...o, ...patch } : o)),
    });
  };

  const removeOverride = (id: string) => {
    setCfg({ ...cfg, overrides: (cfg.overrides || []).filter((o) => o.id !== id) });
  };

  const uploadOverrideImage = async (id: string, file: File) => {
    const url = await upload(file);
    if (url) updateOverride(id, { imageUrl: url, type: "image" });
  };

  const save = async () => {
    setSaving(true);
    const { error } = await supabase
      .from("site_settings")
      .upsert([{ key: KEY, value: cfg as any }], { onConflict: "key" });
    setSaving(false);
    if (error) {
      toast({ title: "Save failed", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Background saved", description: "Refresh the homepage to see changes." });
    }
  };

  const previewStyle: React.CSSProperties =
    cfg.type === "image"
      ? {
          backgroundImage: `linear-gradient(hsla(0,0%,0%,${cfg.overlayOpacity / 100}), hsla(0,0%,0%,${cfg.overlayOpacity / 100})), url(${cfg.imageUrl})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }
      : cfg.type === "gradient"
        ? { background: `linear-gradient(135deg, hsl(${cfg.gradientFrom}), hsl(${cfg.gradientTo}))` }
        : { background: `hsl(${cfg.color})` };

  return (
    <AdminShell title="Background Customize" description="Set background color, gradient or image">
      <div className="flex flex-col gap-5">
        <div className="overflow-hidden rounded-2xl border border-white/10">
          <div style={previewStyle} className="flex h-40 items-center justify-center text-sm font-semibold text-white/80">
            Preview
          </div>
        </div>
        {/* Enable toggle */}
        <div className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 p-4">
          <div className="flex items-center gap-3">
            <Power className={`h-5 w-5 ${cfg.enabled ? "text-primary" : "text-muted-foreground"}`} />
            <div>
              <div className="text-sm font-semibold">Site background enabled</div>
              <div className="text-xs text-muted-foreground">
                Turn off to fully disable the background everywhere.
              </div>
            </div>
          </div>
          <Switch
            checked={cfg.enabled}
            onCheckedChange={(v) => setCfg({ ...cfg, enabled: v })}
          />
        </div>

        {/* Scope selector */}
        <div className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-white/5 p-4">
          <div>
            <div className="text-sm font-semibold">Where should it show?</div>
            <div className="text-xs text-muted-foreground">
              Limit the background to specific pages or hide it from some pages.
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {([
              { v: "all", label: "All pages" },
              { v: "include", label: "Only on…" },
              { v: "exclude", label: "Hide on…" },
            ] as { v: Scope; label: string }[]).map((opt) => (
              <button
                key={opt.v}
                onClick={() => setCfg({ ...cfg, scope: opt.v })}
                className={`rounded-xl border px-3 py-2 text-xs font-semibold transition ${
                  cfg.scope === opt.v
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-white/10 text-muted-foreground hover:bg-white/5"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
          {cfg.scope !== "all" && (
            <div className="flex flex-col gap-2">
              <label className="text-xs text-muted-foreground">
                One path per line. Use <code className="text-primary">/admin/*</code> for wildcards.
              </label>
              <textarea
                rows={4}
                value={(cfg.paths || []).join("\n")}
                onChange={(e) =>
                  setCfg({
                    ...cfg,
                    paths: e.target.value.split("\n").map((s) => s.trim()).filter(Boolean),
                  })
                }
                placeholder={"/\n/dashboard\n/admin/*"}
                className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 font-mono text-xs outline-none focus:border-primary"
              />
            </div>
          )}
        </div>

        <div className="grid grid-cols-3 gap-2">
          {(["solid", "gradient", "image"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setCfg({ ...cfg, type: t })}
              className={`rounded-xl border px-3 py-2 text-xs font-semibold capitalize transition ${
                cfg.type === t
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-white/10 text-muted-foreground hover:bg-white/5"
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {cfg.type === "solid" && (
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium">HSL color (e.g. "222 47% 11%")</label>
            <input
              value={cfg.color}
              onChange={(e) => setCfg({ ...cfg, color: e.target.value })}
              className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none focus:border-primary"
            />
          </div>
        )}

        {cfg.type === "gradient" && (
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-2">
              <label className="text-sm font-medium">From (HSL)</label>
              <input
                value={cfg.gradientFrom}
                onChange={(e) => setCfg({ ...cfg, gradientFrom: e.target.value })}
                className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none focus:border-primary"
              />
            </div>
            <div className="flex flex-col gap-2">
              <label className="text-sm font-medium">To (HSL)</label>
              <input
                value={cfg.gradientTo}
                onChange={(e) => setCfg({ ...cfg, gradientTo: e.target.value })}
                className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none focus:border-primary"
              />
            </div>
          </div>
        )}

        {cfg.type === "image" && (
          <div className="flex flex-col gap-3">
            <label className="glass-card flex cursor-pointer items-center gap-3 rounded-xl border border-dashed border-white/15 p-4 transition hover:border-primary/40">
              <Upload className="h-5 w-5 text-primary" />
              <span className="text-sm">{uploading ? "Uploading…" : "Upload background image"}</span>
              <input type="file" accept="image/*" onChange={handleFile} className="hidden" />
            </label>
            <input
              value={cfg.imageUrl}
              placeholder="…or paste an image URL"
              onChange={(e) => setCfg({ ...cfg, imageUrl: e.target.value })}
              className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none focus:border-primary"
            />
            <div className="flex flex-col gap-1">
              <label className="text-xs text-muted-foreground">Dark overlay: {cfg.overlayOpacity}%</label>
              <input
                type="range"
                min={0}
                max={90}
                value={cfg.overlayOpacity}
                onChange={(e) => setCfg({ ...cfg, overlayOpacity: Number(e.target.value) })}
              />
            </div>
          </div>
        )}

        {/* Per-page overrides */}
        <div className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-white/5 p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="text-sm font-semibold">Per-page backgrounds</div>
              <div className="text-xs text-muted-foreground">
                Set a different background for specific pages (e.g. Index, Dashboard). Overrides win over the base background.
              </div>
            </div>
            <button
              onClick={() => setCfg({ ...cfg, overrides: [...(cfg.overrides || []), newOverride()] })}
              className="flex items-center gap-1 rounded-lg bg-primary/15 px-3 py-2 text-xs font-bold text-primary transition hover:bg-primary/25"
            >
              <Plus className="h-3.5 w-3.5" /> Add
            </button>
          </div>

          {(cfg.overrides || []).map((ov) => {
            const ovPreview: React.CSSProperties =
              ov.type === "image"
                ? {
                    backgroundImage: `linear-gradient(hsla(0,0%,0%,${ov.overlayOpacity / 100}), hsla(0,0%,0%,${ov.overlayOpacity / 100})), url(${ov.imageUrl})`,
                    backgroundSize: "cover",
                    backgroundPosition: "center",
                  }
                : ov.type === "gradient"
                  ? { background: `linear-gradient(135deg, hsl(${ov.gradientFrom}), hsl(${ov.gradientTo}))` }
                  : { background: `hsl(${ov.color})` };

            return (
              <div key={ov.id} className="flex flex-col gap-3 rounded-xl border border-white/10 bg-background/40 p-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex flex-1 flex-col gap-2">
                    <label className="text-xs font-semibold text-muted-foreground">
                      Pages (one per line, supports <code className="text-primary">/admin/*</code>)
                    </label>
                    <textarea
                      rows={2}
                      value={(ov.paths || []).join("\n")}
                      onChange={(e) =>
                        updateOverride(ov.id, {
                          paths: e.target.value.split("\n").map((s) => s.trim()).filter(Boolean),
                        })
                      }
                      placeholder={"/\n/dashboard"}
                      className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 font-mono text-xs outline-none focus:border-primary"
                    />
                  </div>
                  <button
                    onClick={() => removeOverride(ov.id)}
                    className="flex items-center gap-1 rounded-lg border border-white/10 px-2 py-2 text-xs text-destructive transition hover:bg-destructive/10"
                    aria-label="Remove"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>

                <div style={ovPreview} className="h-20 rounded-lg border border-white/10" />

                <div className="grid grid-cols-3 gap-2">
                  {(["solid", "gradient", "image"] as const).map((t) => (
                    <button
                      key={t}
                      onClick={() => updateOverride(ov.id, { type: t })}
                      className={`rounded-lg border px-2 py-1.5 text-[11px] font-semibold capitalize transition ${
                        ov.type === t
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-white/10 text-muted-foreground hover:bg-white/5"
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>

                {ov.type === "solid" && (
                  <input
                    value={ov.color}
                    onChange={(e) => updateOverride(ov.id, { color: e.target.value })}
                    placeholder='HSL e.g. "222 47% 11%"'
                    className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs outline-none focus:border-primary"
                  />
                )}

                {ov.type === "gradient" && (
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      value={ov.gradientFrom}
                      onChange={(e) => updateOverride(ov.id, { gradientFrom: e.target.value })}
                      placeholder="From HSL"
                      className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs outline-none focus:border-primary"
                    />
                    <input
                      value={ov.gradientTo}
                      onChange={(e) => updateOverride(ov.id, { gradientTo: e.target.value })}
                      placeholder="To HSL"
                      className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs outline-none focus:border-primary"
                    />
                  </div>
                )}

                {ov.type === "image" && (
                  <div className="flex flex-col gap-2">
                    <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-white/15 p-2.5 text-xs transition hover:border-primary/40">
                      <Upload className="h-4 w-4 text-primary" />
                      <span>{uploading ? "Uploading…" : "Upload image for this page"}</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) uploadOverrideImage(ov.id, f);
                        }}
                      />
                    </label>
                    <input
                      value={ov.imageUrl}
                      onChange={(e) => updateOverride(ov.id, { imageUrl: e.target.value })}
                      placeholder="…or paste an image URL"
                      className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs outline-none focus:border-primary"
                    />
                    <div className="flex flex-col gap-1">
                      <label className="text-[11px] text-muted-foreground">
                        Overlay opacity: {ov.overlayOpacity}%
                      </label>
                      <input
                        type="range"
                        min={0}
                        max={90}
                        value={ov.overlayOpacity}
                        onChange={(e) => updateOverride(ov.id, { overlayOpacity: Number(e.target.value) })}
                      />
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {(!cfg.overrides || cfg.overrides.length === 0) && (
            <div className="rounded-lg border border-dashed border-white/10 p-3 text-center text-xs text-muted-foreground">
              No per-page overrides. Click "Add" to set a unique background for a page.
            </div>
          )}
        </div>

        <button
          onClick={save}
          disabled={saving}
          className="rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground transition hover:opacity-90 disabled:opacity-50"
        >
          {saving ? "Saving…" : "Save Background"}
        </button>
      </div>
    </AdminShell>
  );
};

export default AdminBackgroundCustomize;
