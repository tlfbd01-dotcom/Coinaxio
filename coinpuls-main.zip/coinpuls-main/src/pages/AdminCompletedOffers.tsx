import { useEffect, useMemo, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import EditCompletedOfferDialog from "@/components/admin/EditCompletedOfferDialog";
import { formatCoins, dollarsToCoins } from "@/lib/coins";
import {
  CheckCircle2,
  Search,
  Pencil,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
} from "lucide-react";

interface Row {
  id: string;
  user_id: string;
  username: string | null;
  display_name: string | null;
  provider_name: string | null;
  title: string | null;
  payout: number;
  status: string;
  provider_tx_id: string | null;
  country: string | null;
  created_at: string;
}

const PAGE_SIZES = [15, 30, 50, 100];

const AdminCompletedOffers = () => {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(false);
  const [q, setQ] = useState("");
  const [wall, setWall] = useState("all");
  const [country, setCountry] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [pageSize, setPageSize] = useState(15);
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [editRow, setEditRow] = useState<Row | null>(null);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase.rpc("admin_list_completed_offers");
    setLoading(false);
    if (error) {
      toast({ title: "Failed to load", description: error.message, variant: "destructive" });
      return;
    }
    setRows((data as Row[]) ?? []);
  };

  useEffect(() => {
    load();
  }, []);

  const walls = useMemo(
    () => Array.from(new Set(rows.map((r) => r.provider_name).filter(Boolean) as string[])),
    [rows]
  );
  const countries = useMemo(
    () => Array.from(new Set(rows.map((r) => r.country).filter(Boolean) as string[])),
    [rows]
  );

  const filtered = useMemo(() => {
    const ql = q.trim().toLowerCase();
    return rows.filter((r) => {
      if (ql) {
        const hay = `${r.username ?? ""} ${r.display_name ?? ""} ${r.title ?? ""} ${
          r.provider_tx_id ?? ""
        }`.toLowerCase();
        if (!hay.includes(ql)) return false;
      }
      if (wall !== "all" && r.provider_name !== wall) return false;
      if (country !== "all" && (r.country ?? "Unknown") !== country) return false;
      const t = new Date(r.created_at).getTime();
      if (from && t < new Date(from).getTime()) return false;
      if (to && t > new Date(to).getTime() + 86_399_000) return false;
      return true;
    });
  }, [rows, q, wall, country, from, to]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const start = (safePage - 1) * pageSize;
  const slice = filtered.slice(start, start + pageSize);

  const totalCoins = rows.reduce((a, r) => a + Number(r.payout ?? 0), 0);

  const fmtDate = (s: string) => {
    const d = new Date(s);
    return d.toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const toggleAll = () => {
    if (slice.every((r) => selected.has(r.id))) {
      const next = new Set(selected);
      slice.forEach((r) => next.delete(r.id));
      setSelected(next);
    } else {
      const next = new Set(selected);
      slice.forEach((r) => next.add(r.id));
      setSelected(next);
    }
  };
  const toggleOne = (id: string) => {
    const next = new Set(selected);
    next.has(id) ? next.delete(id) : next.add(id);
    setSelected(next);
  };

  const Select = ({
    value,
    onChange,
    options,
  }: {
    value: string;
    onChange: (v: string) => void;
    options: { value: string; label: string }[];
  }) => (
    <select
      value={value}
      onChange={(e) => {
        onChange(e.target.value);
        setPage(1);
      }}
      className="rounded-full border border-white/10 bg-black/40 px-3 py-1.5 text-xs outline-none focus:border-primary"
    >
      {options.map((o) => (
        <option key={o.value} value={o.value} className="bg-neutral-900">
          {o.label}
        </option>
      ))}
    </select>
  );

  return (
    <AdminShell title="Offers" description="Completed conversions">
      <div className="flex flex-col gap-4 pb-10">
        <div className="rounded-2xl border border-white/10 bg-neutral-900/60 p-4 sm:p-5">
          <h2 className="mb-4 flex items-center gap-2 text-base font-bold text-primary sm:text-lg">
            <CheckCircle2 className="h-5 w-5" /> Completed Offers ({rows.length})
          </h2>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative min-w-[180px] flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                placeholder="Search user..."
                value={q}
                onChange={(e) => {
                  setQ(e.target.value);
                  setPage(1);
                }}
                className="w-full rounded-full border border-white/10 bg-black/40 py-1.5 pl-9 pr-3 text-xs outline-none focus:border-primary"
              />
            </div>
            <Select
              value={wall}
              onChange={setWall}
              options={[
                { value: "all", label: "All Walls" },
                ...walls.map((w) => ({ value: w, label: w })),
              ]}
            />
            <Select
              value={country}
              onChange={setCountry}
              options={[
                { value: "all", label: "All Countries" },
                ...countries.map((c) => ({ value: c, label: c })),
              ]}
            />
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <span>From:</span>
              <input
                type="date"
                value={from}
                onChange={(e) => {
                  setFrom(e.target.value);
                  setPage(1);
                }}
                className="rounded-md border border-white/10 bg-black/40 px-2 py-1 text-xs outline-none focus:border-primary"
              />
              <span>To:</span>
              <input
                type="date"
                value={to}
                onChange={(e) => {
                  setTo(e.target.value);
                  setPage(1);
                }}
                className="rounded-md border border-white/10 bg-black/40 px-2 py-1 text-xs outline-none focus:border-primary"
              />
            </div>
            <Select
              value={String(pageSize)}
              onChange={(v) => setPageSize(Number(v))}
              options={PAGE_SIZES.map((n) => ({ value: String(n), label: `${n} rows` }))}
            />
          </div>

          {/* Table */}
          <div className="mt-4 overflow-x-auto rounded-xl border border-white/10 bg-black/30">
            <table className="w-full min-w-[900px] text-left text-xs">
              <thead className="text-[11px] uppercase tracking-wider text-primary/90">
                <tr className="border-b border-white/10">
                  <th className="px-3 py-2.5">
                    <input
                      type="checkbox"
                      checked={slice.length > 0 && slice.every((r) => selected.has(r.id))}
                      onChange={toggleAll}
                      className="h-3.5 w-3.5 accent-primary"
                    />
                  </th>
                  <th className="px-3 py-2.5">#</th>
                  <th className="px-3 py-2.5">User ID</th>
                  <th className="px-3 py-2.5">Username</th>
                  <th className="px-3 py-2.5">Offerwall</th>
                  <th className="px-3 py-2.5">Offer Name</th>
                  <th className="px-3 py-2.5">Coin</th>
                  <th className="px-3 py-2.5">Transaction ID</th>
                  <th className="px-3 py-2.5">IP</th>
                  <th className="px-3 py-2.5">Country</th>
                  <th className="px-3 py-2.5">Date</th>
                  <th className="px-3 py-2.5 text-right">Act</th>
                </tr>
              </thead>
              <tbody>
                {slice.map((r, i) => (
                  <tr key={r.id} className="border-b border-white/5 transition hover:bg-white/5">
                    <td className="px-3 py-2.5">
                      <input
                        type="checkbox"
                        checked={selected.has(r.id)}
                        onChange={() => toggleOne(r.id)}
                        className="h-3.5 w-3.5 accent-primary"
                      />
                    </td>
                    <td className="px-3 py-2.5 text-muted-foreground">{start + i + 1}</td>
                    <td className="px-3 py-2.5 text-muted-foreground">
                      {r.user_id.slice(0, 4)}…
                    </td>
                    <td className="px-3 py-2.5 font-semibold">{r.username ?? "—"}</td>
                    <td className="px-3 py-2.5 text-primary">{r.provider_name ?? "—"}</td>
                    <td className="max-w-[180px] truncate px-3 py-2.5" title={r.title ?? ""}>
                      {r.title ?? "—"}
                    </td>
                    <td className="px-3 py-2.5 font-bold text-primary">
                      {formatCoins(r.payout)}
                    </td>
                    <td
                      className="max-w-[160px] truncate px-3 py-2.5 text-muted-foreground"
                      title={r.provider_tx_id ?? ""}
                    >
                      {r.provider_tx_id ?? "—"}
                    </td>
                    <td className="px-3 py-2.5 text-muted-foreground">N/A</td>
                    <td className="px-3 py-2.5 text-muted-foreground">
                      {r.country ?? "Unknown"}
                    </td>
                    <td className="px-3 py-2.5 text-muted-foreground">{fmtDate(r.created_at)}</td>
                    <td className="px-3 py-2.5 text-right">
                      <button
                        onClick={() => setEditRow(r)}
                        className="text-primary/80 transition hover:text-primary"
                        aria-label="Edit"
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
                {slice.length === 0 && (
                  <tr>
                    <td colSpan={12} className="px-3 py-8 text-center text-muted-foreground">
                      {loading ? "Loading…" : "No completed offers."}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Footer */}
          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="text-muted-foreground">
              Showing {filtered.length === 0 ? 0 : start + 1}-
              {Math.min(start + pageSize, filtered.length)} of {filtered.length}
            </span>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setPage(1)}
                disabled={safePage === 1}
                className="rounded-md p-1.5 text-muted-foreground transition hover:bg-white/5 disabled:opacity-30"
              >
                <ChevronsLeft className="h-4 w-4" />
              </button>
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={safePage === 1}
                className="rounded-md px-2 py-1 text-muted-foreground transition hover:bg-white/5 disabled:opacity-30"
              >
                ← Prev
              </button>
              <span className="rounded-md bg-primary px-3 py-1 font-bold text-primary-foreground">
                {safePage}
              </span>
              <button
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={safePage === totalPages}
                className="rounded-md px-2 py-1 text-muted-foreground transition hover:bg-white/5 disabled:opacity-30"
              >
                Next →
              </button>
              <button
                onClick={() => setPage(totalPages)}
                disabled={safePage === totalPages}
                className="rounded-md p-1.5 text-muted-foreground transition hover:bg-white/5 disabled:opacity-30"
              >
                <ChevronsRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Totals */}
        <div className="flex items-center justify-between rounded-2xl border border-white/10 bg-neutral-900/60 p-4 sm:p-5">
          <div className="flex flex-col gap-1">
            <span className="text-xs text-muted-foreground">Total Offers</span>
            <span className="text-2xl font-extrabold text-primary">{rows.length}</span>
          </div>
          <div className="flex flex-col items-end gap-1">
            <span className="text-xs text-muted-foreground">Total Coins</span>
            <span className="text-2xl font-extrabold text-primary">
              {dollarsToCoins(totalCoins).toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      <EditCompletedOfferDialog
        row={editRow}
        open={!!editRow}
        onOpenChange={(v) => !v && setEditRow(null)}
        onSaved={load}
      />
    </AdminShell>
  );
};

export default AdminCompletedOffers;
