import { useEffect, useState } from "react";
import PageShell from "@/components/PageShell";
import { supabase } from "@/integrations/supabase/client";
import { formatCoins } from "@/lib/coins";

interface Offer {
  id: string;
  title: string;
  image_url: string | null;
  payout: number;
  category: string | null;
  click_url: string | null;
}

const AllOffers = () => {
  const [offers, setOffers] = useState<Offer[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from("offers")
      .select("id, title, image_url, payout, category, click_url")
      .eq("is_active", true)
      .order("payout", { ascending: false })
      .then(({ data }) => {
        setOffers(data ?? []);
        setLoading(false);
      });
  }, []);

  return (
    <PageShell title="All Offers" subtitle="Browse every available offer">
      {loading && <p className="text-center text-xs text-muted-foreground">Loading…</p>}
      {!loading && offers.length === 0 && (
        <p className="text-center text-xs text-muted-foreground">No offers available right now.</p>
      )}
      <div className="grid grid-cols-2 gap-3">
        {offers.map((o) => (
          <a
            key={o.id}
            href={o.click_url ?? "#"}
            target="_blank"
            rel="noreferrer"
            className="glass-card flex flex-col gap-2 rounded-2xl p-3 transition hover:scale-[1.02]"
          >
            {o.image_url && (
              <img
                src={o.image_url}
                alt={o.title}
                className="h-24 w-full rounded-xl object-cover"
                loading="lazy"
              />
            )}
            <p className="line-clamp-2 text-xs font-semibold">{o.title}</p>
            <div className="mt-auto flex items-center justify-between">
              {o.category && <span className="text-[10px] text-muted-foreground">{o.category}</span>}
              <span className="text-sm font-bold text-primary">{formatCoins(o.payout)}</span>
            </div>
          </a>
        ))}
      </div>
    </PageShell>
  );
};

export default AllOffers;
