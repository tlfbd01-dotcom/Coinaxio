import { useEffect, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { formatCoins } from "@/lib/coins";

interface Log {
  id: string;
  provider_slug: string | null;
  user_id: string | null;
  payout: number | null;
  status: string;
  ip_address: string | null;
  created_at: string;
  raw_payload: any;
}

const AdminPostbackHistory = () => {
  const [logs, setLogs] = useState<Log[]>([]);
  const [open, setOpen] = useState<string | null>(null);

  useEffect(() => {
    supabase
      .from("postback_logs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(100)
      .then(({ data }) => setLogs((data as Log[]) ?? []));
  }, []);

  return (
    <AdminShell title="Postback History" description="Inspect incoming postback events">
      <div className="flex flex-col gap-2">
        {logs.map((l) => (
          <div key={l.id} className="rounded-xl border border-white/10 bg-white/5 p-3">
            <button
              onClick={() => setOpen(open === l.id ? null : l.id)}
              className="flex w-full items-center justify-between text-left"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold">{l.provider_slug ?? "?"}</p>
                <p className="text-[10px] text-muted-foreground">
                  {l.user_id?.slice(0, 8) ?? "no-user"}… · {new Date(l.created_at).toLocaleString()}
                </p>
              </div>
              <div className="text-right">
                {l.payout != null && (
                  <p className="text-sm font-bold text-primary">{formatCoins(l.payout)}</p>
                )}
                <p className="text-[10px] uppercase">{l.status}</p>
              </div>
            </button>
            {open === l.id && (
              <pre className="mt-3 max-h-64 overflow-auto rounded-lg bg-black/30 p-2 text-[10px]">
                {JSON.stringify(l.raw_payload, null, 2)}
              </pre>
            )}
          </div>
        ))}
        {logs.length === 0 && (
          <p className="text-center text-xs text-muted-foreground">No postbacks yet.</p>
        )}
      </div>
    </AdminShell>
  );
};

export default AdminPostbackHistory;
