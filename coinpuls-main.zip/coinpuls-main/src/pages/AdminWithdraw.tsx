import { useEffect, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";
import PaymentMethodsManager from "@/components/PaymentMethodsManager";
import { Settings } from "lucide-react";
import { formatCoins } from "@/lib/coins";

interface W {
  id: string;
  user_id: string;
  amount: number;
  destination: string;
  status: string;
  created_at: string;
  admin_note: string | null;
}

const AdminWithdraw = () => {
  const { user } = useAuth();
  const [items, setItems] = useState<W[]>([]);
  const [filter, setFilter] = useState<string>("pending");
  const [showManager, setShowManager] = useState(false);

  const load = () => {
    let q = supabase.from("withdrawals").select("*").order("created_at", { ascending: false }).limit(100);
    if (filter !== "all") q = q.eq("status", filter as any);
    q.then(({ data }) => setItems((data as W[]) ?? []));
  };

  useEffect(load, [filter]);

  const updateStatus = async (id: string, status: "approved" | "rejected" | "paid") => {
    const { error } = await supabase
      .from("withdrawals")
      .update({ status, processed_by: user?.id, processed_at: new Date().toISOString() })
      .eq("id", id);
    if (error) toast({ title: "Failed", description: error.message, variant: "destructive" });
    else {
      toast({ title: `Marked ${status}` });
      load();
    }
  };

  return (
    <AdminShell title="Withdrawals" description="Approve or reject payout requests">
      <button
        onClick={() => setShowManager((s) => !s)}
        className="mb-4 flex w-full items-center justify-center gap-2 rounded-xl border border-primary/40 bg-primary/10 px-4 py-2.5 text-sm font-bold text-primary hover:bg-primary/20"
      >
        <Settings className="h-4 w-4" />
        {showManager ? "Hide Payment Method Manager" : "Manage Payment Methods"}
      </button>
      {showManager && (
        <div className="mb-6">
          <PaymentMethodsManager />
        </div>
      )}

      <div className="mb-4 flex gap-2">
        {["pending", "approved", "paid", "rejected", "all"].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-full px-3 py-1.5 text-xs font-semibold ${
              filter === f ? "bg-primary text-primary-foreground" : "bg-white/5 text-muted-foreground"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="flex flex-col gap-2">
        {items.map((w) => (
          <div key={w.id} className="rounded-xl border border-white/10 bg-white/5 p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-bold">{formatCoins(w.amount)} coins</p>
                <p className="text-xs text-muted-foreground">{w.destination}</p>
                <p className="text-[10px] text-muted-foreground">user: {w.user_id.slice(0, 8)}…</p>
              </div>
              <span className="rounded-full bg-white/10 px-3 py-1 text-xs font-semibold uppercase">
                {w.status}
              </span>
            </div>
            {w.status === "pending" && (
              <div className="mt-3 flex gap-2">
                <button
                  onClick={() => updateStatus(w.id, "approved")}
                  className="flex-1 rounded-lg bg-primary py-2 text-xs font-bold text-primary-foreground"
                >
                  Approve
                </button>
                <button
                  onClick={() => updateStatus(w.id, "paid")}
                  className="flex-1 rounded-lg bg-primary/30 py-2 text-xs font-bold"
                >
                  Mark Paid
                </button>
                <button
                  onClick={() => updateStatus(w.id, "rejected")}
                  className="flex-1 rounded-lg bg-destructive/20 py-2 text-xs font-bold text-destructive"
                >
                  Reject
                </button>
              </div>
            )}
          </div>
        ))}
        {items.length === 0 && (
          <p className="text-center text-xs text-muted-foreground">No withdrawals.</p>
        )}
      </div>
    </AdminShell>
  );
};

export default AdminWithdraw;
