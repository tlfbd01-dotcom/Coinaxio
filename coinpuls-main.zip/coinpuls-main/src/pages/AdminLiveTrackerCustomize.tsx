import { useEffect, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { Plus, Trash2, GripVertical } from "lucide-react";

const KEY = "live_tracker";

interface TrackerItem {
  id: string;
  username: string;
  provider: string;
  amount: number;
  avatar: string;
}

interface TrackerConfig {
  enabled: boolean;
  scrolling: boolean; // marquee animation on/off (default: off = stopped)
  speed: number; // seconds for one full loop
  flag: string;
  items: TrackerItem[];
}

const defaults: TrackerConfig = {
  enabled: true,
  scrolling: false,
  speed: 40,
  flag: "🇧🇩",
  items: [
    { id: "1", username: "Khyf", provider: "Adswed", amount: 1020, avatar: "" },
    { id: "2", username: "gjyhg", provider: "pixy", amount: 132, avatar: "" },
  ],
};

const newId = () => Math.random().toString(36).slice(2, 10);

const AdminLiveTrackerCustomize = () => {
  const [cfg, setCfg] = useState<TrackerConfig>(defaults);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("site_settings")
        .select("value")
        .eq("key", KEY)
        .maybeSingle();
      if (data?.value && typeof data.value === "object") {
        const v = data.value as Partial<TrackerConfig>;
        setCfg({ ...defaults, ...v, items: v.items?.length ? v.items : defaults.items });
      }
    })();
  }, []);

  const updateItem = (id: string, patch: Partial<TrackerItem>) => {
    setCfg({ ...cfg, items: cfg.items.map((i) => (i.id === id ? { ...i, ...patch } : i)) });
  };

  const addItem = () => {
    setCfg({
      ...cfg,
      items: [...cfg.items, { id: newId(), username: "User", provider: "Adswed", amount: 100, avatar: "" }],
    });
  };

  const removeItem = (id: string) => {
    setCfg({ ...cfg, items: cfg.items.filter((i) => i.id !== id) });
  };

  const save = async () => {
    setSaving(true);
    const { error } = await supabase
      .from("site_settings")
      .upsert([{ key: KEY, value: cfg as any }], { onConflict: "key" });
    setSaving(false);
    if (error) {
      toast({ title: "Save failed", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Live tracker saved" });
    }
  };

  return (
    <AdminShell title="Live Tracker" description="Configure the live earnings ticker">
      <div className="flex flex-col gap-5">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <div className="glass-card flex items-center justify-between rounded-xl p-3">
            <span className="text-xs font-medium">Enabled</span>
            <button
              onClick={() => setCfg({ ...cfg, enabled: !cfg.enabled })}
              className={`relative h-6 w-10 rounded-full transition ${cfg.enabled ? "bg-primary" : "bg-white/10"}`}
            >
              <span
                className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-all ${
                  cfg.enabled ? "left-5" : "left-1"
                }`}
              />
            </button>
          </div>
          <div className="glass-card flex items-center justify-between rounded-xl p-3">
            <span className="text-xs font-medium">Scrolling</span>
            <button
              onClick={() => setCfg({ ...cfg, scrolling: !cfg.scrolling })}
              className={`relative h-6 w-10 rounded-full transition ${cfg.scrolling ? "bg-primary" : "bg-white/10"}`}
              aria-label="Toggle ticker scroll animation"
            >
              <span
                className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-all ${
                  cfg.scrolling ? "left-5" : "left-1"
                }`}
              />
            </button>
          </div>
          <div className="glass-card flex flex-col gap-1 rounded-xl p-3">
            <label className="text-[10px] uppercase tracking-wide text-muted-foreground">Flag emoji</label>
            <input
              value={cfg.flag}
              maxLength={4}
              onChange={(e) => setCfg({ ...cfg, flag: e.target.value })}
              className="w-full rounded-md bg-white/5 px-2 py-1 text-center text-base outline-none focus:bg-white/10"
            />
          </div>
          <div className="glass-card flex flex-col gap-1 rounded-xl p-3">
            <label className="text-[10px] uppercase tracking-wide text-muted-foreground">
              Speed: {cfg.speed}s
            </label>
            <input
              type="range"
              min={10}
              max={120}
              value={cfg.speed}
              onChange={(e) => setCfg({ ...cfg, speed: Number(e.target.value) })}
            />
          </div>
        </div>

        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold">Ticker entries ({cfg.items.length})</h2>
          <button
            onClick={addItem}
            className="flex items-center gap-1 rounded-lg bg-primary px-3 py-1.5 text-xs font-bold text-primary-foreground transition hover:opacity-90"
          >
            <Plus className="h-3.5 w-3.5" /> Add
          </button>
        </div>

        <div className="flex flex-col gap-2">
          {cfg.items.map((it) => (
            <div key={it.id} className="glass-card flex items-center gap-2 rounded-xl p-2.5">
              <GripVertical className="h-4 w-4 text-muted-foreground" />
              <input
                value={it.username}
                placeholder="Username"
                onChange={(e) => updateItem(it.id, { username: e.target.value })}
                className="w-24 rounded-md bg-white/5 px-2 py-1 text-xs outline-none focus:bg-white/10"
              />
              <input
                value={it.provider}
                placeholder="Provider"
                onChange={(e) => updateItem(it.id, { provider: e.target.value })}
                className="w-20 rounded-md bg-white/5 px-2 py-1 text-xs outline-none focus:bg-white/10"
              />
              <input
                type="number"
                value={it.amount}
                onChange={(e) => updateItem(it.id, { amount: Number(e.target.value) })}
                className="w-20 rounded-md bg-white/5 px-2 py-1 text-xs outline-none focus:bg-white/10"
              />
              <input
                value={it.avatar}
                placeholder="Avatar URL (optional)"
                onChange={(e) => updateItem(it.id, { avatar: e.target.value })}
                className="flex-1 rounded-md bg-white/5 px-2 py-1 text-xs outline-none focus:bg-white/10"
              />
              <button
                onClick={() => removeItem(it.id)}
                className="text-destructive hover:text-destructive/80"
                aria-label="Remove"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>

        <button
          onClick={save}
          disabled={saving}
          className="rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground transition hover:opacity-90 disabled:opacity-50"
        >
          {saving ? "Saving…" : "Save Tracker"}
        </button>
      </div>
    </AdminShell>
  );
};

export default AdminLiveTrackerCustomize;
