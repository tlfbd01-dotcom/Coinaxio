import Header from "@/components/Header";
import DesktopSidebar from "@/components/DesktopSidebar";
import UserActivity from "@/components/UserActivity";
import PopularOffers from "@/components/PopularOffers";
import FeaturedBanners from "@/components/FeaturedBanners";
import Partners from "@/components/Partners";
import Footer from "@/components/Footer";
import BottomNav from "@/components/BottomNav";
import DashboardBackground from "@/components/DashboardBackground";
import CoinParticles from "@/components/landing/CoinParticles";

const Dashboard = () => {
  return (
    <div className="relative mx-auto flex min-h-screen w-full overflow-x-clip bg-black/40 text-foreground">
      <DashboardBackground />
      <CoinParticles />
      <DesktopSidebar />
      <div className="flex min-h-screen min-w-0 flex-1 flex-col pb-24 lg:pb-0">
        <Header />
        <UserActivity />
        <PopularOffers />
        <FeaturedBanners />
        <Partners />
        <Footer />
      </div>
      <BottomNav />
    </div>
  );
};

export default Dashboard;
