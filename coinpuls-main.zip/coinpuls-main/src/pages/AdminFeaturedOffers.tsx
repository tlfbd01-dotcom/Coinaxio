import { useEffect, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface F {
  id: string;
  title: string;
  subtitle: string | null;
  image_url: string | null;
  cta_url: string | null;
  is_active: boolean;
  sort_order: number;
}

const AdminFeaturedOffers = () => {
  const [items, setItems] = useState<F[]>([]);
  const [form, setForm] = useState({ title: "", subtitle: "", image_url: "", cta_url: "" });

  const load = () => {
    supabase
      .from("featured_offers")
      .select("*")
      .order("sort_order")
      .then(({ data }) => setItems((data as F[]) ?? []));
  };
  useEffect(load, []);

  const add = async () => {
    if (!form.title) return;
    const { error } = await supabase.from("featured_offers").insert(form);
    if (error) toast({ title: "Failed", description: error.message, variant: "destructive" });
    else {
      setForm({ title: "", subtitle: "", image_url: "", cta_url: "" });
      load();
    }
  };

  const toggle = async (f: F) => {
    await supabase.from("featured_offers").update({ is_active: !f.is_active }).eq("id", f.id);
    load();
  };

  const remove = async (id: string) => {
    await supabase.from("featured_offers").delete().eq("id", id);
    load();
  };

  return (
    <AdminShell title="Featured Offers" description="Curate highlighted offers">
      <div className="mb-3 grid grid-cols-1 gap-2">
        <input placeholder="title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs" />
        <input placeholder="subtitle" value={form.subtitle} onChange={(e) => setForm({ ...form, subtitle: e.target.value })} className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs" />
        <input placeholder="image url" value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs" />
        <input placeholder="cta url" value={form.cta_url} onChange={(e) => setForm({ ...form, cta_url: e.target.value })} className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs" />
      </div>
      <button onClick={add} className="mb-5 w-full rounded-lg bg-primary py-2 text-xs font-bold text-primary-foreground">Add Featured</button>

      <div className="flex flex-col gap-2">
        {items.map((f) => (
          <div key={f.id} className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-3 py-2">
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold">{f.title}</p>
              {f.subtitle && <p className="truncate text-[10px] text-muted-foreground">{f.subtitle}</p>}
            </div>
            <div className="flex gap-2">
              <button onClick={() => toggle(f)} className={`rounded-full px-3 py-1 text-xs font-bold ${f.is_active ? "bg-primary/20 text-primary" : "bg-white/10 text-muted-foreground"}`}>
                {f.is_active ? "On" : "Off"}
              </button>
              <button onClick={() => remove(f.id)} className="rounded-full bg-destructive/20 px-3 py-1 text-xs font-bold text-destructive">✕</button>
            </div>
          </div>
        ))}
      </div>
    </AdminShell>
  );
};

export default AdminFeaturedOffers;
