import { useEffect, useRef, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { useStorageUpload } from "@/hooks/useStorageUpload";
import { toast } from "@/hooks/use-toast";
import { Upload, Play } from "lucide-react";

const KEY = "site_sounds";

interface SoundConfig {
  enabled: boolean;
  volume: number; // 0-100
  clickUrl: string;
  rewardUrl: string;
  notifyUrl: string;
}

const defaults: SoundConfig = {
  enabled: true,
  volume: 70,
  clickUrl: "",
  rewardUrl: "",
  notifyUrl: "",
};

const slots: { key: keyof Omit<SoundConfig, "enabled" | "volume">; label: string; folder: string }[] = [
  { key: "clickUrl", label: "Button click sound", folder: "sounds/click" },
  { key: "rewardUrl", label: "Reward / coin sound", folder: "sounds/reward" },
  { key: "notifyUrl", label: "Notification sound", folder: "sounds/notify" },
];

const AdminSoundCustomize = () => {
  const [cfg, setCfg] = useState<SoundConfig>(defaults);
  const [saving, setSaving] = useState(false);
  const [uploadingKey, setUploadingKey] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { upload } = useStorageUpload({ folder: "sounds" });

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("site_settings")
        .select("value")
        .eq("key", KEY)
        .maybeSingle();
      if (data?.value && typeof data.value === "object") {
        setCfg({ ...defaults, ...(data.value as Partial<SoundConfig>) });
      }
    })();
  }, []);

  const handleUpload = async (slotKey: keyof SoundConfig, file: File) => {
    setUploadingKey(slotKey as string);
    const url = await upload(file);
    setUploadingKey(null);
    if (url) setCfg({ ...cfg, [slotKey]: url });
  };

  const playPreview = (url: string) => {
    if (!url) return;
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = url;
      audioRef.current.volume = cfg.volume / 100;
      audioRef.current.play().catch(() => {});
    }
  };

  const save = async () => {
    setSaving(true);
    const { error } = await supabase
      .from("site_settings")
      .upsert([{ key: KEY, value: cfg as any }], { onConflict: "key" });
    setSaving(false);
    if (error) {
      toast({ title: "Save failed", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Sound settings saved" });
    }
  };

  return (
    <AdminShell title="Sound Customize" description="Manage UI sound effects">
      <audio ref={audioRef} hidden />
      <div className="flex flex-col gap-5">
        <div className="glass-card flex items-center justify-between rounded-2xl p-4">
          <div>
            <p className="text-sm font-semibold">Sound effects</p>
            <p className="text-xs text-muted-foreground">Enable or disable all UI sounds</p>
          </div>
          <button
            onClick={() => setCfg({ ...cfg, enabled: !cfg.enabled })}
            className={`relative h-7 w-12 rounded-full transition ${cfg.enabled ? "bg-primary" : "bg-white/10"}`}
          >
            <span
              className={`absolute top-1 h-5 w-5 rounded-full bg-white transition-all ${
                cfg.enabled ? "left-6" : "left-1"
              }`}
            />
          </button>
        </div>

        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium">Master volume: {cfg.volume}%</label>
          <input
            type="range"
            min={0}
            max={100}
            value={cfg.volume}
            onChange={(e) => setCfg({ ...cfg, volume: Number(e.target.value) })}
          />
        </div>

        {slots.map((s) => (
          <div key={s.key} className="glass-card flex flex-col gap-2 rounded-xl p-4">
            <p className="text-sm font-semibold">{s.label}</p>
            <div className="flex gap-2">
              <label className="flex flex-1 cursor-pointer items-center gap-2 rounded-lg border border-dashed border-white/15 px-3 py-2 text-xs transition hover:border-primary/40">
                <Upload className="h-4 w-4 text-primary" />
                <span className="truncate">
                  {uploadingKey === s.key
                    ? "Uploading…"
                    : cfg[s.key]
                      ? "Replace audio"
                      : "Upload audio (mp3, wav)"}
                </span>
                <input
                  type="file"
                  accept="audio/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleUpload(s.key, file);
                  }}
                />
              </label>
              {cfg[s.key] && (
                <button
                  onClick={() => playPreview(cfg[s.key] as string)}
                  className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/15 text-primary transition hover:bg-primary/25"
                  aria-label="Preview"
                >
                  <Play className="h-4 w-4" />
                </button>
              )}
            </div>
            {cfg[s.key] && (
              <p className="truncate text-[10px] text-muted-foreground">{cfg[s.key]}</p>
            )}
          </div>
        ))}

        <button
          onClick={save}
          disabled={saving}
          className="rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground transition hover:opacity-90 disabled:opacity-50"
        >
          {saving ? "Saving…" : "Save Sounds"}
        </button>
      </div>
    </AdminShell>
  );
};

export default AdminSoundCustomize;
