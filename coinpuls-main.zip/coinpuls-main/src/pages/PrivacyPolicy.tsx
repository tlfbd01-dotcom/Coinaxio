import PageShell from "@/components/PageShell";

const PrivacyPolicy = () => (
  <PageShell title="Privacy Policy" subtitle="How we handle your data">
    <article className="prose prose-invert max-w-none space-y-4 text-sm text-muted-foreground">
      <p>COINTO respects your privacy. This page explains what we collect and how we use it.</p>
      <h2 className="text-base font-bold text-foreground">Information we collect</h2>
      <p>Account info, offer activity, payout details, and basic device data.</p>
      <h2 className="text-base font-bold text-foreground">How we use it</h2>
      <p>To verify offer completions, prevent fraud, and process withdrawals.</p>
      <h2 className="text-base font-bold text-foreground">Sharing</h2>
      <p>We share minimal data with offer partners to confirm completions.</p>
      <h2 className="text-base font-bold text-foreground">Contact</h2>
      <p>Email support to request data deletion or corrections.</p>
    </article>
  </PageShell>
);

export default PrivacyPolicy;
