import { useEffect, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { useStorageUpload } from "@/hooks/useStorageUpload";
import { toast } from "@/hooks/use-toast";
import { Upload, Trash2, Play } from "lucide-react";
import {
  defaultFeaturedBanners,
  type FeaturedBannerItem,
  type FeaturedBannersConfig,
} from "@/components/FeaturedBanners";

const KEY = "featured_banners";

const BannerEditor = ({
  side,
  item,
  onChange,
}: {
  side: "left" | "right";
  item: FeaturedBannerItem;
  onChange: (next: FeaturedBannerItem) => void;
}) => {
  const { upload, uploading } = useStorageUpload({ folder: "featured-banners" });

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await upload(file);
    if (url) onChange({ ...item, imageUrl: url });
  };

  const previewStyle: React.CSSProperties = item.imageUrl
    ? {
        backgroundImage: `linear-gradient(hsla(0,0%,0%,${item.overlayOpacity / 100}), hsla(0,0%,0%,${item.overlayOpacity / 100})), url(${item.imageUrl})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }
    : { background: "linear-gradient(135deg, hsl(var(--primary) / 0.2), hsl(var(--primary) / 0.05))" };

  return (
    <div className="glass-card flex flex-col gap-3 rounded-2xl border border-white/10 p-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold capitalize text-primary">{side} banner</h3>
      </div>

      {/* Live preview */}
      <div
        style={previewStyle}
        className="relative flex h-32 flex-col justify-between overflow-hidden rounded-xl border border-white/10 p-3"
      >
        <div className="absolute right-2 top-2 flex h-5 w-5 items-center justify-center rounded-full bg-black/50">
          <Play className="h-2.5 w-2.5 fill-current" />
        </div>
        <span className="text-[10px] font-bold text-purple-300">{item.label}</span>
        <div>
          <p className="text-xs font-bold">{item.title}</p>
          <p className="text-[10px] text-gray-300">{item.subtitle}</p>
        </div>
        {item.caption && (
          <span className="text-right text-[9px] text-purple-400">{item.caption}</span>
        )}
      </div>

      {/* Image upload */}
      <label className="glass-card flex cursor-pointer items-center gap-3 rounded-xl border border-dashed border-white/15 p-3 transition hover:border-primary/40">
        <Upload className="h-4 w-4 text-primary" />
        <span className="text-xs">{uploading ? "Uploading…" : "Upload background image"}</span>
        <input type="file" accept="image/*" onChange={handleFile} className="hidden" />
      </label>
      <input
        value={item.imageUrl}
        placeholder="…or paste an image URL"
        onChange={(e) => onChange({ ...item, imageUrl: e.target.value })}
        className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs outline-none focus:border-primary"
      />
      {item.imageUrl && (
        <button
          onClick={() => onChange({ ...item, imageUrl: "" })}
          className="flex items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-destructive/10 py-2 text-xs font-semibold text-destructive transition hover:bg-destructive/20"
        >
          <Trash2 className="h-3.5 w-3.5" /> Remove image
        </button>
      )}

      {/* Overlay slider */}
      <div className="flex flex-col gap-1">
        <label className="text-[11px] text-muted-foreground">
          Dark overlay: {item.overlayOpacity}%
        </label>
        <input
          type="range"
          min={0}
          max={90}
          value={item.overlayOpacity}
          onChange={(e) => onChange({ ...item, overlayOpacity: Number(e.target.value) })}
        />
      </div>

      {/* Text fields */}
      <div className="grid grid-cols-2 gap-2">
        <Field
          label="Label"
          value={item.label}
          onChange={(v) => onChange({ ...item, label: v })}
        />
        <Field
          label="Caption"
          value={item.caption}
          onChange={(v) => onChange({ ...item, caption: v })}
        />
      </div>
      <Field
        label="Title"
        value={item.title}
        onChange={(v) => onChange({ ...item, title: v })}
      />
      <Field
        label="Subtitle"
        value={item.subtitle}
        onChange={(v) => onChange({ ...item, subtitle: v })}
      />
      <Field
        label="Click URL (optional)"
        value={item.ctaUrl}
        onChange={(v) => onChange({ ...item, ctaUrl: v })}
      />
    </div>
  );
};

const Field = ({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) => (
  <div className="flex flex-col gap-1">
    <label className="text-[11px] font-medium text-muted-foreground">{label}</label>
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs outline-none focus:border-primary"
    />
  </div>
);

const AdminFeaturedBanners = () => {
  const [cfg, setCfg] = useState<FeaturedBannersConfig>(defaultFeaturedBanners);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("site_settings")
        .select("value")
        .eq("key", KEY)
        .maybeSingle();
      if (data?.value && typeof data.value === "object") {
        setCfg({ ...defaultFeaturedBanners, ...(data.value as Partial<FeaturedBannersConfig>) });
      }
    })();
  }, []);

  const save = async () => {
    setSaving(true);
    const { error } = await supabase
      .from("site_settings")
      .upsert([{ key: KEY, value: cfg as never }], { onConflict: "key" });
    setSaving(false);
    if (error) {
      toast({ title: "Save failed", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Featured banners saved", description: "Changes are live." });
    }
  };

  return (
    <AdminShell
      title="Featured Banners"
      description="Customize the two banners under the homepage. Recommended image size: 600×400px (each card is ~h-40 / 160px tall on desktop)."
    >
      <div className="flex flex-col gap-5">
        <Field
          label="Section title"
          value={cfg.title}
          onChange={(v) => setCfg({ ...cfg, title: v })}
        />

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <BannerEditor
            side="left"
            item={cfg.left}
            onChange={(next) => setCfg({ ...cfg, left: next })}
          />
          <BannerEditor
            side="right"
            item={cfg.right}
            onChange={(next) => setCfg({ ...cfg, right: next })}
          />
        </div>

        <button
          onClick={save}
          disabled={saving}
          className="rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground transition hover:opacity-90 disabled:opacity-50"
        >
          {saving ? "Saving…" : "Save Featured Banners"}
        </button>
      </div>
    </AdminShell>
  );
};

export default AdminFeaturedBanners;
