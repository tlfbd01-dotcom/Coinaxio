import { useEffect, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { Facebook, Twitter, Instagram, Youtube, Send, MessageCircle, Github, Globe } from "lucide-react";

const KEY = "site_social_links";

interface SocialLinks {
  facebook: string;
  twitter: string;
  instagram: string;
  youtube: string;
  telegram: string;
  whatsapp: string;
  discord: string;
  website: string;
}

const fields: { key: keyof SocialLinks; label: string; icon: typeof Globe; placeholder: string }[] = [
  { key: "facebook", label: "Facebook", icon: Facebook, placeholder: "https://facebook.com/yourpage" },
  { key: "twitter", label: "Twitter / X", icon: Twitter, placeholder: "https://x.com/yourpage" },
  { key: "instagram", label: "Instagram", icon: Instagram, placeholder: "https://instagram.com/yourpage" },
  { key: "youtube", label: "YouTube", icon: Youtube, placeholder: "https://youtube.com/@yourchannel" },
  { key: "telegram", label: "Telegram", icon: Send, placeholder: "https://t.me/yourgroup" },
  { key: "whatsapp", label: "WhatsApp", icon: MessageCircle, placeholder: "https://wa.me/8801XXXXXXXXX" },
  { key: "discord", label: "Discord", icon: Github, placeholder: "https://discord.gg/your-invite" },
  { key: "website", label: "Website", icon: Globe, placeholder: "https://yoursite.com" },
];

const empty: SocialLinks = {
  facebook: "",
  twitter: "",
  instagram: "",
  youtube: "",
  telegram: "",
  whatsapp: "",
  discord: "",
  website: "",
};

const AdminSocialLinksCustomize = () => {
  const [links, setLinks] = useState<SocialLinks>(empty);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("site_settings")
        .select("value")
        .eq("key", KEY)
        .maybeSingle();
      if (data?.value && typeof data.value === "object") {
        setLinks({ ...empty, ...(data.value as Partial<SocialLinks>) });
      }
    })();
  }, []);

  const save = async () => {
    setSaving(true);
    const { error } = await supabase
      .from("site_settings")
      .upsert([{ key: KEY, value: links as any }], { onConflict: "key" });
    setSaving(false);
    if (error) {
      toast({ title: "Save failed", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Social links saved" });
    }
  };

  return (
    <AdminShell title="Social Links" description="Update footer & contact social links">
      <div className="flex flex-col gap-3">
        {fields.map(({ key, label, icon: Icon, placeholder }) => (
          <div key={key} className="flex flex-col gap-1.5">
            <label className="flex items-center gap-2 text-sm font-medium">
              <Icon className="h-4 w-4 text-primary" /> {label}
            </label>
            <input
              type="url"
              value={links[key]}
              placeholder={placeholder}
              onChange={(e) => setLinks({ ...links, [key]: e.target.value })}
              className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none focus:border-primary"
            />
          </div>
        ))}

        <button
          onClick={save}
          disabled={saving}
          className="mt-3 rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground transition hover:opacity-90 disabled:opacity-50"
        >
          {saving ? "Saving…" : "Save Links"}
        </button>
      </div>
    </AdminShell>
  );
};

export default AdminSocialLinksCustomize;
