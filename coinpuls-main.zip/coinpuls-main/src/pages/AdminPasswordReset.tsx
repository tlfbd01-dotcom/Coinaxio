import { useEffect, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { KeyRound, Search, ShieldAlert, Eye, EyeOff, Save } from "lucide-react";

interface UserRow {
  user_id: string;
  email: string;
  display_name: string | null;
  username: string | null;
}

const AdminPasswordReset = () => {
  const [query, setQuery] = useState("");
  const [users, setUsers] = useState<UserRow[]>([]);
  const [searching, setSearching] = useState(false);
  const [selected, setSelected] = useState<UserRow | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [resetting, setResetting] = useState(false);

  const search = async () => {
    setSearching(true);
    const { data, error } = await supabase.functions.invoke("admin-reset-password", {
      body: { action: "search", query },
    });
    setSearching(false);
    if (error || (data && (data as { error?: string }).error)) {
      const msg = error?.message ?? (data as { error?: string })?.error ?? "Search failed";
      toast({ title: "Search failed", description: msg, variant: "destructive" });
      return;
    }
    setUsers(((data as { users: UserRow[] })?.users ?? []) as UserRow[]);
  };

  useEffect(() => {
    search();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const reset = async () => {
    if (!selected) return;
    if (newPassword.length < 6) {
      toast({ title: "Password too short", description: "Minimum 6 characters", variant: "destructive" });
      return;
    }
    if (newPassword !== confirmPassword) {
      toast({ title: "Passwords don't match", description: "Confirm password must match", variant: "destructive" });
      return;
    }
    setResetting(true);
    const { data, error } = await supabase.functions.invoke("admin-reset-password", {
      body: { user_id: selected.user_id, new_password: newPassword },
    });
    setResetting(false);
    if (error || (data && (data as { error?: string }).error)) {
      const msg = error?.message ?? (data as { error?: string })?.error ?? "Reset failed";
      toast({ title: "Reset failed", description: msg, variant: "destructive" });
      return;
    }
    toast({ title: "Password updated", description: `New password set for ${selected.email}` });
    setNewPassword("");
    setConfirmPassword("");
    setSelected(null);
  };

  return (
    <AdminShell title="Password Reset" description="Reset a user's password">
      <div className="flex flex-col gap-5">
        <div className="flex items-start gap-3 rounded-xl border border-amber-500/30 bg-amber-500/5 p-3">
          <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
          <p className="text-xs text-amber-200">
            Use carefully. The user will lose access until you share the new password with them.
          </p>
        </div>

        {/* Search */}
        <div className="flex gap-2">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && search()}
            placeholder="Search by email"
            className="flex-1 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm outline-none focus:border-primary"
          />
          <button
            onClick={search}
            disabled={searching}
            className="flex items-center gap-1.5 rounded-xl bg-primary px-4 text-sm font-bold text-primary-foreground transition hover:opacity-90 disabled:opacity-50"
          >
            <Search className="h-4 w-4" /> {searching ? "…" : "Search"}
          </button>
        </div>

        {/* User list */}
        <div className="flex flex-col gap-2">
          {users.length === 0 && !searching && (
            <p className="text-sm text-muted-foreground">No users found.</p>
          )}
          {users.map((u) => (
            <button
              key={u.user_id}
              onClick={() => setSelected(u)}
              className={`flex items-center justify-between rounded-xl border px-3 py-2.5 text-left text-sm transition ${
                selected?.user_id === u.user_id
                  ? "border-primary bg-primary/10"
                  : "border-white/10 bg-white/5 hover:bg-white/10"
              }`}
            >
              <div className="min-w-0">
                <p className="truncate font-semibold">{u.display_name ?? u.email}</p>
                <p className="truncate text-[11px] text-muted-foreground">{u.email}</p>
              </div>
              {selected?.user_id === u.user_id && (
                <span className="text-xs font-bold text-primary">Selected</span>
              )}
            </button>
          ))}
        </div>

        {/* Reset card — styled like the mockup */}
        {selected && (
          <div className="mx-auto w-full max-w-md rounded-2xl border border-white/10 bg-neutral-950/80 p-5 shadow-xl">
            <div className="mb-4 flex items-center gap-2">
              <KeyRound className="h-5 w-5 text-emerald-400" />
              <h2 className="text-base font-bold">
                Reset <span className="text-primary">Admin</span> Password
              </h2>
            </div>

            {/* Current Email */}
            <label className="mb-1 block text-[11px] font-semibold text-primary">Current Email</label>
            <input
              value={selected.email}
              readOnly
              className="mb-4 w-full cursor-not-allowed rounded-full border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-muted-foreground outline-none"
            />

            {/* New Password */}
            <label className="mb-1 block text-[11px] font-semibold text-primary">New Password</label>
            <div className="relative mb-4">
              <input
                type={showNew ? "text" : "password"}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Enter new password"
                className="w-full rounded-full border border-white/10 bg-white px-4 py-2.5 pr-10 text-sm text-neutral-900 outline-none focus:border-primary"
              />
              <button
                type="button"
                onClick={() => setShowNew((v) => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-emerald-500"
                aria-label="Toggle password visibility"
              >
                {showNew ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>

            {/* Confirm Password */}
            <label className="mb-1 block text-[11px] font-semibold text-primary">Confirm Password</label>
            <input
              type={showConfirm ? "text" : "password"}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirm password"
              className="mb-5 w-full rounded-full border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-foreground outline-none focus:border-primary placeholder:text-muted-foreground"
              onDoubleClick={() => setShowConfirm((v) => !v)}
            />

            {/* Update button */}
            <button
              onClick={reset}
              disabled={resetting || newPassword.length < 6 || newPassword !== confirmPassword}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-emerald-500 py-3 text-sm font-bold text-neutral-900 transition hover:bg-emerald-400 disabled:opacity-50"
            >
              <Save className="h-4 w-4" />
              {resetting ? "Updating…" : "Update Password"}
            </button>
          </div>
        )}
      </div>
    </AdminShell>
  );
};

export default AdminPasswordReset;
