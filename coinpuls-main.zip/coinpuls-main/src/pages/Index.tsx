import { Navigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";
import DesktopSidebar from "@/components/DesktopSidebar";
import UserActivity from "@/components/UserActivity";
import PopularOffers from "@/components/PopularOffers";
import FeaturedBanners from "@/components/FeaturedBanners";
import Partners from "@/components/Partners";
import Footer from "@/components/Footer";
import BottomNav from "@/components/BottomNav";
import CookieConsent from "@/components/CookieConsent";
import HeroSection from "@/components/landing/HeroSection";
import StatsSection from "@/components/landing/StatsSection";
import TrustBadges from "@/components/landing/TrustBadges";
import HowItWorks from "@/components/landing/HowItWorks";
import FaqSection from "@/components/landing/FaqSection";
import CtaBanner from "@/components/landing/CtaBanner";
import CoinParticles from "@/components/landing/CoinParticles";

const Index = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center bg-background text-sm text-muted-foreground">Loading…</div>;
  }

  if (user) {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <div className="relative mx-auto flex min-h-screen w-full overflow-x-clip bg-black/80 text-foreground">
      <CoinParticles />
      <DesktopSidebar />
      <div className="flex min-h-screen min-w-0 flex-1 flex-col pb-24 lg:pb-0">
        <Header />
        <UserActivity />
        <HeroSection />
        <PopularOffers />
        <StatsSection />
        <TrustBadges />
        <FeaturedBanners />
        <HowItWorks />
        <Partners />
        <FaqSection />
        <CtaBanner />
        <Footer />
      </div>
      <BottomNav />
      <CookieConsent />
    </div>
  );
};

export default Index;
