import { useEffect, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { RefreshCw, CheckCircle2, AlertCircle } from "lucide-react";

interface SyncMeta {
  last_sync?: string;
  inserted?: number;
  updated?: number;
  skipped?: number;
  total?: number;
}

interface AutoCfg {
  enabled: boolean;
  interval_minutes: number;
  last_run_at?: string | null;
}

const AdminNotikImport = () => {
  const [meta, setMeta] = useState<SyncMeta>({});
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [offerCount, setOfferCount] = useState<number>(0);
  const [auto, setAuto] = useState<AutoCfg>({ enabled: true, interval_minutes: 60, last_run_at: null });
  const [savingAuto, setSavingAuto] = useState(false);

  const loadMeta = async () => {
    const { data } = await supabase
      .from("site_settings")
      .select("value")
      .eq("key", "notik_sync")
      .maybeSingle();
    if (data?.value) setMeta(data.value as SyncMeta);

    const { data: a } = await supabase
      .from("site_settings")
      .select("value")
      .eq("key", "notik_auto_sync")
      .maybeSingle();
    if (a?.value) setAuto({ enabled: true, interval_minutes: 60, last_run_at: null, ...(a.value as any) });

    const { data: prov } = await supabase
      .from("providers").select("id").eq("slug", "notik").maybeSingle();
    if (prov?.id) {
      const { count } = await supabase
        .from("offers")
        .select("id", { count: "exact", head: true })
        .eq("provider_id", prov.id)
        .eq("is_active", true);
      setOfferCount(count ?? 0);
    }
  };

  useEffect(() => { loadMeta(); }, []);

  const saveAuto = async (next: Partial<AutoCfg>) => {
    const merged = { ...auto, ...next };
    setAuto(merged);
    setSavingAuto(true);
    const { error } = await supabase
      .from("site_settings")
      .upsert({ key: "notik_auto_sync", value: merged as any }, { onConflict: "key" });
    setSavingAuto(false);
    if (error) toast({ title: "Save failed", description: error.message, variant: "destructive" });
    else toast({ title: "Auto-sync settings saved" });
  };

  const sync = async () => {
    setBusy(true);
    setResult(null);
    try {
      const { data, error } = await supabase.functions.invoke("notik-sync");
      if (error) throw error;
      setResult(data);
      if ((data as any)?.error) {
        toast({ title: "Sync failed", description: (data as any).error, variant: "destructive" });
      } else {
        toast({
          title: "Synced",
          description: `Total ${data.total} · Added ${data.inserted} · Updated ${data.updated}`,
        });
      }
      await loadMeta();
    } catch (e: any) {
      toast({ title: "Sync error", description: e?.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <AdminShell title="Notik Import" description="Auto-sync offers from Notik publisher API">
      <div className="mx-auto flex w-full max-w-[310px] flex-col gap-5 pb-24">
        <section className="rounded-2xl border border-white/10 bg-neutral-900/60 p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-base font-bold text-primary sm:text-lg">Notik Sync</h2>
            <span className={`rounded-full px-2 py-0.5 text-[11px] font-bold ${offerCount > 0 ? "bg-primary/20 text-primary" : "bg-white/10 text-muted-foreground"}`}>
              {offerCount} active offers
            </span>
          </div>

          <div className="mb-4 grid grid-cols-2 gap-3 text-xs">
            <Stat label="Last sync" value={meta.last_sync ? new Date(meta.last_sync).toLocaleString() : "Never"} />
            <Stat label="Total fetched" value={meta.total ?? "—"} />
            <Stat label="Inserted" value={meta.inserted ?? "—"} />
            <Stat label="Updated" value={meta.updated ?? "—"} />
          </div>

          <button
            onClick={sync}
            disabled={busy}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary py-2.5 text-sm font-bold text-primary-foreground disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 ${busy ? "animate-spin" : ""}`} />
            {busy ? "Syncing…" : "Sync Now"}
          </button>

          {result && (
            <div className={`mt-4 rounded-lg border p-3 text-xs ${result.error ? "border-destructive/40 bg-destructive/10 text-destructive" : "border-primary/30 bg-primary/10 text-foreground"}`}>
              <div className="mb-1 flex items-center gap-1.5 font-bold">
                {result.error ? <AlertCircle className="h-3.5 w-3.5" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
                {result.error ? "Error" : "Success"}
              </div>
              <pre className="whitespace-pre-wrap break-words text-[10px] opacity-80">
                {JSON.stringify(result, null, 2)}
              </pre>
            </div>
          )}
        </section>

        <section className="rounded-2xl border border-white/10 bg-neutral-900/60 p-5">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-base font-bold text-primary">Auto-Sync</h2>
            <label className="flex items-center gap-2 text-xs">
              <input
                type="checkbox"
                checked={auto.enabled}
                onChange={(e) => saveAuto({ enabled: e.target.checked })}
                className="h-4 w-4 accent-primary"
              />
              <span className="font-bold">{auto.enabled ? "On" : "Off"}</span>
            </label>
          </div>
          <label className="block text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
            Interval (minutes)
          </label>
          <div className="mt-2 flex items-center gap-2">
            <input
              type="number"
              min={5}
              value={auto.interval_minutes}
              onChange={(e) => setAuto({ ...auto, interval_minutes: Math.max(5, parseInt(e.target.value) || 60) })}
              className="w-24 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm"
            />
            <button
              onClick={() => saveAuto({ interval_minutes: auto.interval_minutes })}
              disabled={savingAuto}
              className="rounded-lg bg-primary px-3 py-2 text-xs font-bold text-primary-foreground disabled:opacity-50"
            >
              {savingAuto ? "Saving…" : "Save"}
            </button>
          </div>
          <p className="mt-2 text-[10px] text-muted-foreground">
            Last auto-run: {auto.last_run_at ? new Date(auto.last_run_at).toLocaleString() : "Never"}
          </p>
        </section>

        <section className="rounded-2xl border border-white/10 bg-neutral-900/60 p-5 text-xs text-muted-foreground">
          <p className="mb-2 font-bold text-foreground">How it works</p>
          <ul className="list-inside list-disc space-y-1">
            <li>Pulls all offers from Notik's <code>get-offers/all</code> endpoint</li>
            <li>Pulls top-converting offers and marks them as featured</li>
            <li>Upserts into the <code>offers</code> table — All Offers & Popular Offers reflect changes instantly</li>
            <li>Auto-Sync chalu thakle background-e prati {auto.interval_minutes} minute por automatic sync hobe</li>
          </ul>
        </section>
      </div>
    </AdminShell>
  );
};

const Stat = ({ label, value }: { label: string; value: string | number }) => (
  <div className="rounded-lg border border-white/10 bg-white/5 p-2.5">
    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
    <p className="mt-1 font-bold">{String(value)}</p>
  </div>
);

export default AdminNotikImport;
