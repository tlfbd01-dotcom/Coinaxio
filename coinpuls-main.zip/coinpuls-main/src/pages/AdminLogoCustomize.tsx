import { useEffect, useRef, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { useStorageUpload } from "@/hooks/useStorageUpload";
import { toast } from "@/hooks/use-toast";
import { clearSiteSettingCache } from "@/hooks/useSiteSetting";
import { Upload, Eye, Type, Image as ImageIcon, Palette, Coins, RotateCcw, Save } from "lucide-react";

const KEY = "site_logo";

interface LogoConfig {
  url: string;
  text: string;
  avatarUrl: string; // coin icon (used in live tracker / balance)
  loadingUrl: string;
}

const defaults: LogoConfig = {
  url: "",
  text: "COINTO",
  avatarUrl: "",
  loadingUrl: "",
};

const AdminLogoCustomize = () => {
  const [cfg, setCfg] = useState<LogoConfig>(defaults);
  const [initial, setInitial] = useState<LogoConfig>(defaults);
  const [mode, setMode] = useState<"text" | "image">("image");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState<"logo" | "coin" | null>(null);
  const { upload } = useStorageUpload({ folder: "logos" });

  const logoInputRef = useRef<HTMLInputElement>(null);
  const coinInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("site_settings")
        .select("value")
        .eq("key", KEY)
        .maybeSingle();
      if (data?.value && typeof data.value === "object") {
        const merged = { ...defaults, ...(data.value as Partial<LogoConfig>) };
        setCfg(merged);
        setInitial(merged);
        setMode(merged.url ? "image" : "text");
      }
    })();
  }, []);

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading("logo");
    const url = await upload(file);
    setUploading(null);
    if (url) setCfg((c) => ({ ...c, url }));
  };

  const handleCoinUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading("coin");
    const url = await upload(file);
    setUploading(null);
    if (url) setCfg((c) => ({ ...c, avatarUrl: url }));
  };

  const resetLogo = () => setCfg((c) => ({ ...c, url: "", text: defaults.text }));
  const resetCoin = () => setCfg((c) => ({ ...c, avatarUrl: "" }));

  const save = async () => {
    setSaving(true);
    const { error } = await supabase
      .from("site_settings")
      .upsert([{ key: KEY, value: cfg as any }], { onConflict: "key" });
    setSaving(false);
    if (error) {
      toast({ title: "Save failed", description: error.message, variant: "destructive" });
    } else {
      setInitial(cfg);
      clearSiteSettingCache(KEY);
      toast({ title: "Saved", description: "Logo & icon updated" });
    }
  };

  return (
    <AdminShell title="Logo & Icon" description="Customize your brand logo and coin icon">
      <div className="mx-auto flex max-w-2xl flex-col gap-5 pb-24">
        {/* Logo Customize Card */}
        <section className="rounded-2xl border border-white/10 bg-neutral-900/60 p-4 sm:p-5">
          <div className="mb-4 flex items-center gap-2">
            <Palette className="h-5 w-5 text-primary" />
            <h2 className="text-base font-bold text-primary sm:text-lg">Logo Customize</h2>
          </div>

          {/* Preview */}
          <div className="mb-4 rounded-xl border border-white/10 bg-black/40 p-5">
            <div className="mb-3 flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
              <Eye className="h-3.5 w-3.5" /> Preview
            </div>
            <div className="flex min-h-[64px] items-center justify-center">
              {mode === "image" && cfg.url ? (
                <img src={cfg.url} alt="Logo preview" className="max-h-16 object-contain" />
              ) : (
                <span className="text-2xl font-extrabold tracking-wider sm:text-3xl">
                  {cfg.text || "—"}
                </span>
              )}
            </div>
          </div>

          {/* Mode tabs */}
          <div className="mb-3 grid grid-cols-2 gap-2 rounded-xl bg-black/40 p-1">
            <button
              onClick={() => setMode("text")}
              className={`flex items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-semibold transition ${
                mode === "text"
                  ? "bg-white/5 text-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Type className="h-4 w-4" /> Text
            </button>
            <button
              onClick={() => setMode("image")}
              className={`flex items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-semibold transition ${
                mode === "image"
                  ? "bg-primary text-primary-foreground shadow-lg shadow-primary/30"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <ImageIcon className="h-4 w-4" /> Image
            </button>
          </div>

          {mode === "image" ? (
            <button
              onClick={() => logoInputRef.current?.click()}
              disabled={uploading === "logo"}
              className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-black/40 py-3 text-sm font-semibold transition hover:bg-white/5 disabled:opacity-50"
            >
              <Upload className="h-4 w-4" />
              {uploading === "logo" ? "Uploading…" : cfg.url ? "Change Image" : "Upload Image"}
            </button>
          ) : (
            <input
              value={cfg.text}
              onChange={(e) => setCfg({ ...cfg, text: e.target.value })}
              maxLength={20}
              placeholder="Enter logo text"
              className="w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm outline-none focus:border-primary"
            />
          )}
          <input
            ref={logoInputRef}
            type="file"
            accept="image/*"
            onChange={handleLogoUpload}
            className="hidden"
          />

          <button
            onClick={resetLogo}
            className="mt-3 flex items-center gap-1.5 rounded-lg bg-white/5 px-3 py-1.5 text-xs text-muted-foreground transition hover:text-foreground"
          >
            <RotateCcw className="h-3 w-3" /> Reset Logo
          </button>
        </section>

        {/* Coin Icon Card */}
        <section className="rounded-2xl border border-white/10 bg-neutral-900/60 p-4 sm:p-5">
          <div className="mb-1 flex items-center gap-2">
            <Coins className="h-5 w-5 text-primary" />
            <h2 className="text-base font-bold text-primary sm:text-lg">Coin Icon Customize</h2>
          </div>
          <p className="mb-4 text-xs text-muted-foreground">
            This icon will appear in Live Tracker, Balance display, and other places.
          </p>

          <div className="mb-4 rounded-xl border border-white/10 bg-black/40 p-5">
            <div className="mb-3 flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
              <Eye className="h-3.5 w-3.5" /> Preview
            </div>
            <div className="flex items-center justify-center gap-4">
              <div className="flex h-14 w-14 items-center justify-center overflow-hidden rounded-xl bg-white/5">
                {cfg.avatarUrl ? (
                  <img src={cfg.avatarUrl} alt="Coin icon" className="h-full w-full object-contain" />
                ) : (
                  <Coins className="h-7 w-7 text-primary" />
                )}
              </div>
              <div className="flex items-center gap-2 rounded-full bg-black/60 px-4 py-2">
                {cfg.avatarUrl ? (
                  <img src={cfg.avatarUrl} alt="" className="h-5 w-5 object-contain" />
                ) : (
                  <Coins className="h-5 w-5 text-primary" />
                )}
                <span className="text-sm font-bold">1,234.50</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => coinInputRef.current?.click()}
            disabled={uploading === "coin"}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 bg-black/40 py-3 text-sm font-semibold transition hover:bg-white/5 disabled:opacity-50"
          >
            <Upload className="h-4 w-4" />
            {uploading === "coin" ? "Uploading…" : cfg.avatarUrl ? "Change Icon" : "Upload Icon"}
          </button>
          <input
            ref={coinInputRef}
            type="file"
            accept="image/*"
            onChange={handleCoinUpload}
            className="hidden"
          />

          <button
            onClick={resetCoin}
            className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-xl bg-white/5 py-2.5 text-xs text-muted-foreground transition hover:text-foreground"
          >
            <RotateCcw className="h-3 w-3" /> Reset to Default
          </button>
        </section>

        <button
          onClick={save}
          disabled={saving || uploading !== null}
          className="flex items-center justify-center gap-2 rounded-2xl bg-primary py-4 text-sm font-bold text-primary-foreground shadow-lg shadow-primary/30 transition hover:opacity-90 disabled:opacity-50"
        >
          <Save className="h-4 w-4" />
          {saving ? "Saving…" : "Save All Changes"}
        </button>
      </div>
    </AdminShell>
  );
};

export default AdminLogoCustomize;
