import { useEffect, useState } from "react";
import AdminShell from "@/components/AdminShell";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface RoleRow {
  id: string;
  user_id: string;
  role: "admin" | "moderator" | "user";
}
interface Profile {
  user_id: string;
  display_name: string | null;
  username: string | null;
}

const AdminRoleManagement = () => {
  const [roles, setRoles] = useState<RoleRow[]>([]);
  const [profiles, setProfiles] = useState<Record<string, Profile>>({});
  const [userId, setUserId] = useState("");
  const [role, setRole] = useState<"admin" | "moderator">("admin");

  const load = async () => {
    const { data } = await supabase.from("user_roles").select("*").order("created_at", { ascending: false });
    const list = (data as RoleRow[]) ?? [];
    setRoles(list);
    if (list.length) {
      const ids = [...new Set(list.map((r) => r.user_id))];
      const { data: profs } = await supabase
        .from("profiles")
        .select("user_id, display_name, username")
        .in("user_id", ids);
      const map: Record<string, Profile> = {};
      (profs ?? []).forEach((p) => (map[p.user_id] = p as Profile));
      setProfiles(map);
    }
  };
  useEffect(() => {
    load();
  }, []);

  const grant = async () => {
    if (!userId.trim()) return;
    const { error } = await supabase.from("user_roles").insert({ user_id: userId.trim(), role });
    if (error) toast({ title: "Failed", description: error.message, variant: "destructive" });
    else {
      setUserId("");
      load();
    }
  };

  const revoke = async (id: string) => {
    await supabase.from("user_roles").delete().eq("id", id);
    load();
  };

  return (
    <AdminShell title="Role Management" description="Grant admin / moderator roles">
      <div className="mb-3 flex flex-col gap-2">
        <input
          placeholder="User UUID (from Users page)"
          value={userId}
          onChange={(e) => setUserId(e.target.value)}
          className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs"
        />
        <div className="flex gap-2">
          <select
            value={role}
            onChange={(e) => setRole(e.target.value as any)}
            className="flex-1 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs"
          >
            <option value="admin">admin</option>
            <option value="moderator">moderator</option>
          </select>
          <button onClick={grant} className="rounded-lg bg-primary px-4 py-2 text-xs font-bold text-primary-foreground">
            Grant
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-2">
        {roles.map((r) => (
          <div
            key={r.id}
            className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-3 py-2"
          >
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold">
                {profiles[r.user_id]?.display_name ?? r.user_id.slice(0, 8) + "…"}
              </p>
              <p className="text-[10px] uppercase text-primary">{r.role}</p>
            </div>
            {r.role !== "user" && (
              <button
                onClick={() => revoke(r.id)}
                className="rounded-full bg-destructive/20 px-3 py-1 text-xs font-bold text-destructive"
              >
                Revoke
              </button>
            )}
          </div>
        ))}
      </div>
    </AdminShell>
  );
};

export default AdminRoleManagement;
