import { useEffect, useState } from "react";
import PageShell from "@/components/PageShell";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/hooks/use-toast";
import { formatCoins, coinsToDollars } from "@/lib/coins";

interface PaymentMethod {
  id: string;
  name: string;
  min_amount: number;
  max_amount: number | null;
}

interface Withdrawal {
  id: string;
  amount: number;
  destination: string;
  status: string;
  created_at: string;
}

const Withdraw = () => {
  const { user } = useAuth();
  const [balance, setBalance] = useState(0);
  const [methods, setMethods] = useState<PaymentMethod[]>([]);
  const [methodId, setMethodId] = useState("");
  const [amount, setAmount] = useState("");
  const [destination, setDestination] = useState("");
  const [history, setHistory] = useState<Withdrawal[]>([]);
  const [busy, setBusy] = useState(false);

  const refresh = async () => {
    if (!user) return;
    const [{ data: prof }, { data: pm }, { data: hist }] = await Promise.all([
      supabase.from("profiles").select("balance").eq("user_id", user.id).maybeSingle(),
      supabase.from("payment_methods").select("*").eq("is_enabled", true).order("sort_order"),
      supabase
        .from("withdrawals")
        .select("id, amount, destination, status, created_at")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(10),
    ]);
    setBalance(Number(prof?.balance ?? 0));
    setMethods(pm ?? []);
    setHistory(hist ?? []);
    if (!methodId && pm && pm[0]) setMethodId(pm[0].id);
  };

  useEffect(() => {
    refresh();
  }, [user]);

  const submit = async () => {
    if (!user || !methodId) return;
    const coinsRequested = Number(amount);
    if (!coinsRequested || coinsRequested <= 0) return toast({ title: "Enter amount", variant: "destructive" });
    const amt = coinsToDollars(coinsRequested);
    if (amt > balance) return toast({ title: "Insufficient balance", variant: "destructive" });
    if (!destination) return toast({ title: "Enter destination", variant: "destructive" });

    setBusy(true);
    const { error } = await supabase.from("withdrawals").insert({
      user_id: user.id,
      payment_method_id: methodId,
      amount: amt,
      destination,
    });
    setBusy(false);
    if (error) {
      toast({ title: "Failed", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Withdrawal requested", description: "Pending admin approval" });
      setAmount("");
      setDestination("");
      refresh();
    }
  };

  return (
    <PageShell title="Withdraw" subtitle={`Balance: ${formatCoins(balance)} coins`}>
      <div className="flex flex-col gap-3">
        <label className="flex flex-col gap-1">
          <span className="text-xs text-muted-foreground">Payment Method</span>
          <select
            value={methodId}
            onChange={(e) => setMethodId(e.target.value)}
            className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none focus:border-primary"
          >
            {methods.length === 0 && <option value="">No methods configured</option>}
            {methods.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name} (min {formatCoins(m.min_amount)} coins)
              </option>
            ))}
          </select>
        </label>

        <input
          type="number"
          placeholder="Amount in coins"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none focus:border-primary"
        />
        <input
          type="text"
          placeholder="Destination (account / wallet address)"
          value={destination}
          onChange={(e) => setDestination(e.target.value)}
          className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none focus:border-primary"
        />

        <button
          onClick={submit}
          disabled={busy || methods.length === 0}
          className="mt-2 rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground transition hover:opacity-90 disabled:opacity-50"
        >
          {busy ? "Submitting…" : "Request Withdrawal"}
        </button>
      </div>

      <h3 className="mt-8 mb-3 text-sm font-bold">Recent Requests</h3>
      <div className="flex flex-col gap-2">
        {history.length === 0 && <p className="text-xs text-muted-foreground">No requests yet.</p>}
        {history.map((w) => (
          <div key={w.id} className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm">
            <div>
              <p className="font-semibold">{formatCoins(w.amount)} coins</p>
              <p className="text-xs text-muted-foreground">{new Date(w.created_at).toLocaleDateString()}</p>
            </div>
            <span className={`rounded-full px-3 py-1 text-xs font-bold ${
              w.status === "paid" ? "bg-primary/20 text-primary" :
              w.status === "rejected" ? "bg-destructive/20 text-destructive" :
              "bg-white/10 text-muted-foreground"
            }`}>{w.status}</span>
          </div>
        ))}
      </div>

    </PageShell>
  );
};

export default Withdraw;
