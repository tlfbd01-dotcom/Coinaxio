import PageShell from "@/components/PageShell";

const TermsOfService = () => (
  <PageShell title="Terms of Service" subtitle="Last updated recently">
    <article className="prose prose-invert max-w-none space-y-4 text-sm text-muted-foreground">
      <p>
        Welcome to COINTO. By accessing or using our platform, you agree to be bound by these Terms of Service.
      </p>
      <h2 className="text-base font-bold text-foreground">1. Account</h2>
      <p>You must provide accurate information during registration and keep your credentials secure.</p>
      <h2 className="text-base font-bold text-foreground">2. Rewards</h2>
      <p>Rewards are credited upon verified completion of offers. Fraudulent activity will void rewards.</p>
      <h2 className="text-base font-bold text-foreground">3. Withdrawals</h2>
      <p>Withdrawals are processed manually and may take up to 72 hours.</p>
      <h2 className="text-base font-bold text-foreground">4. Termination</h2>
      <p>We reserve the right to suspend accounts that violate these terms.</p>
    </article>
  </PageShell>
);

export default TermsOfService;
