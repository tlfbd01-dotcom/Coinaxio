// Conversion: 1 USD = 1000 coins. DB stores values in USD (payout, balance, total_earned).
// Use these helpers everywhere we display coin amounts to users.
export const COINS_PER_DOLLAR = 1000;

export const dollarsToCoins = (n: number | string | null | undefined): number =>
  Math.round((Number(n) || 0) * COINS_PER_DOLLAR);

export const formatCoins = (n: number | string | null | undefined): string =>
  dollarsToCoins(n).toLocaleString();

export const coinsToDollars = (coins: number): number => coins / COINS_PER_DOLLAR;
