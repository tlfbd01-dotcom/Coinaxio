import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { lazy, Suspense, useState } from "react";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/useAuth";
import { AuthDialogProvider } from "@/components/AuthDialogProvider";
import ProtectedRoute from "@/components/ProtectedRoute";
import SplashScreen from "@/components/SplashScreen";
import RouteSplash from "@/components/RouteSplash";
import SiteBackground from "@/components/SiteBackground";
import { DesktopSidebarProvider } from "@/hooks/useDesktopSidebar";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";

// Public
const TermsOfService = lazy(() => import("./pages/TermsOfService.tsx"));
const PrivacyPolicy = lazy(() => import("./pages/PrivacyPolicy.tsx"));
const OfferyPostbackProxy = lazy(() => import("./pages/OfferyPostbackProxy.tsx"));
const ResetPassword = lazy(() => import("./pages/ResetPassword.tsx"));

// User
const Dashboard = lazy(() => import("./pages/Dashboard.tsx"));
const AllOffers = lazy(() => import("./pages/AllOffers.tsx"));
const UserCompletedOffers = lazy(() => import("./pages/UserCompletedOffers.tsx"));
const ProfileSettings = lazy(() => import("./pages/ProfileSettings.tsx"));
const Leaderboard = lazy(() => import("./pages/Leaderboard.tsx"));
const Withdraw = lazy(() => import("./pages/Withdraw.tsx"));

// Admin
const AdminPanel = lazy(() => import("./pages/AdminPanel.tsx"));
const AdminAllUsers = lazy(() => import("./pages/AdminAllUsers.tsx"));
const AdminWithdraw = lazy(() => import("./pages/AdminWithdraw.tsx"));
const AdminPasswordReset = lazy(() => import("./pages/AdminPasswordReset.tsx"));
const AdminLogoCustomize = lazy(() => import("./pages/AdminLogoCustomize.tsx"));
const AdminOfferwallCustomize = lazy(() => import("./pages/AdminOfferwallCustomize.tsx"));
const AdminSocialLinksCustomize = lazy(() => import("./pages/AdminSocialLinksCustomize.tsx"));
const AdminSoundCustomize = lazy(() => import("./pages/AdminSoundCustomize.tsx"));
const AdminBackgroundCustomize = lazy(() => import("./pages/AdminBackgroundCustomize.tsx"));
const AdminRoleManagement = lazy(() => import("./pages/AdminRoleManagement.tsx"));
const AdminLiveTrackerCustomize = lazy(() => import("./pages/AdminLiveTrackerCustomize.tsx"));
const AdminProvidersCustomize = lazy(() => import("./pages/AdminProvidersCustomize.tsx"));
const AdminFeaturedOffers = lazy(() => import("./pages/AdminFeaturedOffers.tsx"));
const AdminFeaturedBanners = lazy(() => import("./pages/AdminFeaturedBanners.tsx"));
const AdminPaymentMethods = lazy(() => import("./pages/AdminPaymentMethods.tsx"));
const AdminHomepageImages = lazy(() => import("./pages/AdminHomepageImages.tsx"));
const AdminChargeback = lazy(() => import("./pages/AdminChargeback.tsx"));
const AdminPostbackHistory = lazy(() => import("./pages/AdminPostbackHistory.tsx"));
const AdminCompletedOffers = lazy(() => import("./pages/AdminCompletedOffers.tsx"));
const AdminNotikImport = lazy(() => import("./pages/AdminNotikImport.tsx"));

const queryClient = new QueryClient();

const RouteFallback = () => (
  <div className="flex min-h-screen items-center justify-center bg-background text-sm text-muted-foreground">
    Loading…
  </div>
);

const Protected = ({ children, admin = false }: { children: React.ReactNode; admin?: boolean }) => (
  <ProtectedRoute requireAdmin={admin}>{children}</ProtectedRoute>
);

const App = () => {
  const [showSplash, setShowSplash] = useState(true);

  return (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      {showSplash && <SplashScreen onDone={() => setShowSplash(false)} />}
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <SiteBackground />
        <AuthProvider>
          <DesktopSidebarProvider>
          <AuthDialogProvider>
          <RouteSplash />
          <Suspense fallback={<RouteFallback />}>
            <Routes>
              {/* Public */}
              <Route path="/" element={<Index />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/terms" element={<TermsOfService />} />
              <Route path="/privacy" element={<PrivacyPolicy />} />
              <Route path="/api/offery-postback" element={<OfferyPostbackProxy />} />
              <Route path="/leaderboard" element={<Leaderboard />} />
              <Route path="/all-offers" element={<AllOffers />} />

              {/* User */}
              <Route path="/dashboard" element={<Protected><Dashboard /></Protected>} />
              <Route path="/my-offers" element={<Protected><UserCompletedOffers /></Protected>} />
              <Route path="/profile" element={<Protected><ProfileSettings /></Protected>} />
              <Route path="/withdraw" element={<Protected><Withdraw /></Protected>} />

              {/* Admin */}
              <Route path="/admin" element={<Protected admin><AdminPanel /></Protected>} />
              <Route path="/admin/users" element={<Protected admin><AdminAllUsers /></Protected>} />
              <Route path="/admin/withdraw" element={<Protected admin><AdminWithdraw /></Protected>} />
              <Route path="/admin/password" element={<Protected admin><AdminPasswordReset /></Protected>} />
              <Route path="/admin/logo" element={<Protected admin><AdminLogoCustomize /></Protected>} />
              <Route path="/admin/offerwall" element={<Protected admin><AdminOfferwallCustomize /></Protected>} />
              <Route path="/admin/social" element={<Protected admin><AdminSocialLinksCustomize /></Protected>} />
              <Route path="/admin/sound" element={<Protected admin><AdminSoundCustomize /></Protected>} />
              <Route path="/admin/background" element={<Protected admin><AdminBackgroundCustomize /></Protected>} />
              <Route path="/admin/roles" element={<Protected admin><AdminRoleManagement /></Protected>} />
              <Route path="/admin/live-tracker" element={<Protected admin><AdminLiveTrackerCustomize /></Protected>} />
              <Route path="/admin/providers" element={<Protected admin><AdminProvidersCustomize /></Protected>} />
              <Route path="/admin/featured-offers" element={<Protected admin><AdminFeaturedOffers /></Protected>} />
              <Route path="/admin/featured-banners" element={<Protected admin><AdminFeaturedBanners /></Protected>} />
              <Route path="/admin/payment-methods" element={<Protected admin><AdminPaymentMethods /></Protected>} />
              <Route path="/admin/homepage-images" element={<Protected admin><AdminHomepageImages /></Protected>} />
              <Route path="/admin/chargeback" element={<Protected admin><AdminChargeback /></Protected>} />
              <Route path="/admin/postback-history" element={<Protected admin><AdminPostbackHistory /></Protected>} />
              <Route path="/admin/offers" element={<Protected admin><AdminCompletedOffers /></Protected>} />
              <Route path="/admin/notik-import" element={<Protected admin><AdminNotikImport /></Protected>} />

              <Route path="*" element={<NotFound />} />
            </Routes>
          </Suspense>
          </AuthDialogProvider>
          </DesktopSidebarProvider>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
  );
};

export default App;
