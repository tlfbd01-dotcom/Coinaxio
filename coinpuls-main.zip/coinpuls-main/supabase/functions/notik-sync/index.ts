// Notik offer sync — fetches Notik catalog and upserts into `offers` table.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const NOTIK_BASE = "https://notik.me";

interface NotikOffer {
  offer_id?: string | number;
  id?: string | number;
  name?: string;
  title?: string;
  description?: string;
  payout?: number | string;
  amount?: number | string;
  reward?: number | string;
  icon?: string;
  image?: string;
  image_url?: string;
  thumbnail?: string;
  url?: string;
  click_url?: string;
  tracking_link?: string;
  link?: string;
  countries?: string[] | string;
  country?: string;
  country_code?: string[] | string;
  device?: string;
  devices?: string[] | string;
  device_type?: string;
  device_os?: string;
  category?: string;
  categories?: string[] | string;
  type?: string;
}

const pickStr = (...vals: (string | undefined | null)[]) =>
  vals.find((v) => typeof v === "string" && v.length > 0) ?? null;

const pickNum = (...vals: (number | string | undefined | null)[]) => {
  for (const v of vals) {
    if (v == null) continue;
    const n = typeof v === "number" ? v : Number(v);
    if (!isNaN(n)) return n;
  }
  return 0;
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const sb = createClient(SUPABASE_URL, SERVICE_ROLE);

    // Optional body { provider_id }
    let bodyProviderId: string | undefined;
    try {
      if (req.method === "POST") {
        const b = await req.json();
        bodyProviderId = b?.provider_id;
      }
    } catch { /* ignore */ }

    // 1. Resolve provider row (by id if passed, else by slug 'notik', else create)
    let providerId: string;
    let providerCfg: Record<string, string> = {};
    if (bodyProviderId) {
      const { data: p } = await sb.from("providers").select("id, config").eq("id", bodyProviderId).maybeSingle();
      if (!p) throw new Error("Provider not found");
      providerId = p.id;
      providerCfg = (p.config ?? {}) as Record<string, string>;
    } else {
      const { data: existingProv } = await sb
        .from("providers")
        .select("id, config")
        .eq("slug", "notik")
        .maybeSingle();
      if (existingProv?.id) {
        providerId = existingProv.id;
        providerCfg = (existingProv.config ?? {}) as Record<string, string>;
      } else {
        const { data: created, error: pErr } = await sb
          .from("providers")
          .insert({ slug: "notik", name: "Notik", description: "Notik Offerwall", is_enabled: true })
          .select("id, config")
          .single();
        if (pErr || !created) throw new Error("Failed to create provider: " + pErr?.message);
        providerId = created.id;
        providerCfg = (created.config ?? {}) as Record<string, string>;
      }
    }

    // Prefer credentials from DB, fallback to env
    const NOTIK_API_KEY = providerCfg.api_key || Deno.env.get("NOTIK_API_KEY") || "";
    const NOTIK_PUB_ID = providerCfg.pub_id || Deno.env.get("NOTIK_PUB_ID") || "";
    const NOTIK_APP_ID = providerCfg.app_id || Deno.env.get("NOTIK_APP_ID") || "";

    if (!NOTIK_API_KEY || !NOTIK_PUB_ID || !NOTIK_APP_ID) {
      return new Response(
        JSON.stringify({ error: "Notik credentials missing (set api_key, pub_id, app_id in provider config)" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // 2. Fetch from Notik
    const url = `${NOTIK_BASE}/api/v2/get-offers/all?api_key=${encodeURIComponent(NOTIK_API_KEY)}&pub_id=${encodeURIComponent(NOTIK_PUB_ID)}&app_id=${encodeURIComponent(NOTIK_APP_ID)}&user_id=server_sync`;
    const resp = await fetch(url, {
      headers: {
        Accept: "application/json",
        "User-Agent": "Mozilla/5.0 (compatible; NotikSync/1.0)",
        Referer: "https://snapcoins.co",
      },
    });
    const text = await resp.text();
    if (!resp.ok) {
      console.error("Notik API error", resp.status, text.slice(0, 500));
      return new Response(
        JSON.stringify({ error: `Notik API ${resp.status}`, body: text.slice(0, 500) }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    let json: any;
    try { json = JSON.parse(text); } catch {
      return new Response(
        JSON.stringify({ error: "Notik returned non-JSON", preview: text.slice(0, 300) }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Normalize to array — Notik may wrap data in {offers: [...]} / {data: [...]} / [...]
    const list: NotikOffer[] = Array.isArray(json)
      ? json
      : Array.isArray(json?.offers?.data) ? json.offers.data
      : Array.isArray(json?.offers) ? json.offers
      : Array.isArray(json?.data?.data) ? json.data.data
      : Array.isArray(json?.data) ? json.data
      : Array.isArray(json?.result) ? json.result
      : [];

    if (list.length === 0) {
      return new Response(
        JSON.stringify({ ok: true, synced: 0, note: "No offers returned", sample: json }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Top-converting → mark featured
    let topIds = new Set<string>();
    try {
      const topUrl = `${NOTIK_BASE}/api/v2/get-top-converting-offers?api_key=${encodeURIComponent(NOTIK_API_KEY)}&pub_id=${encodeURIComponent(NOTIK_PUB_ID)}&app_id=${encodeURIComponent(NOTIK_APP_ID)}`;
      const topResp = await fetch(topUrl);
      if (topResp.ok) {
        const topJson = await topResp.json();
        const topList: NotikOffer[] = Array.isArray(topJson) ? topJson
          : Array.isArray(topJson?.offers) ? topJson.offers
          : Array.isArray(topJson?.data) ? topJson.data
          : [];
        topList.forEach((o) => {
          const id = String(o.offer_id ?? o.id ?? "");
          if (id) topIds.add(id);
        });
      }
    } catch (e) { console.warn("top-converting fetch failed", e); }

    // 3. Upsert each offer (manual: lookup by external_id+provider)
    let inserted = 0, updated = 0, skipped = 0;
    for (const o of list) {
      const external_id = String(o.offer_id ?? o.id ?? "");
      const title = pickStr(o.name, o.title);
      if (!external_id || !title) { skipped++; continue; }

      const arrOrStr = (v: unknown): string | null => {
        if (Array.isArray(v)) return v.length ? v.join(",") : null;
        if (typeof v === "string" && v) return v;
        return null;
      };
      const country = arrOrStr(o.countries) ?? arrOrStr(o.country_code) ?? pickStr(o.country);
      const device = arrOrStr(o.devices) ?? pickStr(o.device, o.device_type, o.device_os);
      const category = arrOrStr(o.categories) ?? pickStr(o.category, o.type);
      const description = pickStr(o.description, (o as any).description1, (o as any).description2);

      const row = {
        provider_id: providerId,
        external_id,
        title,
        description,
        image_url: pickStr(o.icon, o.image, o.image_url, o.thumbnail),
        click_url: pickStr(o.url, o.click_url, o.tracking_link, o.link),
        payout: pickNum(o.payout, o.amount, o.reward),
        country,
        device,
        category,
        is_active: true,
      };

      const { data: existing } = await sb
        .from("offers")
        .select("id")
        .eq("provider_id", providerId)
        .eq("external_id", external_id)
        .maybeSingle();

      if (existing?.id) {
        const { error } = await sb.from("offers").update(row).eq("id", existing.id);
        if (!error) updated++; else { console.error("update err", error.message); skipped++; }
      } else {
        const { error } = await sb.from("offers").insert(row);
        if (!error) inserted++; else { console.error("insert err", error.message); skipped++; }
      }
    }

    // 4. Sync top-converting → featured_offers (replace previous notik-featured)
    if (topIds.size > 0) {
      const { data: topOffers } = await sb
        .from("offers")
        .select("id, title, image_url, click_url, external_id")
        .eq("provider_id", providerId)
        .in("external_id", Array.from(topIds));

      if (topOffers && topOffers.length > 0) {
        // Wipe previous notik-sourced featured rows then insert fresh
        await sb.from("featured_offers").delete().like("badge", "notik-top%");
        const featuredRows = topOffers.slice(0, 10).map((o, idx) => ({
          offer_id: o.id,
          title: o.title,
          image_url: o.image_url,
          cta_url: o.click_url,
          badge: "notik-top",
          sort_order: idx,
          is_active: true,
        }));
        await sb.from("featured_offers").insert(featuredRows);
      }
    }

    // Record last sync timestamp
    await sb.from("site_settings").upsert(
      { key: "notik_sync", value: { last_sync: new Date().toISOString(), inserted, updated, skipped, total: list.length } as any },
      { onConflict: "key" },
    );

    return new Response(
      JSON.stringify({ ok: true, total: list.length, inserted, updated, skipped, top: topIds.size }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (e) {
    console.error("notik-sync error", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
