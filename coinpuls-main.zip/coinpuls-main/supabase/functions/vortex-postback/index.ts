// Vortexwall S2S postback handler.
// Docs: https://publisher.vortexwall.com/docs/
// Macros: {IDENTITY_ID} {CAMPAIGN_ID} {CAMPAIGN_NAME} {EVENT_ID} {EVENT_NAME}
//         {PAYOUT} {POINTS} {TXID} {RESULT} {IPADDR} {SUB1} {SUB2} {HASH}
// URL: https://<project>.supabase.co/functions/v1/vortex-postback
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { Md5 } from "https://deno.land/std@0.160.0/hash/md5.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const md5 = (s: string) => new Md5().update(s).toString();

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const reqId = crypto.randomUUID().slice(0, 8);
  const log = (msg: string, data?: unknown) =>
    console.log(`[vortexwall ${reqId}] ${msg}`, data !== undefined ? JSON.stringify(data) : "");

  try {
    const url = new URL(req.url);
    let payload: Record<string, unknown> = {};

    if (req.method === "POST") {
      const ct = req.headers.get("content-type") ?? "";
      if (ct.includes("application/json")) {
        payload = await req.json().catch(() => ({}));
      } else {
        const form = await req.formData().catch(() => null);
        if (form) form.forEach((v, k) => (payload[k] = String(v)));
      }
    }
    url.searchParams.forEach((v, k) => {
      payload[k] = v;
      payload[k.toLowerCase()] = v;
    });
    log("payload", payload);

    const ip =
      (payload.ipaddr as string) ??
      req.headers.get("cf-connecting-ip") ??
      req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
      null;

    const identityId = String(
      payload.identity_id ?? payload.identityid ?? payload.user_id ?? payload.uid ?? "",
    ).trim();
    const txid = String(payload.txid ?? payload.tx_id ?? payload.transaction_id ?? "").trim();
    const campaignId = (payload.campaign_id ?? payload.campaignid ?? null) as string | null;
    const campaignName = (payload.campaign_name ?? payload.campaignname ?? "Vortex Offer") as string;
    const eventName = (payload.event_name ?? payload.eventname ?? "") as string;

    const payoutRaw = payload.payout;
    const pointsRaw = payload.points;
    const payoutUsd = payoutRaw !== undefined && payoutRaw !== null && payoutRaw !== ""
      ? Number(payoutRaw) : null;
    const points = pointsRaw !== undefined && pointsRaw !== null && pointsRaw !== ""
      ? Number(pointsRaw) : null;

    // Store payout in USD (1$=1000 coins). Fallback: points/1000.
    const payout = payoutUsd !== null && Number.isFinite(payoutUsd) && payoutUsd > 0
      ? payoutUsd
      : (points !== null && Number.isFinite(points) ? points / 1000 : null);

    // RESULT: 1=success/credit, 2=reversal/chargeback (best-effort interpretation)
    const result = String(payload.result ?? "1");
    const isChargeback = result === "2" || result.toLowerCase() === "reversed" || result.toLowerCase() === "chargeback";

    const hash = String(payload.hash ?? "").toLowerCase();
    const isValidUuid = identityId && UUID_RE.test(identityId);

    const { data: logRow, error: logErr } = await supabase
      .from("postback_logs")
      .insert({
        provider_slug: "vortexwall",
        user_id: isValidUuid ? identityId : null,
        offer_external_id: campaignId,
        payout,
        raw_payload: payload,
        ip_address: ip,
        status: "received",
      })
      .select()
      .single();
    if (logErr) throw logErr;

    // Optional hash verification: md5(identity_id + txid + payout + SECRET)
    const secret = Deno.env.get("VORTEX_SECRET_KEY") ?? "";
    if (secret && hash) {
      const expected = md5(`${identityId}${txid}${payoutRaw ?? ""}${secret}`).toLowerCase();
      if (hash !== expected) {
        log("hash mismatch", { expected, hash });
        await supabase.from("postback_logs")
          .update({ status: "invalid_signature", error_message: "MD5 hash mismatch" })
          .eq("id", logRow.id);
        return new Response("Invalid hash", { status: 401, headers: corsHeaders });
      }
    }

    if (!identityId) {
      await supabase.from("postback_logs")
        .update({ status: "skipped_no_user", error_message: "identity_id missing" })
        .eq("id", logRow.id);
      return new Response("OK (no identity_id)", { status: 200, headers: corsHeaders });
    }
    if (!isValidUuid) {
      await supabase.from("postback_logs")
        .update({ status: "skipped_invalid_user", error_message: `identity_id '${identityId}' is not a valid UUID` })
        .eq("id", logRow.id);
      return new Response("OK (invalid identity_id)", { status: 200, headers: corsHeaders });
    }
    if (payout === null || !Number.isFinite(payout) || payout <= 0) {
      await supabase.from("postback_logs")
        .update({ status: "skipped_no_payout", error_message: "payout/points missing" })
        .eq("id", logRow.id);
      return new Response("OK (no payout)", { status: 200, headers: corsHeaders });
    }

    const { data: providerRow } = await supabase
      .from("providers").select("id").eq("slug", "vortexwall").maybeSingle();

    const { data: profile, error: profErr } = await supabase
      .from("profiles").select("balance, total_earned").eq("user_id", identityId).maybeSingle();
    if (profErr || !profile) {
      await supabase.from("postback_logs")
        .update({ status: "user_not_found", error_message: profErr?.message ?? "profile missing" })
        .eq("id", logRow.id);
      return new Response("OK (no profile)", { status: 200, headers: corsHeaders });
    }

    const txId = txid || logRow.id;
    const signedPayout = isChargeback ? -Math.abs(payout) : Math.abs(payout);
    const title = eventName ? `${campaignName} — ${eventName}` : campaignName;

    const { error: coErr } = await supabase.from("completed_offers").insert({
      user_id: identityId,
      provider_id: providerRow?.id ?? null,
      provider_tx_id: isChargeback ? `${txId}-cb` : txId,
      title,
      payout: signedPayout,
      status: isChargeback ? "chargeback" : "credited",
    });
    if (coErr) {
      await supabase.from("postback_logs")
        .update({ status: "duplicate_or_error", error_message: coErr.message })
        .eq("id", logRow.id);
      return new Response("OK (duplicate)", { status: 200, headers: corsHeaders });
    }

    const newBalance = Number(profile.balance) + signedPayout;
    const newEarned = isChargeback
      ? Number(profile.total_earned)
      : Number(profile.total_earned) + signedPayout;

    const { error: updErr } = await supabase
      .from("profiles")
      .update({ balance: newBalance, total_earned: newEarned })
      .eq("user_id", identityId);
    if (updErr) {
      await supabase.from("postback_logs")
        .update({ status: "credit_failed", error_message: updErr.message })
        .eq("id", logRow.id);
      return new Response("Credit failed", { status: 500, headers: corsHeaders });
    }

    await supabase.from("postback_logs")
      .update({ status: isChargeback ? "chargeback" : "credited" })
      .eq("id", logRow.id);

    log("done", { identityId, signedPayout, newBalance });
    return new Response("OK", { status: 200, headers: corsHeaders });
  } catch (err) {
    console.error(`[vortexwall ${reqId}] fatal`, err);
    return new Response(JSON.stringify({ error: (err as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
