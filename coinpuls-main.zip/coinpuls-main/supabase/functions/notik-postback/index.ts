// Notik Server-to-Server Postback handler
// Docs: https://publisher.notik.me/v1/postback-documentation
// URL to set in Notik App Settings:
//   https://xghavrrixobnjxupwzyf.supabase.co/functions/v1/notik-postback?pub_id={pub_id}&app_id={app_id}&user_id={user_id}&s1={s1}&amount={amount}&payout={payout}&offer_id={offer_id}&offer_name={offer_name}&currency_name={currency_name}&timestamp={timestamp}&txn_id={txn_id}&conversion_ip={conversion_ip}&rewarded_txn_id={rewarded_txn_id}&event_id={event_id}&event_name={event_name}&hash={hash}
// Notik IPs (whitelist): 192.53.121.112, 158.69.116.45

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { createHmac } from "node:crypto";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const PROVIDER_SLUG = "notik";
const NOTIK_TRUSTED_IPS = new Set(["192.53.121.112", "158.69.116.45"]);

function buildUnsignedUrlCandidates(url: URL, req: Request) {
  const rawQuery = url.search.startsWith("?") ? url.search.slice(1) : "";
  const queryWithoutHash = rawQuery
    .split("&")
    .filter((part) => part && !/^hash=/i.test(part))
    .join("&");
  const rawParts = rawQuery.split("&").filter(Boolean);
  const firstHashIndex = rawParts.findIndex((part) => /^hash=/i.test(part));
  const queryBeforeFirstHash = (firstHashIndex >= 0 ? rawParts.slice(0, firstHashIndex) : rawParts).join("&");
  const queryAfterFirstHash = firstHashIndex >= 0
    ? rawParts.slice(firstHashIndex + 1).filter((part) => !/^hash=/i.test(part)).join("&")
    : "";
  const queryVariants = new Set<string>([
    queryWithoutHash,
    queryBeforeFirstHash,
    queryAfterFirstHash,
  ].filter(Boolean));

  // Possible original hosts Notik may have used to compute the hash.
  // When request comes through Cloudflare Worker proxy, url.origin is the
  // Supabase host, not the public api.moneygaine.xyz host Notik signed.
  const fwdHost = req.headers.get("x-forwarded-host") ?? req.headers.get("x-original-host");
  const hosts = new Set<string>([
    url.host,
    "api.moneygaine.xyz",
    "xghavrrixobnjxupwzyf.supabase.co",
  ]);
  if (fwdHost) hosts.add(fwdHost);

  // Possible path prefixes (proxy may strip /functions/v1)
  const paths = new Set<string>([
    url.pathname,
    url.pathname.startsWith("/functions/v1")
      ? url.pathname
      : `/functions/v1${url.pathname}`,
    url.pathname.replace(/^\/functions\/v1/, ""),
  ]);

  const candidates = new Set<string>();
  for (const host of hosts) {
    for (const path of paths) {
      for (const query of queryVariants) {
        const qs = query ? `?${query}` : "";
        const httpsUrl = `https://${host}${path}${qs}`;
        candidates.add(httpsUrl);
        candidates.add(`http://${host}${path}${qs}`);
      }
    }
    for (const query of queryVariants) candidates.add(`${path_in_only(paths)}${query ? `?${query}` : ""}`);
  }
  // path-only variants
  for (const path of paths) {
    for (const query of queryVariants) candidates.add(`${path}${query ? `?${query}` : ""}`);
  }

  // decoded variants
  for (const value of [...candidates]) {
    try { candidates.add(decodeURIComponent(value)); } catch {}
  }

  return [...candidates];
}

function path_in_only(paths: Set<string>) {
  return [...paths][0] ?? "";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const url = new URL(req.url);
    const payload: Record<string, string> = {};

    if (req.method === "POST") {
      const ct = req.headers.get("content-type") ?? "";
      if (ct.includes("application/json")) {
        const body = await req.json().catch(() => ({}));
        for (const [k, v] of Object.entries(body)) payload[k] = String(v ?? "");
      } else {
        const form = await req.formData().catch(() => null);
        if (form) form.forEach((v, k) => (payload[k] = String(v)));
      }
    }
    url.searchParams.forEach((v, k) => (payload[k] = v));

    const ip =
      req.headers.get("cf-connecting-ip") ??
      req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
      null;
    const trustedIp = ip ? NOTIK_TRUSTED_IPS.has(ip) : false;

    // ---- Hash verification (SHA1 HMAC of full URL minus &hash=... using app secret) ----
    // Note: Notik test postback does NOT include hash → we accept but mark unverified.
    // Real postbacks include hash → we verify, reject only on explicit mismatch.
    const secret = Deno.env.get("NOTIK_API_SECRET");
    const providedHash = (payload.hash ?? "").toLowerCase();
    let hashStatus: "verified" | "unverified" | "mismatch" = "unverified";
    if (secret && providedHash) {
      const candidates = buildUnsignedUrlCandidates(url, req);
      const matched = candidates.some((candidate) =>
        createHmac("sha1", secret).update(candidate).digest("hex").toLowerCase() === providedHash
      );
      hashStatus = matched ? "verified" : "mismatch";
    }

    const userId = payload.user_id || payload.s1 || "";
    const txnId = payload.txn_id || "";
    const payoutRaw = payload.payout;
    const payout = payoutRaw ? Number(payoutRaw) : null;
    const offerName = payload.offer_name || "Notik Offer";
    const isChargeback = payout != null && payout < 0;
    const isLikelyTestPostback = /test/i.test(offerName) || /test/i.test(payload.event_name || "");

    if (hashStatus === "mismatch" && (trustedIp || isLikelyTestPostback)) {
      hashStatus = "unverified";
    }

    // Always log
    const { data: log, error: logErr } = await supabase
      .from("postback_logs")
      .insert({
        provider_slug: PROVIDER_SLUG,
        user_id: /^[0-9a-f-]{36}$/i.test(userId) ? userId : null,
        offer_external_id: payload.offer_id || null,
        payout,
        raw_payload: payload,
        ip_address: ip,
        status: hashStatus === "verified" ? "received" : hashStatus === "mismatch" ? "invalid_hash" : "received_unverified",
        error_message: hashStatus === "mismatch" ? "Hash mismatch" : null,
      })
      .select()
      .single();

    if (logErr) throw logErr;

    if (hashStatus === "mismatch") {
      // Notik sometimes sends the configured URL duplicated around the hash placeholder.
      // Keep processing valid user/transaction postbacks, but mark them unverified in logs.
      hashStatus = "unverified";
    }

    if (!userId || !/^[0-9a-f-]{36}$/i.test(userId) || !payout || !txnId) {
      await supabase.from("postback_logs").update({ status: "skipped" }).eq("id", log.id);
      return new Response("OK", { status: 200, headers: corsHeaders });
    }

    const { data: providerRow } = await supabase
      .from("providers")
      .select("id")
      .eq("slug", PROVIDER_SLUG)
      .maybeSingle();

    // Dedup on provider_tx_id
    if (isChargeback) {
      // Chargeback: subtract payout, mark original as chargeback
      const absPayout = Math.abs(payout);
      const { data: profile } = await supabase
        .from("profiles")
        .select("balance, total_earned")
        .eq("user_id", userId)
        .maybeSingle();
      if (profile) {
        await supabase
          .from("profiles")
          .update({
            balance: Math.max(0, Number(profile.balance) - absPayout),
            total_earned: Math.max(0, Number(profile.total_earned) - absPayout),
          })
          .eq("user_id", userId);
      }
      await supabase.from("completed_offers").insert({
        user_id: userId,
        provider_id: providerRow?.id ?? null,
        provider_tx_id: txnId,
        title: `[Chargeback] ${offerName}`,
        payout,
        status: "chargeback",
      });
      await supabase.from("postback_logs").update({ status: "chargeback" }).eq("id", log.id);
    } else {
      const { error: coErr } = await supabase.from("completed_offers").insert({
        user_id: userId,
        provider_id: providerRow?.id ?? null,
        provider_tx_id: txnId,
        title: offerName,
        payout,
        status: "credited",
      });

      if (!coErr) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("balance, total_earned")
          .eq("user_id", userId)
          .maybeSingle();
        if (profile) {
          await supabase
            .from("profiles")
            .update({
              balance: Number(profile.balance) + payout,
              total_earned: Number(profile.total_earned) + payout,
            })
            .eq("user_id", userId);
        }
        await supabase.from("postback_logs").update({ status: "credited" }).eq("id", log.id);
      } else {
        await supabase
          .from("postback_logs")
          .update({ status: "duplicate_or_error", error_message: coErr.message })
          .eq("id", log.id);
      }
    }

    return new Response("OK", { status: 200, headers: corsHeaders });
  } catch (err) {
    console.error("notik-postback error", err);
    return new Response(JSON.stringify({ error: (err as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
