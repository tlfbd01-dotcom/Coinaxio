// Generic per-provider postback handler.
// URL pattern: /functions/v1/provider-postback/{slug}?user_id=...&payout=...&offer_id=...
// or POST body. Optional `secret` query param checked against providers.config.secret if set.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const reqId = crypto.randomUUID().slice(0, 8);
  const log = (msg: string, data?: unknown) =>
    console.log(`[postback ${reqId}] ${msg}`, data !== undefined ? JSON.stringify(data) : "");

  try {
    const url = new URL(req.url);
    const parts = url.pathname.split("/").filter(Boolean);
    const slug = parts[parts.length - 1] || "unknown";
    log("incoming", { slug, method: req.method, url: req.url });

    let payload: Record<string, unknown> = {};
    if (req.method === "POST") {
      const ct = req.headers.get("content-type") ?? "";
      if (ct.includes("application/json")) {
        payload = await req.json().catch(() => ({}));
      } else {
        const form = await req.formData().catch(() => null);
        if (form) form.forEach((v, k) => (payload[k] = String(v)));
      }
    }
    url.searchParams.forEach((v, k) => {
      payload[k] = v;
      payload[k.toLowerCase()] = v; // case-insensitive access (e.g. userId -> userid)
    });
    log("payload", payload);

    const ip =
      req.headers.get("cf-connecting-ip") ??
      req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
      null;

    const { data: providerRow, error: provErr } = await supabase
      .from("providers")
      .select("id, slug, config, is_enabled")
      .eq("slug", slug)
      .maybeSingle();
    if (provErr) log("provider lookup error", provErr.message);
    log("provider", providerRow);

    // Optional secret verification
    const expectedSecret = (providerRow?.config as Record<string, unknown> | null)?.secret as
      | string
      | undefined;
    const providedSecret = (payload.secret ?? payload.signature ?? payload.hash) as
      | string
      | undefined;
    if (expectedSecret && expectedSecret !== providedSecret) {
      log("secret mismatch", { expected_len: expectedSecret.length, provided: providedSecret });
      await supabase.from("postback_logs").insert({
        provider_slug: slug,
        raw_payload: payload,
        ip_address: ip,
        status: "invalid_secret",
        error_message: "Secret mismatch",
      });
      return new Response("Invalid secret", { status: 401, headers: corsHeaders });
    }

    // ---- Extract user_id (try many common macro names) ----
    const rawUserId = (
      payload.user_id ?? payload.userid ?? payload.uid ?? payload.subid ??
      payload.sub_id ?? payload.sub1 ?? payload.aff_sub ?? payload.aff_sub1 ??
      payload.publisher_user_id ?? payload.s1 ?? ""
    ) as string;
    const userId = String(rawUserId).trim();
    const isValidUuid = userId && UUID_RE.test(userId);

    const offerExternalId = (payload.offer_id ?? payload.oid ?? payload.offer_name ?? null) as string | null;
    const payoutRaw = payload.payout ?? payload.user_amount ?? payload.amount ?? payload.revenue;
    const payoutUsd = payoutRaw !== undefined && payoutRaw !== null && payoutRaw !== ""
      ? Number(payoutRaw)
      : null;

    // Store payout in USD. Display layer converts to coins (1$ = 1000 coins).
    // If a provider only sends `reward` (coins) without USD, divide by 1000 to normalize.
    const rewardRaw = payload.reward ?? payload.coins ?? payload.points;
    const rewardCoins = rewardRaw !== undefined && rewardRaw !== null && rewardRaw !== ""
      ? Number(rewardRaw)
      : null;
    const payout = payoutUsd !== null && Number.isFinite(payoutUsd) && payoutUsd > 0
      ? payoutUsd
      : (rewardCoins !== null && Number.isFinite(rewardCoins) ? rewardCoins / 1000 : null);
    const payoutValid = payout !== null && Number.isFinite(payout) && payout > 0;

    log("parsed", { userId, isValidUuid, payoutUsd, rewardCoins, payout, payoutValid });

    const { data: logRow, error: logErr } = await supabase
      .from("postback_logs")
      .insert({
        provider_slug: slug,
        user_id: isValidUuid ? userId : null,
        offer_external_id: offerExternalId,
        payout,
        raw_payload: payload,
        ip_address: ip,
        status: "received",
      })
      .select()
      .single();

    if (logErr) {
      log("log insert error", logErr);
      throw logErr;
    }

    if (!providerRow || !providerRow.is_enabled) {
      log("provider disabled or missing", { slug });
      await supabase
        .from("postback_logs")
        .update({ status: "provider_disabled", error_message: `Provider '${slug}' not found or disabled in providers table` })
        .eq("id", logRow.id);
      return new Response("Provider not enabled", { status: 200, headers: corsHeaders });
    }

    if (!userId) {
      const msg = "user_id is empty — check macro variable in provider dashboard postback URL";
      log(msg);
      await supabase.from("postback_logs").update({ status: "skipped_no_user", error_message: msg }).eq("id", logRow.id);
      return new Response("OK (no user_id)", { status: 200, headers: corsHeaders });
    }

    if (!isValidUuid) {
      const msg = `user_id '${userId}' is not a valid UUID — your offer link must pass the user's UUID`;
      log(msg);
      await supabase.from("postback_logs").update({ status: "skipped_invalid_user", error_message: msg }).eq("id", logRow.id);
      return new Response("OK (invalid user_id)", { status: 200, headers: corsHeaders });
    }

    if (!payoutValid) {
      const msg = `payout '${payoutRaw}' is missing or not > 0`;
      log(msg);
      await supabase.from("postback_logs").update({ status: "skipped_no_payout", error_message: msg }).eq("id", logRow.id);
      return new Response("OK (no payout)", { status: 200, headers: corsHeaders });
    }

    // Verify profile exists
    const { data: profile, error: profErr } = await supabase
      .from("profiles")
      .select("balance, total_earned")
      .eq("user_id", userId)
      .maybeSingle();

    if (profErr) {
      log("profile lookup error", profErr);
      await supabase.from("postback_logs").update({ status: "error", error_message: `Profile lookup failed: ${profErr.message}` }).eq("id", logRow.id);
      return new Response("Profile lookup failed", { status: 500, headers: corsHeaders });
    }

    if (!profile) {
      const msg = `No profile found for user_id ${userId}`;
      log(msg);
      await supabase.from("postback_logs").update({ status: "user_not_found", error_message: msg }).eq("id", logRow.id);
      return new Response("OK (user not found)", { status: 200, headers: corsHeaders });
    }

    const txId = (payload.transaction_id ?? payload.tx_id ?? payload.txn_id ?? logRow.id) as string;

    const { error: coErr } = await supabase.from("completed_offers").insert({
      user_id: userId,
      provider_id: providerRow.id,
      provider_tx_id: txId,
      title: (payload.offer_name ?? payload.name ?? "Offer") as string,
      payout,
      status: "credited",
    });

    if (coErr) {
      log("completed_offers insert error", coErr);
      await supabase
        .from("postback_logs")
        .update({ status: "duplicate_or_error", error_message: `completed_offers insert failed: ${coErr.message}` })
        .eq("id", logRow.id);
      return new Response("OK (duplicate)", { status: 200, headers: corsHeaders });
    }

    const newBalance = Number(profile.balance) + payout;
    const newEarned = Number(profile.total_earned) + payout;
    log("crediting", { userId, oldBalance: profile.balance, newBalance, payout });

    const { error: updErr } = await supabase
      .from("profiles")
      .update({ balance: newBalance, total_earned: newEarned })
      .eq("user_id", userId);

    if (updErr) {
      log("profile update error", updErr);
      await supabase
        .from("postback_logs")
        .update({ status: "credit_failed", error_message: `Profile update failed: ${updErr.message}` })
        .eq("id", logRow.id);
      return new Response("Credit failed", { status: 500, headers: corsHeaders });
    }

    await supabase.from("postback_logs").update({ status: "credited" }).eq("id", logRow.id);
    log("credited successfully", { userId, payout, newBalance });

    return new Response("OK", { status: 200, headers: corsHeaders });
  } catch (err) {
    console.error(`[postback ${reqId}] fatal error`, err);
    return new Response(JSON.stringify({ error: (err as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
