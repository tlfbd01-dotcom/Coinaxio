// Offery S2S postback handler.
// Docs: https://offery.io/docs/
// Params: subId, transId, offer_id, offer_name, reward, payout, status (1=credit,2=chargeback),
//         debug (1=test), signature = md5(subId + transId + reward + SECRET_KEY)
// URL: https://<project>.supabase.co/functions/v1/offery-postback
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { Md5 } from "https://deno.land/std@0.160.0/hash/md5.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const md5 = (s: string) => new Md5().update(s).toString();

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const reqId = crypto.randomUUID().slice(0, 8);
  const log = (msg: string, data?: unknown) =>
    console.log(`[offery ${reqId}] ${msg}`, data !== undefined ? JSON.stringify(data) : "");

  try {
    const url = new URL(req.url);
    let payload: Record<string, unknown> = {};

    if (req.method === "POST") {
      const ct = req.headers.get("content-type") ?? "";
      if (ct.includes("application/json")) {
        payload = await req.json().catch(() => ({}));
      } else {
        const form = await req.formData().catch(() => null);
        if (form) form.forEach((v, k) => (payload[k] = String(v)));
      }
    }
    url.searchParams.forEach((v, k) => {
      payload[k] = v;
      payload[k.toLowerCase()] = v;
    });
    log("payload", payload);

    const ip =
      req.headers.get("cf-connecting-ip") ??
      req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
      null;

    const subId = String(
      payload.subId ?? payload.subid ?? payload.user_id ?? payload.uid ?? "",
    ).trim();
    const transId = String(
      payload.transId ?? payload.transid ?? payload.transaction_id ?? payload.tx_id ?? "",
    ).trim();
    const offerExternalId = (payload.offer_id ?? payload.oid ?? null) as string | null;
    const offerName = (payload.offer_name ?? payload.name ?? "Offery Offer") as string;

    const rewardRaw = payload.reward;
    const payoutRaw = payload.payout ?? payload.amount ?? payload.revenue;
    const reward = rewardRaw !== undefined && rewardRaw !== null && rewardRaw !== ""
      ? Number(rewardRaw) : null;
    const payoutUsd = payoutRaw !== undefined && payoutRaw !== null && payoutRaw !== ""
      ? Number(payoutRaw) : null;

    // Always store payout in USD. If payout missing, derive from reward (1000 coins = 1 USD).
    const payout = payoutUsd !== null && Number.isFinite(payoutUsd) && payoutUsd > 0
      ? payoutUsd
      : (reward !== null && Number.isFinite(reward) ? reward / 1000 : null);

    const status = String(payload.status ?? "1");
    const isChargeback = status === "2";
    const isDebug = String(payload.debug ?? "0") === "1";
    const signature = String(payload.signature ?? "").toLowerCase();

    const isValidUuid = subId && UUID_RE.test(subId);

    // Insert postback log first
    const { data: logRow, error: logErr } = await supabase
      .from("postback_logs")
      .insert({
        provider_slug: "offery",
        user_id: isValidUuid ? subId : null,
        offer_external_id: offerExternalId,
        payout,
        raw_payload: payload,
        ip_address: ip,
        status: "received",
      })
      .select()
      .single();
    if (logErr) throw logErr;

    // Verify signature: md5(subId + transId + reward + SECRET_KEY)
    const secret = Deno.env.get("OFFERY_SECRET_KEY") ?? "";
    if (secret) {
      const expected = md5(`${subId}${transId}${rewardRaw ?? ""}${secret}`).toLowerCase();
      if (signature && signature !== expected) {
        log("signature mismatch", { expected, signature });
        await supabase.from("postback_logs")
          .update({ status: "invalid_signature", error_message: "MD5 signature mismatch" })
          .eq("id", logRow.id);
        return new Response("Invalid signature", { status: 401, headers: corsHeaders });
      }
    }

    if (isDebug) {
      await supabase.from("postback_logs")
        .update({ status: "test_ok", error_message: "debug=1 test postback" })
        .eq("id", logRow.id);
      return new Response("OK (test)", { status: 200, headers: corsHeaders });
    }

    if (!subId) {
      await supabase.from("postback_logs")
        .update({ status: "skipped_no_user", error_message: "subId missing" })
        .eq("id", logRow.id);
      return new Response("OK (no subId)", { status: 200, headers: corsHeaders });
    }
    if (!isValidUuid) {
      await supabase.from("postback_logs")
        .update({ status: "skipped_invalid_user", error_message: `subId '${subId}' is not a valid UUID` })
        .eq("id", logRow.id);
      return new Response("OK (invalid subId)", { status: 200, headers: corsHeaders });
    }
    if (payout === null || !Number.isFinite(payout) || payout <= 0) {
      await supabase.from("postback_logs")
        .update({ status: "skipped_no_payout", error_message: "payout/reward missing" })
        .eq("id", logRow.id);
      return new Response("OK (no payout)", { status: 200, headers: corsHeaders });
    }

    const { data: providerRow } = await supabase
      .from("providers").select("id").eq("slug", "offery").maybeSingle();

    const { data: profile, error: profErr } = await supabase
      .from("profiles").select("balance, total_earned").eq("user_id", subId).maybeSingle();
    if (profErr || !profile) {
      await supabase.from("postback_logs")
        .update({ status: "user_not_found", error_message: profErr?.message ?? "profile missing" })
        .eq("id", logRow.id);
      return new Response("OK (no profile)", { status: 200, headers: corsHeaders });
    }

    const txId = transId || logRow.id;
    const signedPayout = isChargeback ? -Math.abs(payout) : Math.abs(payout);

    const { error: coErr } = await supabase.from("completed_offers").insert({
      user_id: subId,
      provider_id: providerRow?.id ?? null,
      provider_tx_id: isChargeback ? `${txId}-cb` : txId,
      title: offerName,
      payout: signedPayout,
      status: isChargeback ? "chargeback" : "credited",
    });
    if (coErr) {
      await supabase.from("postback_logs")
        .update({ status: "duplicate_or_error", error_message: coErr.message })
        .eq("id", logRow.id);
      return new Response("OK (duplicate)", { status: 200, headers: corsHeaders });
    }

    const newBalance = Number(profile.balance) + signedPayout;
    const newEarned = isChargeback
      ? Number(profile.total_earned) // don't reduce lifetime earned
      : Number(profile.total_earned) + signedPayout;

    const { error: updErr } = await supabase
      .from("profiles")
      .update({ balance: newBalance, total_earned: newEarned })
      .eq("user_id", subId);
    if (updErr) {
      await supabase.from("postback_logs")
        .update({ status: "credit_failed", error_message: updErr.message })
        .eq("id", logRow.id);
      return new Response("Credit failed", { status: 500, headers: corsHeaders });
    }

    await supabase.from("postback_logs")
      .update({ status: isChargeback ? "chargeback" : "credited" })
      .eq("id", logRow.id);

    log("done", { subId, signedPayout, newBalance });
    return new Response("OK", { status: 200, headers: corsHeaders });
  } catch (err) {
    console.error(`[offery ${reqId}] fatal`, err);
    return new Response(JSON.stringify({ error: (err as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
