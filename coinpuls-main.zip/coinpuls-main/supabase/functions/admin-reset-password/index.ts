// Admin-only edge function: reset a user's password by user_id.
// Requires caller to be an authenticated admin (verified server-side).
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const auth = req.headers.get("Authorization") ?? "";
    const jwt = auth.replace("Bearer ", "");
    if (!jwt) {
      return new Response(JSON.stringify({ error: "Missing auth" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;

    // Verify caller is admin using their JWT
    const userClient = createClient(SUPABASE_URL, ANON_KEY, {
      global: { headers: { Authorization: `Bearer ${jwt}` } },
    });
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData.user) {
      return new Response(JSON.stringify({ error: "Invalid session" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: roleData } = await userClient
      .from("user_roles")
      .select("role")
      .eq("user_id", userData.user.id)
      .eq("role", "admin")
      .maybeSingle();
    if (!roleData) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json().catch(() => ({}));
    const { user_id, new_password, action, query } = body as {
      user_id?: string;
      new_password?: string;
      action?: string;
      query?: string;
    };

    const admin = createClient(SUPABASE_URL, SERVICE_KEY);

    // Search users (by email/name) — returns up to 20 with emails
    if (action === "search") {
      const term = (query ?? "").trim().toLowerCase();
      const { data: list, error: listErr } = await admin.auth.admin.listUsers({
        page: 1,
        perPage: 200,
      });
      if (listErr) {
        return new Response(JSON.stringify({ error: listErr.message }), {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      let users = list.users.map((u) => ({
        user_id: u.id,
        email: u.email ?? "",
      }));
      if (term) {
        users = users.filter((u) => u.email.toLowerCase().includes(term));
      }
      // Join with profiles for display name
      const ids = users.slice(0, 50).map((u) => u.user_id);
      const { data: profs } = await admin
        .from("profiles")
        .select("user_id, display_name, username")
        .in("user_id", ids);
      const byId = new Map((profs ?? []).map((p) => [p.user_id, p]));
      const merged = users.slice(0, 20).map((u) => ({
        ...u,
        display_name: byId.get(u.user_id)?.display_name ?? null,
        username: byId.get(u.user_id)?.username ?? null,
      }));
      return new Response(JSON.stringify({ users: merged }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!user_id || !new_password || new_password.length < 6) {
      return new Response(
        JSON.stringify({
          error: "user_id and new_password (min 6 chars) required",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    const { error } = await admin.auth.admin.updateUserById(user_id, {
      password: new_password,
    });
    if (error) {
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ ok: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(
      JSON.stringify({ error: (e as Error).message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  }
});
