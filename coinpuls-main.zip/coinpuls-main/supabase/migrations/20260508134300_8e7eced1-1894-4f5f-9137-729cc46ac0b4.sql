UPDATE public.providers
SET config = jsonb_build_object(
  'api_key', 'nure1010',
  'app_id', '10627',
  'pub_id', 'mdpagolytt7@gmail.com',
  'secret', '',
  'click_url', 'https://clickwall.net/app/iframe/10627/{user_id}',
  'notes', ''
)
WHERE slug = 'clickwall';