update public.providers
set config = config || jsonb_build_object(
  'app_id','yWRHME9rr3',
  'pub_id','qQjRYt',
  'api_key','Kll4CEGL875baosgszfoZLblWyveGcTh',
  'api_secret','u32yt5RmUxKbpsgtpDmzwBqTKe1gr0lX',
  'click_url','https://notik.me/coins?api_key=Kll4CEGL875baosgszfoZLblWyveGcTh&pub_id=qQjRYt&app_id=yWRHME9rr3&user_id={user_id}'
)
where slug='notik';