-- Create public bucket for provider logos
INSERT INTO storage.buckets (id, name, public)
VALUES ('provider-logos', 'provider-logos', true)
ON CONFLICT (id) DO NOTHING;

-- Public read
CREATE POLICY "Public can view provider logos"
ON storage.objects FOR SELECT
USING (bucket_id = 'provider-logos');

-- Admin write
CREATE POLICY "Admins upload provider logos"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'provider-logos' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins update provider logos"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'provider-logos' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins delete provider logos"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'provider-logos' AND public.has_role(auth.uid(), 'admin'));