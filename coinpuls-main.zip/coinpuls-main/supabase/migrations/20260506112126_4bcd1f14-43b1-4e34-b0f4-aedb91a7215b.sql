
-- Extensions
create extension if not exists pg_cron;
create extension if not exists pg_net;

-- Default setting row
insert into public.site_settings (key, value)
values ('notik_auto_sync', jsonb_build_object('enabled', true, 'interval_minutes', 60, 'last_run_at', null))
on conflict (key) do nothing;

-- Function that checks the setting and dispatches when due
create or replace function public.notik_auto_sync_tick()
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  cfg jsonb;
  enabled boolean;
  interval_min int;
  last_run timestamptz;
begin
  select value into cfg from public.site_settings where key = 'notik_auto_sync';
  if cfg is null then return; end if;

  enabled := coalesce((cfg->>'enabled')::boolean, false);
  interval_min := coalesce((cfg->>'interval_minutes')::int, 60);
  last_run := nullif(cfg->>'last_run_at','')::timestamptz;

  if not enabled then return; end if;
  if last_run is not null and last_run > now() - make_interval(mins => interval_min) then
    return;
  end if;

  perform net.http_post(
    url := 'https://xghavrrixobnjxupwzyf.supabase.co/functions/v1/notik-sync',
    headers := jsonb_build_object(
      'Content-Type','application/json',
      'apikey','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhnaGF2cnJpeG9ibmp4dXB3enlmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzcwNjA3MTUsImV4cCI6MjA5MjYzNjcxNX0.J_Zq5RDfbEPVQ-ggys1R7H395RwEM6ib9nHh6i2o93U'
    ),
    body := jsonb_build_object('source','cron')
  );

  update public.site_settings
  set value = value || jsonb_build_object('last_run_at', now()),
      updated_at = now()
  where key = 'notik_auto_sync';
end;
$$;

-- Schedule every minute (the function self-throttles by interval_minutes)
do $$
begin
  perform cron.unschedule('notik-auto-sync');
exception when others then null;
end $$;

select cron.schedule('notik-auto-sync', '* * * * *', $$select public.notik_auto_sync_tick();$$);
