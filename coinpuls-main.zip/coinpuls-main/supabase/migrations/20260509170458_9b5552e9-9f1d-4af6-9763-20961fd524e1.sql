-- Backfill: gemiad postbacks were stored as pre-multiplied coins (×1000) instead of USD.
-- Normalize completed_offers.payout, postback_logs.payout, and profiles.balance/total_earned to USD.

WITH gem AS (
  SELECT id FROM public.providers WHERE slug = 'gemiad'
),
adjustments AS (
  SELECT user_id, SUM(payout) - SUM(payout / 1000.0) AS over_credited
  FROM public.completed_offers
  WHERE provider_id IN (SELECT id FROM gem) AND payout >= 10
  GROUP BY user_id
)
UPDATE public.profiles p
SET balance = GREATEST(0, p.balance - a.over_credited),
    total_earned = GREATEST(0, p.total_earned - a.over_credited)
FROM adjustments a
WHERE p.user_id = a.user_id;

UPDATE public.completed_offers
SET payout = payout / 1000.0
WHERE provider_id IN (SELECT id FROM public.providers WHERE slug = 'gemiad')
  AND payout >= 10;

UPDATE public.postback_logs
SET payout = payout / 1000.0
WHERE provider_slug = 'gemiad' AND payout >= 10;