-- Replace the broad public SELECT with a no-op (objects are still publicly readable
-- via the public bucket's signed/public URLs, but listing via storage.objects is restricted).
DROP POLICY IF EXISTS "Public can view provider logos" ON storage.objects;

-- Allow only admins to list/select rows in storage.objects for this bucket.
-- Public read of the actual file bytes still works because the bucket is marked public.
CREATE POLICY "Admins list provider logos"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'provider-logos' AND public.has_role(auth.uid(), 'admin'));