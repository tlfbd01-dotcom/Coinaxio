CREATE OR REPLACE FUNCTION public.admin_list_completed_offers()
RETURNS TABLE (
  id uuid,
  user_id uuid,
  username text,
  display_name text,
  provider_name text,
  title text,
  payout numeric,
  status completed_offer_status,
  provider_tx_id text,
  country text,
  created_at timestamptz
)
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT
    c.id,
    c.user_id,
    p.username,
    p.display_name,
    pr.name AS provider_name,
    c.title,
    c.payout,
    c.status,
    c.provider_tx_id,
    p.country,
    c.created_at
  FROM public.completed_offers c
  LEFT JOIN public.profiles p ON p.user_id = c.user_id
  LEFT JOIN public.providers pr ON pr.id = c.provider_id
  WHERE public.has_role(auth.uid(), 'admin')
  ORDER BY c.created_at DESC;
$$;

REVOKE ALL ON FUNCTION public.admin_list_completed_offers() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_list_completed_offers() TO authenticated;