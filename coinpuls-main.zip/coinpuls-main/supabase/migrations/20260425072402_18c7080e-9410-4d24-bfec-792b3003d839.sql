-- Public storage bucket for site assets (logo, sounds, backgrounds, homepage images)
insert into storage.buckets (id, name, public)
values ('site-assets', 'site-assets', true)
on conflict (id) do nothing;

-- Public read
create policy "Public read site assets"
  on storage.objects for select
  using (bucket_id = 'site-assets');

-- Admin write/update/delete
create policy "Admins upload site assets"
  on storage.objects for insert
  with check (
    bucket_id = 'site-assets'
    and public.has_role(auth.uid(), 'admin'::public.app_role)
  );

create policy "Admins update site assets"
  on storage.objects for update
  using (
    bucket_id = 'site-assets'
    and public.has_role(auth.uid(), 'admin'::public.app_role)
  );

create policy "Admins delete site assets"
  on storage.objects for delete
  using (
    bucket_id = 'site-assets'
    and public.has_role(auth.uid(), 'admin'::public.app_role)
  );